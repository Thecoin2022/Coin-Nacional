import * as AllIcons from '@coreui/icons';

import { logo } from './logo';
import { logoNegative } from './logo-negative';
import { sygnet } from './sygnet';

export const icons = {
  logo,
  logoNegative,
  sygnet,
  ...AllIcons,
};
