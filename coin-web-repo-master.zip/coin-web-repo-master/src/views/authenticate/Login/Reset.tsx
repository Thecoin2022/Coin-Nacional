import React from 'react';

import { useMediaQuery } from '@material-ui/core';

import { Formik } from 'formik';

import { useParams, useHistory } from 'react-router-dom';

import * as Yup from 'yup';

import api from '../../../services/api';

import {
  Container,
  Bottom,
  Icon,
  BottomText,
  Social,
  Body,
  Bar,
  Box,
  BoxBody,
  Input,
  Label,
  Image,
  Button,
  HelpText,
} from './styles';

const Login: React.FC = () => {
  const biggerThan768 = useMediaQuery('(min-width:768px)');

  const history = useHistory();

  const { token } = useParams<{ token: string }>();

  const logo = React.useMemo(() => {
    if (biggerThan768) return '/logologin.svg';
    return '/logologin2.svg';
  }, [biggerThan768]);

  return (
    <Container>
      <Body>
        <Image src={logo} alt="logo" onClick={() => history.push('/')} />
        <Box>
          <Bar />
          <BoxBody>
            <Formik
              initialValues={{ password: '', passwordConfirmation: '' }}
              validationSchema={Yup.object().shape({
                password: Yup.string().required('Campo obrigatório'),
                passwordConfirmation: Yup.string().oneOf(
                  [Yup.ref('password'), undefined],
                  'As senhas devem ser iguais',
                ),
              })}
              onSubmit={async (values, actions) => {
                await api.post('/password/reset', {
                  token,
                  password: values.password,
                  password_confirmation: values.passwordConfirmation,
                });

                history.push('/authenticate/login');

                actions.setSubmitting(false);
              }}
            >
              {props => (
                <form onSubmit={props.handleSubmit}>
                  <Label>Nova senha</Label>
                  <Input
                    placeholder="Digite sua nova senha"
                    type="password"
                    onChange={props.handleChange}
                    onBlur={props.handleBlur}
                    value={props.values.password}
                    name="password"
                  />
                  {props.errors.password && (
                    <HelpText>{props.errors.password}</HelpText>
                  )}

                  <Label>Confirmação de senha</Label>
                  <Input
                    placeholder="Confirme sua senha"
                    type="password"
                    onChange={props.handleChange}
                    onBlur={props.handleBlur}
                    value={props.values.passwordConfirmation}
                    name="passwordConfirmation"
                  />
                  {props.errors.passwordConfirmation && (
                    <HelpText>{props.errors.passwordConfirmation}</HelpText>
                  )}

                  <Button type="submit">Alterar minha senha</Button>
                </form>
              )}
            </Formik>
          </BoxBody>
        </Box>
      </Body>
      <Bottom>
        <BottomText>
          Lorem ipsum curabitur rutrum a eleifend vulputate ad sodales
          adipiscing malesuada est ipsum
        </BottomText>
        <Social>
          <Icon src="/social4.svg" alt="instagram" />
          <Icon src="/social2.svg" alt="facebook" />
          <Icon src="/social3.svg" alt="twitter" />
          <Icon src="/social1.svg" alt="whatsapp" />
        </Social>
      </Bottom>
    </Container>
  );
};

export default Login;
