import React from 'react';

import { useMediaQuery } from '@material-ui/core';

import { Formik } from 'formik';

import * as Yup from 'yup';

import { useHistory } from 'react-router-dom';

import {
  Container,
  Bottom,
  Icon,
  BottomText,
  Social,
  Body,
  Bar,
  Box,
  BoxBody,
  Input,
  Label,
  Image,
  Button,
  Forgot,
  ForgotText,
  HelpText,
} from './styles';
import { useAuth } from '../../../hooks/auth';

const Login: React.FC = () => {
  const biggerThan768 = useMediaQuery('(min-width:768px)');

  const history = useHistory();

  const { signIn } = useAuth();

  const logo = React.useMemo(() => {
    if (biggerThan768) return '/logologin.svg';
    return '/logologin2.svg';
  }, [biggerThan768]);

  return (
    <Container>
      <Body>
        <Image src={logo} alt="logo" onClick={() => history.push('/')} />
        <Box>
          <Bar />
          <BoxBody>
            <Formik
              initialValues={{ email: '', password: '' }}
              validationSchema={Yup.object().shape({
                email: Yup.string()
                  .email('E-mail inválido')
                  .required('Campo obrigatório'),
                password: Yup.string().required('Campo obrigatório'),
              })}
              onSubmit={async (values, actions) => {
                await signIn(values);

                actions.setSubmitting(false);
              }}
            >
              {props => (
                <form onSubmit={props.handleSubmit}>
                  <Label>E-mail</Label>
                  <Input
                    placeholder="Digite seu e-mail"
                    type="text"
                    onChange={props.handleChange}
                    onBlur={props.handleBlur}
                    value={props.values.email}
                    name="email"
                  />
                  {props.errors.email && (
                    <HelpText>{props.errors.email}</HelpText>
                  )}

                  <Label>Senha</Label>
                  <Input
                    placeholder="Digite sua senha"
                    type="password"
                    onChange={props.handleChange}
                    onBlur={props.handleBlur}
                    value={props.values.password}
                    name="password"
                  />
                  {props.errors.password && (
                    <HelpText>{props.errors.password}</HelpText>
                  )}

                  <Forgot onClick={() => history.push('/authenticate/forgot')}>
                    <ForgotText>Esqueci minha senha</ForgotText>
                  </Forgot>
                  <Button type="submit">Entrar</Button>
                </form>
              )}
            </Formik>
          </BoxBody>
        </Box>
      </Body>
      <Bottom>
        <BottomText>
          Lorem ipsum curabitur rutrum a eleifend vulputate ad sodales
          adipiscing malesuada est ipsum
        </BottomText>
        <Social>
          <Icon src="/social4.svg" alt="instagram" />
          <Icon src="/social2.svg" alt="facebook" />
          <Icon src="/social3.svg" alt="twitter" />
          <Icon src="/social1.svg" alt="whatsapp" />
        </Social>
      </Bottom>
    </Container>
  );
};

export default Login;
