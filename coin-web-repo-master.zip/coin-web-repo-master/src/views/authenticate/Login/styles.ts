import styled from 'styled-components';
import ButtonBase from '@material-ui/core/ButtonBase';

export const Container = styled.div`
  height: 100vh;
  width: 100vw;
  background: #fff;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`;

export const Body = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  width: 650px;
  margin: 0 auto;

  @media only screen and (min-width: 768px) {
    flex: 1;
  }

  @media only screen and (max-width: 768px) {
    width: 100%;
    padding: 20px;
  }
`;

export const Bottom = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 40px;
`;

export const BottomText = styled.div`
  color: #0a1932;
  font-size: 18px;
  text-align: center;
  padding: 0 40px;

  @media only screen and (max-width: 768px) {
    font-size: 15px;
  }
`;

export const Social = styled.div`
  display: flex;
  align-items: center;
  margin-top: 40px;
`;

export const Icon = styled.img`
  & + & {
    margin-left: 20px;
  }
`;

export const Box = styled.div``;

export const Bar = styled.div`
  background: #ffe44d;
  width: 100%;
  height: 6px;
  border-radius: 3px;
`;

export const BoxBody = styled.div`
  padding: 60px;

  @media only screen and (max-width: 768px) {
    padding: 30px;
  }
`;

export const Input = styled.input`
  padding: 10px 15px;
  border-radius: 5px;
  border: 1px solid #bbc4cf;
  width: 100%;
  margin-bottom: 10px;
  -webkit-appearance: none;

  @media only screen and (max-width: 768px) {
    margin-bottom: 20px;
  }
`;

export const Label = styled.div`
  color: #0a1932;
  font-size: 15px;
  font-weight: 500;
  margin-bottom: 7px;
`;

export const Image = styled.img`
  margin-bottom: 50px;
  cursor: pointer;

  @media only screen and (max-width: 768px) {
    margin-bottom: 25px;
  }
`;

export const Forgot = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 20px;
  cursor: pointer;

  @media only screen and (max-width: 768px) {
    margin-bottom: 20px;
  }
`;

export const ForgotText = styled.div`
  color: #0a1932;
  font-size: 15px;
`;

export const Button = styled(ButtonBase)`
  padding: 12px 15px 12px 20px !important;
  background: #0a1932 !important;
  color: #fff !important;
  text-transform: uppercase !important;
  font-weight: bold !important;
  border-radius: 7px !important;
  font-size: 14px !important;
  display: flex !important;
  align-items: center !important;
  width: 100% !important;
  margin-top: 20px !important;

  &:focus {
    outline: 0;
  }
`;

export const HelpText = styled.div`
  color: #ff0033;
  font-size: 14px;
  margin-bottom: 20px;
`;
