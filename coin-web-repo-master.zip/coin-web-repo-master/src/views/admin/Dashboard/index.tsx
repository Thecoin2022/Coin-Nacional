import React from 'react';

const Customers: React.FC = () => {
  return <div />;
};

export default Customers;
