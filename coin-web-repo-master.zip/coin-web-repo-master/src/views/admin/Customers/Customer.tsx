import React from 'react';
import { useHistory, useParams } from 'react-router-dom';

import {
  CButton,
  CCard,
  CCardBody,
  CCardFooter,
  CCardHeader,
  CCol,
  CFormGroup,
  CInput,
  CLabel,
  CInvalidFeedback,
} from '@coreui/react';
import CIcon from '@coreui/icons-react';

import * as Yup from 'yup';

import { Formik } from 'formik';

import { cilCheckAlt } from '@coreui/icons';

import { useAsync } from 'react-async';

import api from '../../../services/api';

interface IloadClients {
  id: string;
  name: string;
}

const loadClients = async ({ clientId }: any): Promise<IloadClients> => {
  const res = await api.get(`/customers/${clientId}`);

  return res.data;
};

const Client: React.FC = (): any => {
  const history = useHistory();
  const { id } = useParams<{ id: string }>();

  const { data, error, isPending } = useAsync({
    promiseFn: loadClients,
    clientId: id,
  });
  if (isPending) return null;
  if (error) return `Something went wrong: ${error.message}`;
  if (data) {
    return (
      <CCol xl={12}>
        <CCard>
          <CCardHeader>Alterar Cliente</CCardHeader>
          <Formik
            initialValues={{
              name: data.name,
            }}
            validateOnBlur={false}
            validateOnChange={false}
            validationSchema={Yup.object().shape({
              name: Yup.string().required('Campo obrigatório'),
            })}
            onSubmit={async (values, actions) => {
              const body = {
                name: values.name,
              };

              await api.patch(`/customers/${id}`, body);

              history.push('/admin/customers');

              actions.setSubmitting(false);
            }}
          >
            {({
              submitForm,
              resetForm,
              handleChange,
              handleBlur,
              values,
              errors,
              isSubmitting,
            }) => (
              <div>
                <CCardBody>
                  <CFormGroup>
                    <CLabel htmlFor="name">Nome</CLabel>
                    <CInput
                      id="name"
                      placeholder="Digite o nome"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.name}
                      invalid={!!errors.name}
                    />
                    <CInvalidFeedback>{errors.name}</CInvalidFeedback>
                  </CFormGroup>
                </CCardBody>
                <CCardFooter>
                  <CButton
                    type="submit"
                    disabled={isSubmitting}
                    onClick={submitForm}
                    size="sm"
                    color="primary"
                  >
                    <CIcon content={cilCheckAlt} /> Salvar
                  </CButton>
                  <CButton
                    style={{ marginLeft: 5 }}
                    type="reset"
                    onClick={resetForm}
                    size="sm"
                    color="danger"
                  >
                    <CIcon name="cil-ban" /> Limpar
                  </CButton>
                </CCardFooter>
              </div>
            )}
          </Formik>
        </CCard>
      </CCol>
    );
  }

  return null;
};

export default Client;
