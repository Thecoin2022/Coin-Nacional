import React, { useState, useEffect } from 'react';
import { useHistory, useLocation } from 'react-router-dom';
import {
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CDataTable,
  CRow,
  CPagination,
  CTooltip,
  CDropdown,
  CDropdownItem,
  CDropdownMenu,
  CDropdownToggle,
} from '@coreui/react';

import CIcon from '@coreui/icons-react';

import { cilTrash, cilPencil } from '@coreui/icons';

import { useAsync } from 'react-async';

import api from '../../../services/api';

interface ICustomer {
  step: number;
  has_property: boolean;
  vehicle_owner: boolean;
  vehicle_financed: boolean;
  id: string;
  user_id: string;
  type_id: string;
  status_id: string;
  name: string;
  mother_name: string;
  cpf: string;
  email: string;
  phone: string;
  birth: string;
  cep: string;
  amount: number;
  months: number;
  income: number;
  vehicle_year: number;
  installments: number;
  financed_amount: number;
  property_id: string;
  bank_id: string;
}

interface IStatus {
  id: string;
  name: string;
  color: string;
  text_color: string;
}

interface ITypes {
  id: string;
  name: string;
}

interface IloadClients {
  customers: ICustomer[];
  statuses: IStatus[];
  types: ITypes[];
}

// You can use async/await or any function that returns a Promise
const loadClients = async (): Promise<IloadClients> => {
  const { data: customers } = await api.get('/customers');

  const { data: statuses } = await api.get(`/statuses`);

  const { data: types } = await api.get(`/types`);

  return { customers, statuses, types };
};

const Doctors: React.FC = (): any => {
  const history = useHistory();
  const queryPage = useLocation().search.match(/page=([0-9]+)/);
  const currentPage = Number(queryPage && queryPage[1] ? queryPage[1] : 1);
  const [page, setPage] = useState(currentPage);

  const pageChange = (newPage: number) => {
    currentPage !== newPage && history.push(`/admin/customers?page=${newPage}`);
  };

  useEffect(() => {
    currentPage !== page && setPage(currentPage);
  }, [currentPage, page]);

  const [loadingDelete, setLoadingDelete] = React.useState(false);

  const { data, error, isPending, setData } = useAsync({
    promiseFn: loadClients,
  });
  if (isPending) return null;
  if (error) return `Something went wrong: ${error.message}`;
  if (data) {
    const removeCustomer = async (id: string) => {
      try {
        setLoadingDelete(true);

        await api.delete(`/customers/${id}`);
        const { data: customers } = await api.get('/customers');

        setData({
          ...data,
          customers,
        });

        setLoadingDelete(false);
      } catch (err) {
        setLoadingDelete(false);
      }
    };

    return (
      <CRow>
        <CCol xl={12}>
          <CCard>
            <CCardHeader>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}
              >
                Simulações
                <div>
                  <CDropdown className="m-1">
                    <CDropdownToggle color="primary" className="button-add">
                      <CIcon name="cil-plus" /> Nova Simulação
                    </CDropdownToggle>
                    <CDropdownMenu>
                      <CDropdownItem
                        onClick={() => {
                          history.push('/admin/customers/newegi');
                        }}
                      >
                        Empréstimo com Garantia de Imóvel
                      </CDropdownItem>
                      <CDropdownItem
                        onClick={() => {
                          history.push('/admin/customers/newegv');
                        }}
                      >
                        Empréstimo com Garantia de Veículo
                      </CDropdownItem>
                      <CDropdownItem
                        onClick={() => {
                          history.push('/admin/customers/newfi');
                        }}
                      >
                        Financiamento Imobiliário
                      </CDropdownItem>
                    </CDropdownMenu>
                  </CDropdown>
                </div>
              </div>
            </CCardHeader>

            <CCardBody>
              <CDataTable
                items={data.customers}
                fields={[
                  { key: 'id', _classes: 'font-weight-bold' },
                  { key: 'step', label: 'Etapa' },
                  { key: 'name', label: 'Nome' },
                  { key: 'type_id', label: 'Tipo de Financiamento' },
                  { key: 'status_id', label: 'Status' },
                  'config',
                ]}
                hover
                striped
                itemsPerPage={5}
                noItemsView={{ noItems: 'Vazio' }}
                activePage={page}
                clickableRows
                loading={loadingDelete}
                scopedSlots={{
                  type_id: (item: ICustomer) => {
                    const findType = data.types.find(
                      type => type.id === item.type_id,
                    );

                    return <td>{findType?.name}</td>;
                  },
                  status_id: (item: ICustomer) => {
                    const findStatus = data.statuses.find(
                      status => status.id === item.status_id,
                    );

                    return (
                      <td>
                        <div
                          style={{
                            backgroundColor: findStatus?.color,
                            width: 'min-content',
                            padding: '0 5px',
                            borderRadius: 5,
                            color: findStatus?.text_color,
                            fontSize: 12,
                            fontWeight: 600,
                          }}
                        >
                          {findStatus?.name}
                        </div>
                      </td>
                    );
                  },
                  config: (item: ICustomer) => (
                    <td>
                      <CTooltip content="Remover Cliente" placement="bottom">
                        <CIcon
                          onClick={() => removeCustomer(item.id)}
                          content={cilTrash}
                          size="1xl"
                        />
                      </CTooltip>
                      <span style={{ padding: '0 5px' }} />
                      <CTooltip content="Alterar Cliente" placement="bottom">
                        <CIcon
                          onClick={() => {
                            if (
                              item.type_id === process.env.REACT_APP_TYPE_EGI_ID
                            ) {
                              history.push(`/admin/customers/egi/${item.id}`);
                            }
                            if (
                              item.type_id === process.env.REACT_APP_TYPE_EGV_ID
                            ) {
                              history.push(`/admin/customers/egv/${item.id}`);
                            }
                            if (
                              item.type_id === process.env.REACT_APP_TYPE_FI_ID
                            ) {
                              history.push(`/admin/customers/fi/${item.id}`);
                            }
                          }}
                          content={cilPencil}
                          size="1xl"
                        />
                      </CTooltip>
                    </td>
                  ),
                }}
              />
              <CPagination
                activePage={page}
                onActivePageChange={pageChange}
                pages={Math.ceil(data.customers.length / 5)}
                doubleArrows={false}
                align="center"
              />
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    );
  }

  return null;
};

export default Doctors;
