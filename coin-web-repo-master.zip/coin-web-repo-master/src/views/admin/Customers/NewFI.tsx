import React from 'react';

import { useHistory } from 'react-router-dom';

import { useAsync } from 'react-async';

import { format } from 'date-fns';

import {
  CButton,
  CCard,
  CCardBody,
  CCardFooter,
  CCardHeader,
  CCol,
  CFormGroup,
  CInput,
  CLabel,
  CInvalidFeedback,
  CSwitch,
  CSelect,
} from '@coreui/react';

import CIcon from '@coreui/icons-react';

import * as Yup from 'yup';

import { Formik } from 'formik';

import { cilCheckAlt } from '@coreui/icons';

import { useAuth } from '../../../hooks/auth';

import api from '../../../services/api';

interface Istatus {
  id: string;
  name: string;
  color: string;
  text_color: string;
}

interface Iproperty {
  id: string;
  name: string;
}

interface Ibank {
  id: string;
  name: string;
}

interface IloadClients {
  statuses: Istatus[];
  properties: Iproperty[];
  banks: Ibank[];
}

// You can use async/await or any function that returns a Promise
const loadClients = async (): Promise<IloadClients> => {
  const { data: statuses } = await api.get('/statuses');

  const { data: properties } = await api.get('/properties');

  const { data: banks } = await api.get('/banks');

  return { statuses, properties, banks };
};

const Client: React.FC = (): any => {
  const history = useHistory();

  const { user } = useAuth();

  const [documentType, setDocumentType] = React.useState<'cpf' | 'cnpj'>('cpf');

  const { data, error, isPending } = useAsync({
    promiseFn: loadClients,
  });
  if (isPending) return null;
  if (error) return `Something went wrong: ${error.message}`;
  if (data) {
    type initialValuesProps = {
      has_property: boolean;
      status_id?: string;
      property_id?: string;
      cep: string;
      amount: number;
      months: number;
      name: string;
      mother_name: string;
      document: string;
      email: string;
      phone: string;
      birth: string;
      income: number;
    };

    const initialValues: initialValuesProps = {
      has_property: false,
      status_id: undefined,
      property_id: undefined,
      cep: '',
      amount: 0,
      months: 0,
      name: '',
      mother_name: '',
      document: '',
      email: '',
      phone: '',
      birth: format(new Date(), 'yyyy-MM-dd'),
      income: 0,
    };

    return (
      <CCol xl={12}>
        <CCard>
          <CCardHeader>Nova Simulação</CCardHeader>
          <Formik
            initialValues={initialValues}
            validateOnBlur={false}
            validateOnChange={false}
            validationSchema={Yup.object().shape({
              has_property: Yup.bool(),
              status_id: Yup.string()
                .uuid('Campo obrigatório')
                .nullable()
                .required('Campo obrigatório'),
              property_id: Yup.string()
                .uuid('Campo obrigatório')
                .nullable()
                .required('Campo obrigatório'),
              cep: Yup.string().required('Campo obrigatório'),
              amount: Yup.number().required('Campo obrigatório'),
              months: Yup.number().required('Campo obrigatório'),
              name: Yup.string().required('Campo obrigatório'),
              mother_name: Yup.string().required('Campo obrigatório'),
              document: Yup.string().required('Campo obrigatório'),
              email: Yup.string().required('Campo obrigatório'),
              phone: Yup.string().required('Campo obrigatório'),
              birth: Yup.date().required('Campo obrigatório'),
              income: Yup.number().required('Campo obrigatório'),
            })}
            onSubmit={async (values, actions) => {
              const body = {
                user_id: user.id,
                step: 4,
                type_id: process.env.REACT_APP_TYPE_FI_ID,
                has_property: values.has_property,
                status_id: values.status_id,
                property_id: values.property_id,
                cep: values.cep,
                amount: values.amount,
                months: values.months,
                name: values.name,
                mother_name: values.mother_name,
                document_type: documentType,
                document: values.document,
                email: values.email,
                phone: values.phone,
                birth: values.birth,
                income: values.income,
              };

              await api.post(`/customers`, body);

              history.push('/admin/customers');

              actions.setSubmitting(false);
            }}
          >
            {({
              submitForm,
              resetForm,
              handleChange,
              handleBlur,
              values,
              errors,
              isSubmitting,
            }) => (
              <div>
                <CCardBody>
                  <CFormGroup>
                    <CLabel htmlFor="name">Nome</CLabel>
                    <CInput
                      id="name"
                      placeholder="Digite o nome"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.name}
                      invalid={!!errors.name}
                    />
                    <CInvalidFeedback>{errors.name}</CInvalidFeedback>
                  </CFormGroup>
                  <CFormGroup>
                    <CLabel htmlFor="mother_name">Nome da mãe</CLabel>
                    <CInput
                      id="mother_name"
                      placeholder="Digite o nome da mãe"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.mother_name}
                      invalid={!!errors.mother_name}
                    />
                    <CInvalidFeedback>{errors.mother_name}</CInvalidFeedback>
                  </CFormGroup>
                  <CFormGroup>
                    <CLabel htmlFor="document_type">Tipo de pessoa</CLabel>
                    <CSelect
                      id="document_type"
                      onChange={(e: any) => {
                        setDocumentType(e.target.value);
                      }}
                      value={documentType}
                    >
                      <option value="cpf">Pessoa física</option>
                      <option value="cnpj">Pessoa jurídica</option>
                    </CSelect>
                  </CFormGroup>
                  <CFormGroup>
                    <CLabel htmlFor="document">
                      {documentType === 'cpf' ? 'CPF' : 'CNPJ'}
                    </CLabel>
                    <CInput
                      id="document"
                      placeholder={`Digite o ${
                        documentType === 'cpf' ? 'CPF' : 'CNPJ'
                      }`}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.document}
                      invalid={!!errors.document}
                    />
                    <CInvalidFeedback>{errors.document}</CInvalidFeedback>
                  </CFormGroup>
                  <CFormGroup>
                    <CLabel htmlFor="email">E-mail</CLabel>
                    <CInput
                      id="email"
                      placeholder="Digite o e-mail"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.email}
                      invalid={!!errors.email}
                    />
                    <CInvalidFeedback>{errors.email}</CInvalidFeedback>
                  </CFormGroup>
                  <CFormGroup>
                    <CLabel htmlFor="phone">Telefone</CLabel>
                    <CInput
                      id="phone"
                      placeholder="Digite o telefone"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.phone}
                      invalid={!!errors.phone}
                    />
                    <CInvalidFeedback>{errors.phone}</CInvalidFeedback>
                  </CFormGroup>
                  <CFormGroup>
                    <CLabel htmlFor="birth">Data de nascimento</CLabel>
                    <CInput
                      type="date"
                      id="birth"
                      name="birth"
                      value={values.birth}
                      placeholder="Data de nascimento"
                      invalid={!!errors.phone}
                    />
                    <CInvalidFeedback>{errors.phone}</CInvalidFeedback>
                  </CFormGroup>
                  <CFormGroup>
                    <CLabel htmlFor="cep">CEP</CLabel>
                    <CInput
                      id="cep"
                      placeholder="Digite o cep"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.cep}
                      invalid={!!errors.cep}
                    />
                    <CInvalidFeedback>{errors.cep}</CInvalidFeedback>
                  </CFormGroup>
                  <CFormGroup>
                    <CLabel htmlFor="income">Renda</CLabel>
                    <CInput
                      id="income"
                      type="number"
                      placeholder="Digite a renda"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.income}
                      invalid={!!errors.income}
                    />
                    <CInvalidFeedback>{errors.income}</CInvalidFeedback>
                  </CFormGroup>
                  <CFormGroup>
                    <CLabel htmlFor="property_id">Tipo de Propriedade</CLabel>
                    <CSelect
                      name="property_id"
                      id="property_id"
                      onChange={handleChange}
                      value={values.property_id}
                      invalid={!!errors.property_id}
                    >
                      <option>Selecionar</option>
                      {data.properties.map(property => (
                        <option key={property.id} value={property.id}>
                          {property.name}
                        </option>
                      ))}
                    </CSelect>
                    <CInvalidFeedback>{errors.property_id}</CInvalidFeedback>
                  </CFormGroup>
                  <CFormGroup>
                    <CLabel htmlFor="has_property">Tem propriedade ?</CLabel>
                    <div>
                      <CSwitch
                        id="has_property"
                        name="has_property"
                        onChange={handleChange}
                        color="primary"
                      />
                    </div>
                    <div className="error-form">{errors.has_property}</div>
                  </CFormGroup>
                  <CFormGroup>
                    <CLabel htmlFor="amount">Valor</CLabel>
                    <CInput
                      id="amount"
                      type="number"
                      placeholder="Digite o valor"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.amount}
                      invalid={!!errors.amount}
                    />
                    <CInvalidFeedback>{errors.amount}</CInvalidFeedback>
                  </CFormGroup>
                  <CFormGroup>
                    <CLabel htmlFor="months">Meses</CLabel>
                    <CInput
                      id="months"
                      type="number"
                      placeholder="Digite a quantidade de meses"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.months}
                      invalid={!!errors.months}
                    />
                    <CInvalidFeedback>{errors.months}</CInvalidFeedback>
                  </CFormGroup>
                  <CFormGroup>
                    <CLabel htmlFor="status_id">Status</CLabel>
                    <CSelect
                      name="status_id"
                      id="status_id"
                      onChange={handleChange}
                      value={values.status_id}
                      invalid={!!errors.status_id}
                    >
                      <option>Selecionar</option>
                      {data.statuses.map(status => (
                        <option key={status.id} value={status.id}>
                          {status.name}
                        </option>
                      ))}
                    </CSelect>
                    <CInvalidFeedback>{errors.status_id}</CInvalidFeedback>
                  </CFormGroup>
                </CCardBody>
                <CCardFooter>
                  <CButton
                    type="submit"
                    disabled={isSubmitting}
                    onClick={submitForm}
                    size="sm"
                    color="primary"
                  >
                    <CIcon content={cilCheckAlt} /> Criar
                  </CButton>
                  <CButton
                    style={{ marginLeft: 5 }}
                    type="reset"
                    onClick={resetForm}
                    size="sm"
                    color="danger"
                  >
                    <CIcon name="cil-ban" /> Limpar
                  </CButton>
                </CCardFooter>
              </div>
            )}
          </Formik>
        </CCard>
      </CCol>
    );
  }

  return null;
};

export default Client;
