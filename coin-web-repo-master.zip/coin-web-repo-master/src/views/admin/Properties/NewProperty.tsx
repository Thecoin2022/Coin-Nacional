import React from 'react';
import { useHistory } from 'react-router-dom';

import {
  CButton,
  CCard,
  CCardBody,
  CCardFooter,
  CCardHeader,
  CCol,
  CFormGroup,
  CInput,
  CLabel,
  CInvalidFeedback,
} from '@coreui/react';
import CIcon from '@coreui/icons-react';

import * as Yup from 'yup';

import { Formik } from 'formik';

import { cilCheckAlt } from '@coreui/icons';

import api from '../../../services/api';

const Client: React.FC = () => {
  const history = useHistory();

  return (
    <CCol xl={12}>
      <CCard>
        <CCardHeader>Nova Propriedade</CCardHeader>
        <Formik
          initialValues={{
            name: '',
          }}
          validateOnBlur={false}
          validateOnChange={false}
          validationSchema={Yup.object().shape({
            name: Yup.string().required('Campo obrigatório'),
          })}
          onSubmit={async (values, actions) => {
            const body = {
              name: values.name,
            };

            await api.post(`/properties`, body);

            history.push('/admin/properties');

            actions.setSubmitting(false);
          }}
        >
          {({
            submitForm,
            resetForm,
            handleChange,
            handleBlur,
            values,
            errors,
            isSubmitting,
          }) => (
            <div>
              <CCardBody>
                <CFormGroup>
                  <CLabel htmlFor="name">Nome</CLabel>
                  <CInput
                    id="name"
                    placeholder="Digite o nome"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.name}
                    invalid={!!errors.name}
                  />
                  <CInvalidFeedback>{errors.name}</CInvalidFeedback>
                </CFormGroup>
              </CCardBody>
              <CCardFooter>
                <CButton
                  type="submit"
                  disabled={isSubmitting}
                  onClick={submitForm}
                  size="sm"
                  color="primary"
                >
                  <CIcon content={cilCheckAlt} /> Criar
                </CButton>
                <CButton
                  style={{ marginLeft: 5 }}
                  type="reset"
                  onClick={resetForm}
                  size="sm"
                  color="danger"
                >
                  <CIcon name="cil-ban" /> Limpar
                </CButton>
              </CCardFooter>
            </div>
          )}
        </Formik>
      </CCard>
    </CCol>
  );
};

export default Client;
