import React from 'react';
import { useHistory } from 'react-router-dom';

import {
  CButton,
  CCard,
  CCardBody,
  CCardFooter,
  CCardHeader,
  CCol,
  CFormGroup,
  CInput,
  CLabel,
  CInvalidFeedback,
} from '@coreui/react';
import CIcon from '@coreui/icons-react';

import * as Yup from 'yup';

import { Formik } from 'formik';

import { cilCheckAlt } from '@coreui/icons';

import api from '../../../services/api';

const Client: React.FC = () => {
  const history = useHistory();

  return (
    <CCol xl={12}>
      <CCard>
        <CCardHeader>Novo Status</CCardHeader>
        <Formik
          initialValues={{
            name: '',
            color: '#ff0033',
            text_color: '#dddddd',
          }}
          validateOnBlur={false}
          validateOnChange={false}
          validationSchema={Yup.object().shape({
            name: Yup.string().required('Campo obrigatório'),
            color: Yup.string().required('Campo obrigatório'),
            text_color: Yup.string().required('Campo obrigatório'),
          })}
          onSubmit={async (values, actions) => {
            const body = {
              name: values.name,
              color: values.color,
              text_color: values.text_color,
            };

            await api.post(`/statuses`, body);

            history.push('/admin/statuses');

            actions.setSubmitting(false);
          }}
        >
          {({
            submitForm,
            resetForm,
            handleChange,
            handleBlur,
            values,
            errors,
            isSubmitting,
          }) => (
            <div>
              <CCardBody>
                <CFormGroup>
                  <CLabel htmlFor="name">Nome</CLabel>
                  <CInput
                    id="name"
                    placeholder="Digite o nome"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.name}
                    invalid={!!errors.name}
                  />
                  <CInvalidFeedback>{errors.name}</CInvalidFeedback>
                </CFormGroup>
                <CFormGroup>
                  <CLabel htmlFor="color">Cor</CLabel>
                  <CInput
                    id="color"
                    type="color"
                    placeholder="Escolha uma cor"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.color}
                    invalid={!!errors.color}
                    className="color-input"
                  />
                  <CInvalidFeedback>{errors.color}</CInvalidFeedback>
                </CFormGroup>
                <CFormGroup>
                  <CLabel htmlFor="text_color">Cor do texto</CLabel>
                  <CInput
                    id="text_color"
                    type="color"
                    placeholder="Escolha uma cor"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.text_color}
                    invalid={!!errors.text_color}
                    className="color-input"
                  />
                  <CInvalidFeedback>{errors.text_color}</CInvalidFeedback>
                </CFormGroup>
              </CCardBody>
              <CCardFooter>
                <CButton
                  type="submit"
                  disabled={isSubmitting}
                  onClick={submitForm}
                  size="sm"
                  color="primary"
                >
                  <CIcon content={cilCheckAlt} /> Criar
                </CButton>
                <CButton
                  style={{ marginLeft: 5 }}
                  type="reset"
                  onClick={resetForm}
                  size="sm"
                  color="danger"
                >
                  <CIcon name="cil-ban" /> Limpar
                </CButton>
              </CCardFooter>
            </div>
          )}
        </Formik>
      </CCard>
    </CCol>
  );
};

export default Client;
