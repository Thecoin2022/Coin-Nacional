import React from 'react';
import { useHistory } from 'react-router-dom';

import {
  CButton,
  CCard,
  CCardBody,
  CCardFooter,
  CCardHeader,
  CCol,
  CFormGroup,
  CInput,
  CLabel,
  CInvalidFeedback,
} from '@coreui/react';
import CIcon from '@coreui/icons-react';

import * as Yup from 'yup';

import { Formik } from 'formik';

import { cilCheckAlt } from '@coreui/icons';

import api from '../../../services/api';

const Client: React.FC = () => {
  const history = useHistory();

  return (
    <CCol xl={12}>
      <CCard>
        <CCardHeader>Novo Parceiro</CCardHeader>
        <Formik
          initialValues={{
            name: '',
            email: '',
            phone: '',
            employees_amount: 0,
            description: '',
          }}
          validateOnBlur={false}
          validateOnChange={false}
          validationSchema={Yup.object().shape({
            name: Yup.string().required('Campo obrigatório'),
            email: Yup.string()
              .email('E-mail inválido')
              .required('Campo obrigatório'),
            phone: Yup.string().required('Campo obrigatório'),
            employees_amount: Yup.number().required('Campo obrigatório'),
            description: Yup.string().nullable(),
          })}
          onSubmit={async (values, actions) => {
            const body = {
              name: values.name,
              email: values.email,
              phone: values.phone,
              employees_amount: values.employees_amount,
              description: values.description ? values.description : undefined,
            };

            await api.post(`/partners`, body);

            history.push('/admin/partners');

            actions.setSubmitting(false);
          }}
        >
          {({
            submitForm,
            resetForm,
            handleChange,
            handleBlur,
            values,
            errors,
            isSubmitting,
          }) => (
            <div>
              <CCardBody>
                <CFormGroup>
                  <CLabel htmlFor="name">Nome</CLabel>
                  <CInput
                    id="name"
                    placeholder="Digite o nome"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.name}
                    invalid={!!errors.name}
                  />
                  <CInvalidFeedback>{errors.name}</CInvalidFeedback>
                </CFormGroup>
                <CFormGroup>
                  <CLabel htmlFor="email">E-mail</CLabel>
                  <CInput
                    id="email"
                    placeholder="Digite o e-mail"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.email}
                    invalid={!!errors.email}
                  />
                  <CInvalidFeedback>{errors.email}</CInvalidFeedback>
                </CFormGroup>
                <CFormGroup>
                  <CLabel htmlFor="phone">Telefone</CLabel>
                  <CInput
                    id="phone"
                    placeholder="Digite o telefone"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.phone}
                    invalid={!!errors.phone}
                  />
                  <CInvalidFeedback>{errors.phone}</CInvalidFeedback>
                </CFormGroup>
                <CFormGroup>
                  <CLabel htmlFor="employees_amount">
                    Número de funcionários
                  </CLabel>
                  <CInput
                    id="employees_amount"
                    type="number"
                    placeholder="Digite o número de funcionários"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.employees_amount}
                    invalid={!!errors.employees_amount}
                  />
                  <CInvalidFeedback>{errors.employees_amount}</CInvalidFeedback>
                </CFormGroup>
                <CFormGroup>
                  <CLabel htmlFor="description">Descrição ( opcional )</CLabel>
                  <CInput
                    id="description"
                    placeholder="Digite uma descrição"
                    onChange={handleChange}
                    onBlur={handleBlur}
                    value={values.description}
                    invalid={!!errors.description}
                  />
                  <CInvalidFeedback>{errors.description}</CInvalidFeedback>
                </CFormGroup>
              </CCardBody>
              <CCardFooter>
                <CButton
                  type="submit"
                  disabled={isSubmitting}
                  onClick={submitForm}
                  size="sm"
                  color="primary"
                >
                  <CIcon content={cilCheckAlt} /> Criar
                </CButton>
                <CButton
                  style={{ marginLeft: 5 }}
                  type="reset"
                  onClick={resetForm}
                  size="sm"
                  color="danger"
                >
                  <CIcon name="cil-ban" /> Limpar
                </CButton>
              </CCardFooter>
            </div>
          )}
        </Formik>
      </CCard>
    </CCol>
  );
};

export default Client;
