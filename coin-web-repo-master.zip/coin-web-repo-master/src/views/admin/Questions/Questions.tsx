import React, { useState, useEffect } from 'react';
import { useHistory, useLocation } from 'react-router-dom';
import {
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CDataTable,
  CRow,
  CPagination,
  CBadge,
  CButton,
  CTooltip,
} from '@coreui/react';

import CIcon from '@coreui/icons-react';

import { cilTrash, cilPencil } from '@coreui/icons';

import { useAsync } from 'react-async';

import api from '../../../services/api';

interface IloadClients {
  id: string;
  name: string;
}

// You can use async/await or any function that returns a Promise
const loadClients = async (): Promise<IloadClients[]> => {
  const res = await api.get('/questions');

  return res.data;
};

const Doctors: React.FC = (): any => {
  const history = useHistory();
  const queryPage = useLocation().search.match(/page=([0-9]+)/);
  const currentPage = Number(queryPage && queryPage[1] ? queryPage[1] : 1);
  const [page, setPage] = useState(currentPage);

  const pageChange = (newPage: number) => {
    currentPage !== newPage && history.push(`/admin/questions?page=${newPage}`);
  };

  useEffect(() => {
    currentPage !== page && setPage(currentPage);
  }, [currentPage, page]);

  const [loadingDelete, setLoadingDelete] = React.useState(false);

  const { data, error, isPending, setData } = useAsync({
    promiseFn: loadClients,
  });
  if (isPending) return null;
  if (error) return `Something went wrong: ${error.message}`;
  if (data) {
    const removeQuestion = async (id: string) => {
      try {
        setLoadingDelete(true);

        await api.delete(`/questions/${id}`);
        const res = await api.get('/questions');

        setData(res.data);

        setLoadingDelete(false);
      } catch (err) {
        setLoadingDelete(false);
      }
    };

    return (
      <CRow>
        <CCol xl={12}>
          <CCard>
            <CCardHeader>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}
              >
                Perguntas Frequentes
                <CButton
                  style={{ marginLeft: 5 }}
                  onClick={() => {
                    history.push('/admin/questions/new');
                  }}
                  size="sm"
                  color="primary"
                  className="button-add"
                >
                  <CIcon name="cil-plus" /> Nova Pergunta Frequente
                </CButton>
              </div>
            </CCardHeader>

            <CCardBody>
              <CDataTable
                items={data}
                fields={[
                  { key: 'id', _classes: 'font-weight-bold' },
                  { key: 'question', label: 'Pergunta' },
                  { key: 'answer', label: 'Resposta' },
                  'status',
                  'config',
                ]}
                hover
                striped
                itemsPerPage={5}
                noItemsView={{ noItems: 'Vazio' }}
                activePage={page}
                clickableRows
                loading={loadingDelete}
                scopedSlots={{
                  status: () => (
                    <td>
                      <CBadge color="success">Ativo</CBadge>
                    </td>
                  ),
                  config: (item: IloadClients) => (
                    <td>
                      <CTooltip
                        content="Remover Pergunta Frequente"
                        placement="bottom"
                      >
                        <CIcon
                          onClick={() => removeQuestion(item.id)}
                          content={cilTrash}
                          size="1xl"
                        />
                      </CTooltip>
                      <span style={{ padding: '0 5px' }} />
                      <CTooltip
                        content="Alterar Pergunta Frequente"
                        placement="bottom"
                      >
                        <CIcon
                          onClick={() => {
                            history.push(`/admin/questions/${item.id}`);
                          }}
                          content={cilPencil}
                          size="1xl"
                        />
                      </CTooltip>
                    </td>
                  ),
                }}
              />
              <CPagination
                activePage={page}
                onActivePageChange={pageChange}
                pages={Math.ceil(data.length / 5)}
                doubleArrows={false}
                align="center"
              />
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    );
  }

  return null;
};

export default Doctors;
