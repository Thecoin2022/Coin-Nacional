import React, { useState, useEffect } from 'react';
import { useHistory, useLocation } from 'react-router-dom';
import {
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CDataTable,
  CRow,
  CPagination,
  CBadge,
  CButton,
  CTooltip,
} from '@coreui/react';

import CIcon from '@coreui/icons-react';

import { cilTrash, cilPencil } from '@coreui/icons';

import { useAsync } from 'react-async';

import api from '../../../services/api';

interface IloadClients {
  id: string;
  title: string;
  image: string;
  content: string;
}

// You can use async/await or any function that returns a Promise
const loadClients = async (): Promise<IloadClients[]> => {
  const res = await api.get('/posts');

  return res.data;
};

const Doctors: React.FC = (): any => {
  const history = useHistory();
  const queryPage = useLocation().search.match(/page=([0-9]+)/);
  const currentPage = Number(queryPage && queryPage[1] ? queryPage[1] : 1);
  const [page, setPage] = useState(currentPage);

  const pageChange = (newPage: number) => {
    currentPage !== newPage && history.push(`/admin/posts?page=${newPage}`);
  };

  useEffect(() => {
    currentPage !== page && setPage(currentPage);
  }, [currentPage, page]);

  const [loadingDelete, setLoadingDelete] = React.useState(false);

  const { data, error, isPending, setData } = useAsync({
    promiseFn: loadClients,
  });
  if (isPending) return null;
  if (error) return `Something went wrong: ${error.message}`;
  if (data) {
    const removePost = async (id: string) => {
      try {
        setLoadingDelete(true);

        await api.delete(`/posts/${id}`);
        const res = await api.get('/posts');

        setData(res.data);

        setLoadingDelete(false);
      } catch (err) {
        setLoadingDelete(false);
      }
    };

    return (
      <CRow>
        <CCol xl={12}>
          <CCard>
            <CCardHeader>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}
              >
                Postagens
                <CButton
                  style={{ marginLeft: 5 }}
                  onClick={() => {
                    history.push('/admin/posts/new');
                  }}
                  size="sm"
                  color="primary"
                  className="button-add"
                >
                  <CIcon name="cil-plus" /> Nova Postagem
                </CButton>
              </div>
            </CCardHeader>

            <CCardBody>
              <CDataTable
                items={data}
                fields={[
                  { key: 'id', _classes: 'font-weight-bold' },
                  { key: 'title', label: 'Título' },
                  { key: 'image', label: 'Imagem' },
                  { key: 'content', label: 'Conteúdo' },
                  'status',
                  'config',
                ]}
                hover
                striped
                itemsPerPage={5}
                noItemsView={{ noItems: 'Vazio' }}
                activePage={page}
                clickableRows
                loading={loadingDelete}
                scopedSlots={{
                  status: () => (
                    <td>
                      <CBadge color="success">Ativo</CBadge>
                    </td>
                  ),
                  image: (item: IloadClients) => (
                    <td>
                      <img
                        src={`${process.env.REACT_APP_API_URL}files/${item.image}`}
                        style={{ width: 60, height: 25, objectFit: 'cover' }}
                        alt={item.image}
                      />
                    </td>
                  ),
                  config: (item: IloadClients) => (
                    <td>
                      <CTooltip content="Remover Postagem" placement="bottom">
                        <CIcon
                          onClick={() => removePost(item.id)}
                          content={cilTrash}
                          size="1xl"
                        />
                      </CTooltip>
                      <span style={{ padding: '0 5px' }} />
                      <CTooltip content="Alterar Postagem" placement="bottom">
                        <CIcon
                          onClick={() => {
                            history.push(`/admin/posts/${item.id}`);
                          }}
                          content={cilPencil}
                          size="1xl"
                        />
                      </CTooltip>
                    </td>
                  ),
                }}
              />
              <CPagination
                activePage={page}
                onActivePageChange={pageChange}
                pages={Math.ceil(data.length / 5)}
                doubleArrows={false}
                align="center"
              />
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    );
  }

  return null;
};

export default Doctors;
