import React from 'react';
import { useHistory, useParams } from 'react-router-dom';

import {
  CButton,
  CCard,
  CCardBody,
  CCardFooter,
  CCardHeader,
  CCol,
  CFormGroup,
  CInput,
  CLabel,
  CInvalidFeedback,
  CInputFile,
} from '@coreui/react';
import CIcon from '@coreui/icons-react';

import * as Yup from 'yup';

import { Formik } from 'formik';

import { cilCheckAlt } from '@coreui/icons';

import { useAsync } from 'react-async';

import api from '../../../services/api';

type ThumbProps = {
  file: File;
};

const Thumb: React.FC<ThumbProps> = ({ file }) => {
  const [loading, setLoading] = React.useState(false);
  const [thumb, setThumb] = React.useState(undefined);

  React.useEffect(() => {
    if (!file) {
      return;
    }

    setLoading(true);

    const reader = new FileReader();

    reader.onloadend = () => {
      setLoading(true);
      setThumb(reader.result as any);
    };

    reader.readAsDataURL(file);
  }, [file]);

  if (!file) {
    return null;
  }

  if (loading) {
    return null;
  }

  return (
    <img
      src={thumb}
      alt={file.name}
      className="img-thumbnail mt-2"
      height={200}
      width={200}
    />
  );
};

interface IloadClients {
  id: string;
  title: string;
  image: string;
  content: string;
}

const loadClients = async ({ clientId }: any): Promise<IloadClients> => {
  const res = await api.get(`/posts/${clientId}`);

  return res.data;
};

const Client: React.FC = (): any => {
  const history = useHistory();
  const { id } = useParams<{ id: string }>();

  const { data, error, isPending } = useAsync({
    promiseFn: loadClients,
    clientId: id,
  });
  if (isPending) return null;
  if (error) return `Something went wrong: ${error.message}`;
  if (data) {
    type initialValuesProps = {
      title: string;
      image: File;
      content: string;
    };

    const initialValues: initialValuesProps = {
      title: data.title,
      image: null as any,
      content: data.content,
    };

    return (
      <CCol xl={12}>
        <CCard>
          <CCardHeader>Alterar Postagem</CCardHeader>
          <Formik
            initialValues={initialValues}
            validateOnBlur={false}
            validateOnChange={false}
            validationSchema={Yup.object().shape({
              title: Yup.string().required('Campo obrigatório'),
              image: Yup.mixed(),
              content: Yup.string().required('Campo obrigatório'),
            })}
            onSubmit={async (values, actions) => {
              const body = {
                title: values.title,
                content: values.content,
              };

              await api.patch(`/posts/${id}`, body);

              if (values.image) {
                const dataForm = new FormData();

                dataForm.append('image', values.image);

                await api.patch(`/posts/${id}/image`, dataForm);
              }

              history.push('/admin/posts');

              actions.setSubmitting(false);
            }}
          >
            {({
              submitForm,
              resetForm,
              handleChange,
              handleBlur,
              values,
              errors,
              isSubmitting,
              setFieldValue,
            }) => (
              <div>
                <CCardBody>
                  <CFormGroup>
                    <CLabel htmlFor="title">Título</CLabel>
                    <CInput
                      id="title"
                      placeholder="Digite o título"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.title}
                      invalid={!!errors.title}
                    />
                    <CInvalidFeedback>{errors.title}</CInvalidFeedback>
                  </CFormGroup>
                  <CFormGroup>
                    <CLabel htmlFor="content">Conteúdo</CLabel>
                    <CInput
                      id="content"
                      placeholder="Digite o conteúdo"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.content}
                      invalid={!!errors.content}
                    />
                    <CInvalidFeedback>{errors.content}</CInvalidFeedback>
                  </CFormGroup>
                  <CFormGroup row>
                    <CLabel col htmlFor="image">
                      Imagem
                    </CLabel>

                    <CInputFile
                      id="image"
                      name="image"
                      onChange={event => {
                        setFieldValue('image', event.currentTarget.files[0]);
                      }}
                      style={{ marginLeft: 15 }}
                    />
                    <CInvalidFeedback>{errors.image}</CInvalidFeedback>
                  </CFormGroup>
                  {values.image ? (
                    <Thumb file={values.image} />
                  ) : (
                    <img
                      src={`${process.env.REACT_APP_API_URL}files/${data.image}`}
                      alt={data.image}
                      className="img-thumbnail mt-2"
                      height={200}
                      width={200}
                    />
                  )}
                </CCardBody>
                <CCardFooter>
                  <CButton
                    type="submit"
                    disabled={isSubmitting}
                    onClick={submitForm}
                    size="sm"
                    color="primary"
                  >
                    <CIcon content={cilCheckAlt} /> Salvar
                  </CButton>
                  <CButton
                    style={{ marginLeft: 5 }}
                    type="reset"
                    onClick={resetForm}
                    size="sm"
                    color="danger"
                  >
                    <CIcon name="cil-ban" /> Limpar
                  </CButton>
                </CCardFooter>
              </div>
            )}
          </Formik>
        </CCard>
      </CCol>
    );
  }

  return null;
};

export default Client;
