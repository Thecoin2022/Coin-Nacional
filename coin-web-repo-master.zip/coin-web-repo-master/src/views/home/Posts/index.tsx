import React from 'react';

import { useAsync } from 'react-async';

import { useHistory } from 'react-router-dom';

import api from '../../../services/api';

import {
  Container,
  Head,
  Post,
  Image,
  Info,
  Title,
  Description,
  Grid,
} from './styles';

interface IloadClients {
  posts: Array<{
    id: string;
    title: string;
    image: string;
    content: string;
  }>;
}

const loadClients = async (): Promise<IloadClients> => {
  const { data: posts } = await api.get(`/posts`);

  return { posts };
};

const Contact: React.FC = (): any => {
  const history = useHistory();

  const { data, error, isPending } = useAsync({
    promiseFn: loadClients,
  });
  if (isPending) return null;
  if (error) return `Something went wrong: ${error.message}`;
  if (data) {
    return (
      <>
        <Head>Blog</Head>
        <Container>
          <Grid>
            {data.posts.map(post => (
              <Post
                key={post.id}
                onClick={() => {
                  history.push(`/blog/${post.id}`);
                }}
              >
                <Image
                  src={`${process.env.REACT_APP_API_URL}files/${post.image}`}
                  alt={post.image}
                />
                <Info>
                  <Title>{post.title}</Title>
                  <Description>{post.content}</Description>
                </Info>
              </Post>
            ))}
          </Grid>
        </Container>
      </>
    );
  }

  return null;
};

export default Contact;
