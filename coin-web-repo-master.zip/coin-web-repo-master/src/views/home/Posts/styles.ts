import styled from 'styled-components';

export const Container = styled.div`
  background: #fff;
  flex: 1;
  max-width: 1280px;
  width: 100%;
  margin: 0 auto;
  padding: 50px 20px;
`;

export const Grid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-gap: 40px;

  @media only screen and (max-width: 768px) {
    grid-template-columns: 1fr;
    grid-gap: 20px;
  }
`;

export const Head = styled.div`
  background: #0a1932;
  width: 100%;
  text-align: center;
  font-size: 32px;
  font-weight: 800;
  padding: 70px 20px;
  color: #fff;

  @media only screen and (max-width: 1024px) {
    font-size: 24px;
    font-weight: bold;
    padding: 50px 20px;
  }

  @media only screen and (max-width: 768px) {
    font-size: 18px;
    font-weight: bold;
    padding: 30px 20px;
  }
`;

export const Post = styled.div`
  border-radius: 10px;
  overflow: hidden;
  cursor: pointer;
`;

export const Image = styled.img`
  width: 100%;
  height: 300px;
  object-fit: cover;

  @media only screen and (max-width: 768px) {
    height: 200px;
  }
`;

export const Info = styled.div`
  background: #05132a;
  padding: 20px;
`;

export const Title = styled.div`
  color: #fff;
  font-size: 18px;
  font-weight: bold;
  line-height: 1.5em;
  height: 1.5em;
  overflow: hidden;
  text-overflow: ellipsis;
`;

export const Description = styled.div`
  color: #fff;
  font-size: 15px;
  margin-top: 10px;
  line-height: 1.5em;
  height: 3em;
  overflow: hidden;
  text-overflow: ellipsis;
`;
