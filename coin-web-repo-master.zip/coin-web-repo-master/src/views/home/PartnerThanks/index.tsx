import React from 'react';

import {
  Container,
  Section,
  SectionDescription,
  SectionTitle,
  Image,
} from './styles';

const Questions: React.FC = (): any => {
  return (
    <Container>
      <Section>
        <SectionTitle>Obrigado!</SectionTitle>

        <SectionDescription>
          Sua solicitação foi enviada para a nossa equipe. Assim que revisado
          será enviado novas instruções para o e-mail cadastrado.
        </SectionDescription>
      </Section>

      <Image src="/partnersform.svg" alt="Parceiro" />
    </Container>
  );
};

export default Questions;
