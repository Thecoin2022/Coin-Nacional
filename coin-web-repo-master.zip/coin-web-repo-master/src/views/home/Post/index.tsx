import React from 'react';

import { useAsync } from 'react-async';

import { useParams } from 'react-router-dom';

import { useMediaQuery } from '@material-ui/core';

import { format, parseISO } from 'date-fns';

import ptBR from 'date-fns/locale/pt-BR';

import api from '../../../services/api';

import {
  Container,
  Head,
  Title,
  Image,
  Content,
  Divider,
  Header,
  HeaderAuthor,
  HeaderAuthorHighlight,
  HeaderDate,
  HeaderTexts,
  Social,
  SocialImage,
  HeaderFull,
  SocialBottom,
} from './styles';

interface IloadClients {
  post: {
    id: string;
    title: string;
    image: string;
    content: string;
    created_at: string;
  };
}

const loadClients = async ({ postId }: any): Promise<IloadClients> => {
  const { data: post } = await api.get(`/posts/${postId}`);

  return { post };
};

const Contact: React.FC = (): any => {
  const biggerThan768 = useMediaQuery('(min-width:768px)');

  const { id } = useParams<{ id: string }>();

  const { data, error, isPending } = useAsync({
    promiseFn: loadClients,
    postId: id,
  });
  if (isPending) return null;
  if (error) return `Something went wrong: ${error.message}`;
  if (data) {
    return (
      <>
        <Head>Fale Conosco</Head>
        <Container>
          <HeaderFull>
            <Header>
              <img src="/post.svg" alt="autor" />
              <HeaderTexts>
                <HeaderAuthor>
                  escrito por{' '}
                  <HeaderAuthorHighlight>Coin</HeaderAuthorHighlight>
                </HeaderAuthor>
                <HeaderDate>
                  {format(parseISO(data.post.created_at), "MMMM 'de' yyyy", {
                    locale: ptBR,
                  })}
                </HeaderDate>
              </HeaderTexts>
            </Header>

            {biggerThan768 && (
              <Social>
                <SocialImage src="/post2.svg" alt="whatsapp" />
                <SocialImage src="/post3.svg" alt="instagram" />
                <SocialImage src="/post4.svg" alt="facebook" />
                <SocialImage src="/post5.svg" alt="twitter" />
              </Social>
            )}
          </HeaderFull>

          <Title>{data.post.title}</Title>
          <Divider />
          <Image
            src={`${process.env.REACT_APP_API_URL}files/${data.post.image}`}
            alt={data.post.image}
          />
          <Content>{data.post.content}</Content>

          {biggerThan768 || (
            <SocialBottom>
              <Social>
                <SocialImage src="/post2.svg" alt="whatsapp" />
                <SocialImage src="/post3.svg" alt="instagram" />
                <SocialImage src="/post4.svg" alt="facebook" />
                <SocialImage src="/post5.svg" alt="twitter" />
              </Social>
            </SocialBottom>
          )}
        </Container>
      </>
    );
  }

  return null;
};

export default Contact;
