import styled from 'styled-components';

export const Container = styled.div`
  background: #fff;
  flex: 1;
  width: 100%;
  max-width: 980px;
  margin: 0 auto;
  padding: 70px 20px;

  @media only screen and (max-width: 768px) {
    padding: 20px;
  }
`;

export const Head = styled.div`
  background: #0a1932;
  width: 100%;
  text-align: center;
  font-size: 32px;
  font-weight: 800;
  padding: 70px 20px;
  color: #fff;

  @media only screen and (max-width: 1024px) {
    font-size: 24px;
    font-weight: bold;
    padding: 50px 20px;
  }

  @media only screen and (max-width: 768px) {
    font-size: 18px;
    font-weight: bold;
    padding: 30px 20px;
  }
`;

export const Title = styled.div`
  color: #0a1932;
  font-size: 32px;
  font-weight: bold;
  width: 100%;
  text-align: center;

  @media only screen and (max-width: 768px) {
    font-size: 24px;
  }
`;

export const Image = styled.img`
  width: 100%;
  object-fit: cover;
  max-height: 400px;
`;

export const Content = styled.div`
  color: #0a1932;
  font-size: 15px;
  margin-top: 50px;
  text-align: justify;

  @media only screen and (max-width: 768px) {
    margin-top: 20px;
  }
`;

export const Divider = styled.div`
  background: #bfc6d2;
  height: 1px;
  width: 60%;
  margin: 50px auto;

  @media only screen and (max-width: 768px) {
    margin: 20px auto;
  }
`;

export const Header = styled.div`
  display: flex;
  align-items: center;
`;

export const HeaderTexts = styled.div`
  margin-left: 20px;
`;

export const HeaderAuthor = styled.div`
  color: #0a1932;
  font-size: 18px;
  font-weight: 500;

  @media only screen and (max-width: 768px) {
    font-size: 15px;
  }
`;

export const HeaderAuthorHighlight = styled.span`
  color: #ffe44d;
  font-size: 18px;
  font-weight: 500;

  @media only screen and (max-width: 768px) {
    font-size: 15px;
  }
`;

export const HeaderDate = styled.span`
  color: #0a1932;
  font-size: 18px;
  margin-top: 10px;
  font-weight: 500;

  @media only screen and (max-width: 768px) {
    font-size: 15px;
  }
`;

export const Social = styled.div`
  display: flex;
  align-items: center;
`;

export const SocialImage = styled.img`
  cursor: pointer;

  & + & {
    margin-left: 10px;
  }
`;

export const HeaderFull = styled.div`
  margin-bottom: 40px;
  display: flex;
  align-items: center;
  justify-content: space-between;

  @media only screen and (max-width: 768px) {
    margin-bottom: 20px;
  }
`;

export const SocialBottom = styled.div`
  display: flex;
  flex-direction: column;
  margin-top: 20px;
  align-items: center;
`;
