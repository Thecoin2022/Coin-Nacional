import React from 'react';

import { useHistory } from 'react-router-dom';

import {
  Container,
  Head,
  Image,
  Left,
  Title,
  Title2,
  Description,
  Section1,
  Section1Left,
  Section1Right,
  Section1Description,
  Section1Title,
  Section2,
  Section2Description,
  Section2Title,
  Image2,
  Button,
  Buttons,
  Section3,
  Section3Description,
  Section3Title,
} from './styles';

const About: React.FC = () => {
  const history = useHistory();

  return (
    <>
      <Container>
        <Head>
          <Left>
            <Title>
              {/* eslint-disable-next-line react/jsx-one-expression-per-line */}
              Sobre a<Title2> Coin</Title2>
            </Title>
            <Description>
              Somos uma plataforma online de empréstimo com garantia.
              Trabalhamos com instituições financeiras que emitem o contrato de
              empréstimo com base na solução financeira que estruturamos para
              você. Viabilizando suas conquistas
            </Description>
          </Left>
          <Image src="/about.svg" alt="sobre" />
        </Head>

        <Section1>
          <Section1Left src="/about3.png" alt="sobre" />
          <Section1Right>
            <Section1Title>
              Seja qual for seu motivo, nós estamos aqui pra ajudar você!
            </Section1Title>
            <Section1Description>
              Trabalhamos com três produtos principais: o empréstimo com imóvel
              em garantia, com carro em garantia e o financiamento imobiliário o
              que nos permite oferecer crédito com taxas de juros mais baixas e
              parcelas mais saudáveis para o seu orçamento!
            </Section1Description>
          </Section1Right>
        </Section1>

        <Section2>
          <Section2Title>
            Somos uma fintech nova, mas com muita história para contar
          </Section2Title>

          <Section2Description>
            Incansavelmente nos dedicamos para impactar positivamente cada vez
            mais pessoas, ao permitir acesso a um crédito saudável.
          </Section2Description>
        </Section2>
      </Container>
      <Image2 src="/about2.png" alt="sobre" />
      <Section3>
        <Section3Title>Sua próxima revolução começa aqui!</Section3Title>

        <Section3Description>Conheça nossas soluções:</Section3Description>

        <Buttons>
          <Button
            onClick={() => {
              history.push('/simulacao/egi');
            }}
          >
            Empréstimo com Garantia de Imóvel
          </Button>
          <Button
            onClick={() => {
              history.push('/simulacao/egv');
            }}
          >
            Empréstimo com Garantía de Veículo
          </Button>
          <Button
            onClick={() => {
              history.push('/simulacao/fi');
            }}
          >
            Financiamento Imobiliário
          </Button>
        </Buttons>
      </Section3>
    </>
  );
};

export default About;
