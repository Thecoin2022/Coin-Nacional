import styled from 'styled-components';
import ButtonBase from '@material-ui/core/ButtonBase';

export const Container = styled.div`
  width: 100%;
  max-width: 1280px;
  margin: 0 auto;
`;

export const Head = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  margin: 40px 20px;
  grid-gap: 20px;

  @media only screen and (max-width: 768px) {
    grid-template-columns: 1fr;
    grid-gap: 40px;
  }
`;

export const Image = styled.img`
  width: 100%;

  @media only screen and (max-width: 768px) {
    grid-row-start: 1;
    grid-row-end: 2;
  }
`;

export const Left = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
`;

export const Title = styled.div`
  color: #0a1932;
  font-size: 32px;
  font-weight: bold;

  @media only screen and (max-width: 768px) {
    text-align: center;
  }
`;

export const Title2 = styled.span`
  color: #ffe44d;
  font-size: 32px;
  font-weight: bold;
`;

export const Description = styled.span`
  color: #0a1932;
  font-size: 18px;
  margin-top: 20px;

  @media only screen and (max-width: 768px) {
    text-align: center;
  }
`;

export const Section1 = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;

  @media only screen and (max-width: 425px) {
    grid-template-columns: 1fr;
  }
`;

export const Section1Right = styled.div`
  background: #ffe44d;
  padding: 70px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  @media only screen and (max-width: 1024px) {
    padding: 50px;
  }

  @media only screen and (max-width: 768px) {
    padding: 20px;
  }
`;

export const Section1Title = styled.div`
  color: #0a1932;
  font-size: 24px;
  font-weight: bold;
  text-align: right;

  @media only screen and (max-width: 1024px) {
    font-size: 18px;
  }

  @media only screen and (max-width: 425px) {
    text-align: center;
  }
`;

export const Section1Description = styled.div`
  color: #0a1932;
  font-size: 18px;
  margin-top: 20px;
  text-align: right;

  @media only screen and (max-width: 1024px) {
    font-size: 15px;
    margin-top: 10px;
  }

  @media only screen and (max-width: 425px) {
    text-align: center;
  }
`;

export const Section1Left = styled.img`
  width: 100%;
  height: 100%;
  object-fit: cover;

  @media only screen and (max-width: 425px) {
    height: 250px;
  }
`;

export const Section2 = styled.div`
  padding: 100px 200px;
  display: flex;
  flex-direction: column;
  align-items: center;

  @media only screen and (max-width: 1024px) {
    padding: 100px 150px;
  }

  @media only screen and (max-width: 768px) {
    padding: 70px;
  }

  @media only screen and (max-width: 425px) {
    padding: 35px;
  }
`;

export const Section2Title = styled.div`
  color: #0a1932;
  font-size: 32px;
  font-weight: bold;
  text-align: center;

  @media only screen and (max-width: 768px) {
    font-size: 24px;
  }
`;

export const Section2Description = styled.div`
  color: #0a1932;
  font-size: 18px;
  margin-top: 20px;
  text-align: center;

  @media only screen and (max-width: 768px) {
    font-size: 15px;
  }
`;

export const Image2 = styled.img`
  width: 100%;
  max-height: 400px;
  object-fit: cover;
`;

export const Section3 = styled.div`
  background: #ffe44d;
  padding: 100px;
  display: flex;
  flex-direction: column;
  align-items: center;

  @media only screen and (max-width: 1024px) {
    padding: 100px 150px;
  }

  @media only screen and (max-width: 768px) {
    padding: 70px;
  }

  @media only screen and (max-width: 425px) {
    padding: 50px;
  }
`;

export const Section3Title = styled.div`
  color: #0a1932;
  font-size: 32px;
  font-weight: bold;
  text-align: center;

  @media only screen and (max-width: 768px) {
    font-size: 24px;
  }
`;

export const Section3Description = styled.div`
  color: #0a1932;
  font-size: 18px;
  margin-top: 20px;
  text-align: center;

  @media only screen and (max-width: 768px) {
    font-size: 15px;
  }
`;

export const Buttons = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  grid-gap: 20px;
  margin-top: 50px;

  @media only screen and (max-width: 768px) {
    grid-template-columns: 1fr;
    grid-gap: 40px;
  }
`;

export const Button = styled(ButtonBase)`
  background: #0a1932 !important;
  color: #fff !important;
  padding: 15px !important;
  font-size: 18px !important;
  font-weight: bold !important;
  text-align: center !important;
  border-radius: 5px !important;

  &:focus {
    outline: 0;
  }

  @media only screen and (max-width: 768px) {
    font-size: 15px !important;
  }
`;
