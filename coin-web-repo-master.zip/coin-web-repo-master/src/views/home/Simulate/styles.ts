import styled from 'styled-components';
import ButtonBase from '@material-ui/core/ButtonBase';

export const Container = styled.div`
  width: 100%;
  max-width: 1280px;
  margin: 0 auto;
`;

export const Section2 = styled.div`
  padding: 100px 200px;
  display: flex;
  flex-direction: column;
  align-items: center;

  @media only screen and (max-width: 1024px) {
    padding: 100px 150px;
  }

  @media only screen and (max-width: 768px) {
    padding: 70px;
  }

  @media only screen and (max-width: 425px) {
    padding: 35px;
  }
`;

export const Section2Title = styled.div`
  color: #0a1932;
  font-size: 32px;
  font-weight: bold;
  text-align: center;

  @media only screen and (max-width: 768px) {
    font-size: 24px;
  }
`;

export const Section2Description = styled.div`
  color: #0a1932;
  font-size: 18px;
  margin-top: 20px;
  text-align: center;

  @media only screen and (max-width: 768px) {
    font-size: 15px;
  }
`;

export const Section3 = styled.div`
  background: #ffe44d;
  padding: 100px;
  display: flex;
  flex-direction: column;
  align-items: center;

  @media only screen and (max-width: 1024px) {
    padding: 100px 150px;
  }

  @media only screen and (max-width: 768px) {
    padding: 70px;
  }

  @media only screen and (max-width: 425px) {
    padding: 50px;
  }
`;

export const Section3Title = styled.div`
  color: #0a1932;
  font-size: 32px;
  font-weight: bold;
  text-align: center;

  @media only screen and (max-width: 768px) {
    font-size: 24px;
  }
`;

export const Buttons = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  grid-gap: 20px;
  margin-top: 50px;

  @media only screen and (max-width: 768px) {
    grid-template-columns: 1fr;
    grid-gap: 40px;
  }
`;

export const Button = styled(ButtonBase)`
  background: #0a1932 !important;
  color: #fff !important;
  padding: 15px !important;
  font-size: 18px !important;
  font-weight: bold !important;
  text-align: center !important;
  border-radius: 5px !important;

  &:focus {
    outline: 0;
  }

  @media only screen and (max-width: 768px) {
    font-size: 15px !important;
  }
`;
