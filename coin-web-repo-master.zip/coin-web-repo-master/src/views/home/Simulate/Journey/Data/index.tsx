import React from 'react';

import { useHistory } from 'react-router-dom';

import { Formik } from 'formik';

import { format } from 'date-fns';

import { useRecoilValue } from 'recoil';

import * as Yup from 'yup';

import { SimulateId } from '../../../../../store/atoms/Simulate';

import {
  Container,
  Title,
  Input,
  Button,
  Form,
  InputMask,
  SelectForm,
  BottomLabel,
} from './styles';
import api from '../../../../../services/api';

const EGI1: React.FC = () => {
  const history = useHistory();

  const [documentType, setDocumentType] = React.useState<'cpf' | 'cnpj'>('cpf');

  const simulateId = useRecoilValue(SimulateId);

  type initialValuesProps = {
    name: string;
    email: string;
    phone: string;
    document: string;
    birth: string;
  };

  const initialValues: initialValuesProps = {
    name: '',
    email: '',
    phone: '',
    document: '',
    birth: format(new Date(), 'yyyy-MM-dd'),
  };

  if (!simulateId) {
    history.push('/simulacao');
  }

  return (
    <Container>
      <Title>Sobre você</Title>

      <SelectForm
        onChange={e => {
          setDocumentType(e.target.value as 'cpf' | 'cnpj');
        }}
        value={documentType}
      >
        <option value="cpf">Pessoa física</option>
        <option value="cnpj">Pessoa jurídica</option>
      </SelectForm>

      <Formik
        initialValues={initialValues}
        validateOnBlur={false}
        validateOnChange={false}
        validationSchema={Yup.object().shape({
          name: Yup.string().required('Campo obrigatório'),
          email: Yup.string().email().required('Campo obrigatório'),
          phone: Yup.string().required('Campo obrigatório'),
          document: Yup.string().required('Campo obrigatório'),
          birth: Yup.date().required('Campo obrigatório'),
        })}
        onSubmit={async (values, actions) => {
          await api.patch(`/customers/${simulateId}`, {
            ...values,
            document_type: documentType,
            step: 2,
          });

          history.push('/simulacao/resultado');

          actions.setSubmitting(false);
        }}
      >
        {props => (
          <Form onSubmit={props.handleSubmit}>
            <Input
              placeholder={
                documentType === 'cpf' ? 'Nome Completo' : 'Razão social'
              }
              onChange={props.handleChange}
              onBlur={props.handleBlur}
              value={props.values.name}
              error={!!props.errors.name}
              name="name"
            />
            <InputMask
              placeholder="Documento"
              onChange={props.handleChange}
              onBlur={props.handleBlur}
              value={props.values.document}
              error={!!props.errors.document}
              name="document"
              mask={
                documentType === 'cpf' ? '999.999.999-99' : '99.999.999/9999-99'
              }
              maskChar=" "
            />
            <Input
              placeholder="E-mail"
              onChange={props.handleChange}
              onBlur={props.handleBlur}
              value={props.values.email}
              error={!!props.errors.email}
              name="email"
            />
            <InputMask
              placeholder="Telefone"
              onChange={props.handleChange}
              onBlur={props.handleBlur}
              value={props.values.phone}
              error={!!props.errors.phone}
              name="phone"
              mask="99 999999999"
              maskChar=" "
            />
            <Input
              type="date"
              placeholder="Data de Nascimento"
              onChange={props.handleChange}
              onBlur={props.handleBlur}
              value={props.values.birth}
              error={!!props.errors.birth}
              name="birth"
            />
            <BottomLabel>Data de nascimento</BottomLabel>
            <Button type="submit">Próximo passo</Button>
          </Form>
        )}
      </Formik>
    </Container>
  );
};

export default EGI1;
