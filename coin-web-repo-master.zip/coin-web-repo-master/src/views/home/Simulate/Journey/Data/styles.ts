import styled from 'styled-components';
import ButtonBase from '@material-ui/core/ButtonBase';

import InputMaskBase from 'react-input-mask';

export const Container = styled.div`
  width: 650px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 70px;

  @media only screen and (max-width: 768px) {
    width: 100%;
    padding: 0 20px;
    margin-bottom: 40px;
  }
`;

export const Price = styled.div`
  width: 100%;
  text-align: center;
  color: #0a1932;
  font-size: 15px;
  font-weight: bold;
  margin-bottom: 70px;
`;

export const Title = styled.div`
  width: 100%;
  text-align: center;
  color: #0a1932;
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 50px;
`;

export const Select = styled.select`
  background: #0a1932;
  color: #fff;
  font-size: 16px;
  font-weight: bold;
  padding: 10px 15px;
  border-radius: 5px;
  border: none;
  margin-bottom: 20px;
`;

type InputProps = {
  error?: boolean;
};

export const Input = styled.input<InputProps>`
  padding: 10px 15px;
  border-radius: 5px;
  border: 1px solid ${props => (props.error ? '#f03' : '#90a8d0')};
  min-width: 0;
  width: 100%;
  margin-top: 20px;
`;

export const InputMask = styled(InputMaskBase)<InputProps>`
  padding: 10px 15px;
  border-radius: 5px;
  border: 1px solid ${props => (props.error ? '#f03' : '#90a8d0')};
  min-width: 0;
  width: 100%;
  margin-top: 20px;
`;

export const SelectForm = styled.select`
  padding: 10px 15px;
  border-radius: 5px;
  border: 1px solid #90a8d0;
  min-width: 0;
  width: 100%;
  margin-top: 20px;
`;

export const Button = styled(ButtonBase)`
  background: #ffe44d !important;
  color: #0a1932 !important;
  padding: 10px 20px !important;
  font-size: 15px !important;
  font-weight: bold !important;
  text-align: center !important;
  border-radius: 5px !important;
  text-transform: uppercase !important;
  -webkit-box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);
  -moz-box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);
  box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);
  margin-top: 40px !important;

  &:focus {
    outline: 0;
  }

  @media only screen and (max-width: 768px) {
    font-size: 12px !important;
  }
`;

export const Form = styled.form`
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
`;

export const BottomLabel = styled.div`
  width: 100%;
`;
