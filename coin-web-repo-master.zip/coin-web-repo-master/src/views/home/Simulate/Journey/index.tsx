import React, { Suspense } from 'react';

import { Route, Switch, useLocation } from 'react-router-dom';

import routes from '../../../../routes/journey.routes';

import {
  Container,
  Section2,
  Section2Description,
  Section2Title,
  Numbers,
  Number,
} from './styles';

const loading = (
  <div className="pt-3 text-center">
    <div className="sk-spinner sk-spinner-pulse" />
  </div>
);

const Simulate: React.FC = () => {
  const location = useLocation();

  return (
    <>
      <Container>
        <Section2>
          <Section2Title>
            Faça uma simulação de empréstimo descomplicada
          </Section2Title>

          <Section2Description>
            Precisamos de poucas informações sobre você para te mostrar como o
            nosso crédito cabe no seu bolso.
          </Section2Description>
        </Section2>
        <Numbers>
          <Number
            active={
              location.pathname === '/simulacao/egi' ||
              location.pathname === '/simulacao/egv' ||
              location.pathname === '/simulacao/fi'
            }
          >
            1
          </Number>
          <Number active={location.pathname === '/simulacao/dados'}>2</Number>
          <Number active={location.pathname === '/simulacao/resultado'}>
            3
          </Number>
        </Numbers>

        <Suspense fallback={loading}>
          <Switch>
            {routes.map((route, idx) => {
              return (
                route.component && (
                  <Route
                    key={idx.toString()}
                    path={route.path}
                    exact={route.exact}
                    name={route.name}
                    component={route.component}
                  />
                )
              );
            })}
          </Switch>
        </Suspense>
      </Container>
    </>
  );
};

export default Simulate;
