import styled from 'styled-components';

export const Container = styled.div`
  width: 100%;
`;

export const Section2 = styled.div`
  padding: 100px 200px;
  max-width: 1280px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  align-items: center;

  @media only screen and (max-width: 1024px) {
    padding: 100px 50px;
  }

  @media only screen and (max-width: 768px) {
    padding: 70px;
  }

  @media only screen and (max-width: 425px) {
    padding: 35px;
  }
`;

export const Section2Title = styled.div`
  color: #0a1932;
  font-size: 32px;
  font-weight: bold;
  text-align: center;

  @media only screen and (max-width: 768px) {
    font-size: 24px;
  }
`;

export const Section2Description = styled.div`
  color: #0a1932;
  font-size: 18px;
  margin-top: 20px;
  text-align: center;

  @media only screen and (max-width: 768px) {
    font-size: 15px;
  }
`;

export const Numbers = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 70px;

  @media only screen and (max-width: 768px) {
    margin-bottom: 40px;
  }
`;

type NumberProps = {
  active?: boolean;
};

export const Number = styled.div<NumberProps>`
  width: 50px;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 5px;
  border: 1px solid ${props => (props.active ? '#FFE44D' : '#0a1932')};
  background: ${props => (props.active ? '#FFE44D' : '#fff')};
  font-size: 32px;
  font-weight: bold;
  color: #0a1932;
  cursor: pointer;

  & + & {
    margin-left: 50px;
  }
`;
