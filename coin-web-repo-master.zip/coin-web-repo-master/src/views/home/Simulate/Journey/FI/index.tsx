import React from 'react';

import { useHistory } from 'react-router-dom';

import { Formik } from 'formik';

import { useAsync } from 'react-async';

import { withStyles } from '@material-ui/core';
import Grid from '@material-ui/core/Grid';
import Slider from '@material-ui/core/Slider';

import { useSetRecoilState } from 'recoil';

import * as Yup from 'yup';

import api from '../../../../../services/api';

import { SimulateId } from '../../../../../store/atoms/Simulate';

import {
  Container,
  Price,
  Title,
  Select,
  InputMask,
  Button,
  Form,
  SelectForm,
} from './styles';

const CustomSlider = withStyles({
  root: {
    color: '#A9AEB7',
    height: 8,
  },
  thumb: {
    height: 24,
    width: 24,
    backgroundColor: '#FFE44D',
    marginTop: -11,
    marginLeft: -12,
    '&:focus, &:hover, &$active': {
      boxShadow: 'inherit',
    },
  },
  active: {},
  valueLabel: {
    left: 'calc(-50% + 4px)',
  },
  track: {
    height: 1,
  },
  rail: {
    height: 1,
  },
})(Slider);

interface IloadClients {
  properties: Array<{
    id: string;
    name: string;
  }>;
}

const loadClients = async (): Promise<IloadClients> => {
  const { data: properties } = await api.get(`/properties`);

  return { properties };
};

const EGI1: React.FC = (): any => {
  const history = useHistory();

  const setSimulateId = useSetRecoilState(SimulateId);

  const [value, setValue] = React.useState<number>(500000);

  const handleChange = (event: any, newValue: number | number[]) => {
    setValue(newValue as number);
  };

  type initialValuesProps = {
    cep: string;
    property_id: string;
    months: number;
  };

  const initialValues: initialValuesProps = {
    cep: '',
    property_id: '',
    months: 18,
  };

  const { data, error, isPending } = useAsync({
    promiseFn: loadClients,
  });
  if (isPending) return null;
  if (error) return `Something went wrong: ${error.message}`;
  if (data) {
    return (
      <Container>
        <Title>De quanto você precisa?</Title>
        <Grid container spacing={2}>
          <Grid item>MIN</Grid>
          <Grid item xs>
            <CustomSlider
              value={value}
              onChange={handleChange}
              aria-labelledby="continuous-slider"
              min={1000}
              max={1000000}
              step={1000}
            />
          </Grid>
          <Grid item>MÁX</Grid>
        </Grid>
        <Price>
          {new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL',
          }).format(value)}
        </Price>

        <Title>Em quantos meses quer pagar o seu empréstimo?</Title>

        <Formik
          initialValues={initialValues}
          validateOnBlur={false}
          validateOnChange={false}
          validationSchema={Yup.object().shape({
            cep: Yup.string().required('Campo obrigatório'),
            property_id: Yup.string().required('Campo obrigatório'),
            months: Yup.number().required('Campo obrigatório'),
          })}
          onSubmit={async (values, actions) => {
            const body = {
              ...values,
              amount: value,
              status_id: process.env.REACT_APP_STATUS_PENDING_ID,
              type_id: process.env.REACT_APP_TYPE_FI_ID,
            };

            const { data: simulate } = await api.post('/customers', body);

            setSimulateId(simulate.id);

            history.push('/simulacao/dados');

            actions.setSubmitting(false);
          }}
        >
          {props => (
            <Form onSubmit={props.handleSubmit}>
              <Select
                name="months"
                id="months"
                onChange={props.handleChange}
                onBlur={props.handleBlur}
                value={props.values.months}
              >
                <option value={18}>18 Meses</option>
                <option value={24}>24 Meses</option>
                <option value={30}>30 Meses</option>
                <option value={36}>36 Meses</option>
                <option value={42}>42 Meses</option>
                <option value={48}>48 Meses</option>
                <option value={54}>54 Meses</option>
                <option value={60}>60 Meses</option>
                <option value={72}>72 Meses</option>
                <option value={84}>80 Meses</option>
                <option value={96}>92 Meses</option>
                <option value={108}>108 Meses</option>
                <option value={120}>120 Meses</option>
                <option value={132}>132 Meses</option>
                <option value={144}>144 Meses</option>
                <option value={156}>156 Meses</option>
                <option value={168}>168 Meses</option>
                <option value={180}>180 Meses</option>
                <option value={192}>192 Meses</option>
                <option value={204}>204 Meses</option>
                <option value={216}>216 Meses</option>
                <option value={228}>228 Meses</option>
                <option value={240}>240 Meses</option>
              </Select>

              <SelectForm
                name="property_id"
                id="property_id"
                onChange={props.handleChange}
                onBlur={props.handleBlur}
                value={props.values.property_id}
              >
                <option>Selecionar</option>
                {data.properties.map(property => (
                  <option key={property.id} value={property.id}>
                    {property.name}
                  </option>
                ))}
              </SelectForm>
              <InputMask
                placeholder="CEP"
                onChange={props.handleChange}
                onBlur={props.handleBlur}
                value={props.values.cep}
                error={!!props.errors.cep}
                name="cep"
                mask="99999-999"
                maskChar=" "
              />
              <Button type="submit">Próximo passo</Button>
            </Form>
          )}
        </Formik>
      </Container>
    );
  }

  return null;
};

export default EGI1;
