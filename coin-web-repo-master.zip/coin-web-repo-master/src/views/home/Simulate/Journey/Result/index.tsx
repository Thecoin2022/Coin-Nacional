import React from 'react';
import { useAsync } from 'react-async';

import { useHistory } from 'react-router-dom';

import { useRecoilValue } from 'recoil';

import api from '../../../../../services/api';

import { SimulateId } from '../../../../../store/atoms/Simulate';

import {
  Container,
  Section,
  Title,
  Description,
  Price,
  PriceText,
  PriceValue,
  PriceDescription,
  Badge,
  BadgeDescription,
  SectionDescription,
  Button,
  Section2,
  ButtonRemake,
} from './styles';

interface IloadClients {
  customer: {
    amount: number;
    months: number;
    type_id: string;
  };
}

const loadClients = async ({ simulateId }: any): Promise<IloadClients> => {
  const { data: customer } = await api.get(`/customers/${simulateId}`);

  return { customer };
};

const EGI3: React.FC = (): any => {
  const history = useHistory();

  const simulateId = useRecoilValue(SimulateId);

  if (!simulateId) {
    history.push('/simulacao');
  }

  const { data, error, isPending } = useAsync({
    promiseFn: loadClients,
    simulateId,
  });

  const percent = React.useMemo(() => {
    if (data?.customer.type_id === process.env.REACT_APP_TYPE_EGI_ID) {
      return '0.75%';
    }
    if (data?.customer.type_id === process.env.REACT_APP_TYPE_EGV_ID) {
      return '1.49%';
    }

    return '0.79%';
  }, [data]);

  const rate = React.useMemo(() => {
    if (data?.customer.type_id === process.env.REACT_APP_TYPE_EGI_ID) {
      return 1.0075;
    }
    if (data?.customer.type_id === process.env.REACT_APP_TYPE_EGV_ID) {
      return 1.0149;
    }

    return 1.0079;
  }, [data]);

  if (isPending) return null;
  if (error) return `Something went wrong: ${error.message}`;
  if (data) {
    return (
      <>
        <Container>
          <Title>Detalhes da Simulação</Title>
          <Description>
            Os detalhes da simulação também foram enviados no seu e-mail.
          </Description>
        </Container>
        <Price>
          <PriceText>R$</PriceText>
          <PriceValue>
            *
            {new Intl.NumberFormat('pt-BR').format(
              (data.customer.amount / data.customer.months) * rate,
            )}
          </PriceValue>
        </Price>
        <PriceDescription>é o valor da sua primeira parcela.</PriceDescription>
        <Section>
          <Badge>VALOR DO CRÉDITO</Badge>
          <BadgeDescription>
            R$ {new Intl.NumberFormat('pt-BR').format(data.customer.amount)}
          </BadgeDescription>
          <Badge>PRAZO DE PAGAMENTO</Badge>
          <BadgeDescription>{data.customer.months} meses</BadgeDescription>
          <SectionDescription>
            A taxa mensal de juros é {percent} + IPCA, portanto, seu valor de
            parcela pode ser diferente desta simulação.
          </SectionDescription>
        </Section>

        <Section2>
          <ButtonRemake
            onClick={async () => {
              history.push('/simulacao');
            }}
          >
            Refazer simulação
          </ButtonRemake>
          <Button
            onClick={async () => {
              await api.patch(`/customers/${simulateId}`, {
                step: 3,
              });
              history.push('/simulacao/complemento');
            }}
          >
            Solicitar Proposta
          </Button>
        </Section2>
      </>
    );
  }

  return null;
};

export default EGI3;
