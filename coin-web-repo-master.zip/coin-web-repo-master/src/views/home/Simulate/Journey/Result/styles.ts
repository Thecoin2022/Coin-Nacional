import styled from 'styled-components';
import ButtonBase from '@material-ui/core/ButtonBase';

export const Container = styled.div`
  width: 650px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  align-items: center;

  @media only screen and (max-width: 768px) {
    width: 100%;
  }
`;

export const Section2 = styled.div`
  width: 100%;
  padding: 40px 20px;
  background: #fff;
  display: flex;
  flex-direction: column;
  align-items: center;
`;

export const Button = styled(ButtonBase)`
  background: #ffe44d !important;
  color: #0a1932 !important;
  padding: 10px 20px !important;
  font-size: 15px !important;
  font-weight: bold !important;
  text-align: center !important;
  border-radius: 5px !important;
  text-transform: uppercase !important;
  -webkit-box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);
  -moz-box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);
  box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);

  &:focus {
    outline: 0;
  }

  @media only screen and (max-width: 768px) {
    font-size: 12px !important;
  }
`;

export const ButtonRemake = styled(ButtonBase)`
  background: #0a1932 !important;
  color: #fff !important;
  padding: 10px 20px !important;
  font-size: 15px !important;
  font-weight: bold !important;
  text-align: center !important;
  border-radius: 5px !important;
  text-transform: uppercase !important;
  margin-bottom: 20px !important;

  &:focus {
    outline: 0;
  }

  @media only screen and (max-width: 768px) {
    font-size: 12px !important;
  }
`;

export const Section = styled.div`
  width: 100%;
  padding: 40px 20px;
  background: #ffe44d;
  display: flex;
  flex-direction: column;
  align-items: center;
`;

export const Title = styled.div`
  width: 100%;
  text-align: center;
  color: #0a1932;
  font-size: 32px;
  font-weight: bold;
  padding: 0 20px;

  @media only screen and (max-width: 768px) {
    font-size: 24px;
  }
`;

export const Description = styled.div`
  width: 100%;
  text-align: center;
  color: #0a1932;
  font-size: 18px;
  margin-bottom: 20px;
  padding: 0 20px;
`;

export const Price = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 40px;
`;

export const PriceText = styled.div`
  color: #0a1932;
  font-size: 18px;
  font-weight: bold;
`;

export const PriceValue = styled.div`
  color: #0a1932;
  font-size: 32px;
  font-weight: bold;
  background: #ffe44d;
  padding: 5px 20px;
  border-radius: 5px;
  margin-left: 5px;
`;

export const PriceDescription = styled.div`
  width: 100%;
  text-align: center;
  color: #0a1932;
  font-size: 15px;
  margin-top: 10px;
  margin-bottom: 20px;
`;

export const Badge = styled.div`
  color: #fff;
  font-size: 18px;
  font-weight: bold;
  background: #0a1932;
  text-transform: uppercase;
  padding: 5px 20px;
  border-radius: 5px;
`;

export const BadgeDescription = styled.div`
  text-align: center;
  color: #0a1932;
  font-size: 18px;
  font-weight: bold;
  margin-top: 10px;
  margin-bottom: 25px;
`;

export const SectionDescription = styled.div`
  text-align: center;
  color: #0a1932;
  font-size: 15px;
  max-width: 700px;
`;
