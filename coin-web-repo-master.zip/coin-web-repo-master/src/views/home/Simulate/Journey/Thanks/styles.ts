import styled from 'styled-components';

export const Container = styled.div`
  width: 100%;
  max-width: 1280px;
  margin: 0 auto;
`;

export const Section2 = styled.div`
  padding: 100px 200px;
  display: flex;
  flex-direction: column;
  align-items: center;

  @media only screen and (max-width: 1024px) {
    padding: 100px 150px;
  }

  @media only screen and (max-width: 768px) {
    padding: 70px;
  }

  @media only screen and (max-width: 425px) {
    padding: 35px;
  }
`;

export const Title = styled.div`
  color: #0a1932;
  font-size: 48px;
  font-weight: bold;
  text-align: center;

  @media only screen and (max-width: 768px) {
    font-size: 36px;
  }
`;

export const Section2Title = styled.div`
  color: #0a1932;
  font-size: 32px;
  font-weight: bold;
  text-align: center;

  @media only screen and (max-width: 768px) {
    font-size: 24px;
  }
`;

export const Section2Description = styled.div`
  color: #0a1932;
  font-size: 18px;
  margin-top: 20px;
  text-align: center;
  margin-bottom: 40px;

  @media only screen and (max-width: 768px) {
    font-size: 15px;
  }
`;
