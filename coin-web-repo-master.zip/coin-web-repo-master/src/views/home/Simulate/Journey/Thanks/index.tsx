import React from 'react';

import {
  Container,
  Section2,
  Section2Description,
  Section2Title,
  Title,
} from './styles';

const Simulate: React.FC = () => {
  return (
    <>
      <Container>
        <Section2>
          <Title>Obrigado!</Title>

          <Section2Title>Seus dados foram enviados com sucesso.</Section2Title>

          <Section2Description>
            Agora faremos a análise do seu pedido de crédito e em breve
            entraremos em contato para informar o resultado da sua solicitação.
          </Section2Description>
          <img src="/simulatethanks.svg" alt="obrigado" />
        </Section2>
      </Container>
    </>
  );
};

export default Simulate;
