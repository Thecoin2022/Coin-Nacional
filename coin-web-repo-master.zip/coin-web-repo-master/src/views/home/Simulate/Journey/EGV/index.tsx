import React from 'react';

import { useHistory } from 'react-router-dom';

import { Formik } from 'formik';

import { withStyles } from '@material-ui/core';
import Grid from '@material-ui/core/Grid';
import Slider from '@material-ui/core/Slider';

import { useSetRecoilState } from 'recoil';

import * as Yup from 'yup';

import { SimulateId } from '../../../../../store/atoms/Simulate';

import {
  Container,
  Price,
  Title,
  Select,
  InputMask,
  Button,
  Form,
} from './styles';
import api from '../../../../../services/api';

const CustomSlider = withStyles({
  root: {
    color: '#A9AEB7',
    height: 8,
  },
  thumb: {
    height: 24,
    width: 24,
    backgroundColor: '#FFE44D',
    marginTop: -11,
    marginLeft: -12,
    '&:focus, &:hover, &$active': {
      boxShadow: 'inherit',
    },
  },
  active: {},
  valueLabel: {
    left: 'calc(-50% + 4px)',
  },
  track: {
    height: 1,
  },
  rail: {
    height: 1,
  },
})(Slider);

const EGI1: React.FC = () => {
  const history = useHistory();

  const setSimulateId = useSetRecoilState(SimulateId);

  const [value, setValue] = React.useState<number>(77500);

  const handleChange = (event: any, newValue: number | number[]) => {
    setValue(newValue as number);
  };

  type initialValuesProps = {
    cep: string;
    vehicle_year: string;
    months: number;
  };

  const initialValues: initialValuesProps = {
    cep: '',
    vehicle_year: '',
    months: 18,
  };

  return (
    <Container>
      <Title>De quanto você precisa?</Title>
      <Grid container spacing={2}>
        <Grid item>MIN</Grid>
        <Grid item xs>
          <CustomSlider
            value={value}
            onChange={handleChange}
            aria-labelledby="continuous-slider"
            min={5000}
            max={150000}
            step={1000}
          />
        </Grid>
        <Grid item>MÁX</Grid>
      </Grid>
      <Price>
        {new Intl.NumberFormat('pt-BR', {
          style: 'currency',
          currency: 'BRL',
        }).format(value)}
      </Price>

      <Title>Em quantos meses quer pagar o seu empréstimo?</Title>

      <Formik
        initialValues={initialValues}
        validateOnBlur={false}
        validateOnChange={false}
        validationSchema={Yup.object().shape({
          cep: Yup.string().required('Campo obrigatório'),
          vehicle_year: Yup.string().required('Campo obrigatório'),
          months: Yup.number().required('Campo obrigatório'),
        })}
        onSubmit={async (values, actions) => {
          const body = {
            ...values,
            amount: value,
            status_id: process.env.REACT_APP_STATUS_PENDING_ID,
            type_id: process.env.REACT_APP_TYPE_EGV_ID,
          };

          const { data: simulate } = await api.post('/customers', body);

          setSimulateId(simulate.id);

          history.push('/simulacao/dados');

          actions.setSubmitting(false);
        }}
      >
        {props => (
          <Form onSubmit={props.handleSubmit}>
            <Select
              name="months"
              id="months"
              onChange={props.handleChange}
              onBlur={props.handleBlur}
              value={props.values.months}
            >
              <option value={18}>18 Meses</option>
              <option value={24}>24 Meses</option>
              <option value={30}>30 Meses</option>
              <option value={36}>36 Meses</option>
              <option value={42}>42 Meses</option>
              <option value={48}>48 Meses</option>
              <option value={54}>54 Meses</option>
              <option value={60}>60 Meses</option>
            </Select>

            <InputMask
              placeholder="Ano do veículo"
              onChange={props.handleChange}
              onBlur={props.handleBlur}
              value={props.values.vehicle_year}
              error={!!props.errors.vehicle_year}
              name="vehicle_year"
              mask="9999"
              maskChar=" "
            />
            <InputMask
              placeholder="CEP"
              onChange={props.handleChange}
              onBlur={props.handleBlur}
              value={props.values.cep}
              error={!!props.errors.cep}
              name="cep"
              mask="99999-999"
              maskChar=" "
            />
            <Button type="submit">Próximo passo</Button>
          </Form>
        )}
      </Formik>
    </Container>
  );
};

export default EGI1;
