import React from 'react';

import { useHistory } from 'react-router-dom';

import { Formik } from 'formik';

import { useRecoilValue } from 'recoil';

import * as Yup from 'yup';

import api from '../../../../../services/api';

import { SimulateId } from '../../../../../store/atoms/Simulate';

import {
  Container,
  Title,
  Button,
  Form,
  Description,
  Label,
  InputRadio,
  InputRadioText,
  InputMask,
} from './styles';

const EGI1: React.FC = () => {
  const history = useHistory();

  const simulateId = useRecoilValue(SimulateId);

  type initialValuesProps = {
    income: string;
    has_property: string;
  };

  const initialValues: initialValuesProps = {
    income: '',
    has_property: 'a',
  };

  if (!simulateId) {
    history.push('/simulacao');
  }

  return (
    <Container>
      <Title>Dados complementares</Title>
      <Description>
        Para seguirmos com seu pedido de crédito, precisamos de mais algumas
        informações sobre você e seu imóvel.
      </Description>

      <Formik
        initialValues={initialValues}
        validateOnBlur={false}
        validateOnChange={false}
        validationSchema={Yup.object().shape({
          income: Yup.string().required('Campo obrigatório'),
        })}
        onSubmit={async (values, actions) => {
          await api.patch(`/customers/${simulateId}`, {
            income: parseInt(values.income.replace(/[^0-9]/g, ''), 10),
            has_property: values.has_property === 'a',
            step: 4,
          });

          history.push('/simulacao/obrigado');

          actions.setSubmitting(false);
        }}
      >
        {props => (
          <Form onSubmit={props.handleSubmit}>
            <Label>Renda mensal líquida</Label>
            <InputMask
              placeholder="Renda mensal líquida"
              onChange={props.handleChange}
              onBlur={props.handleBlur}
              value={props.values.income}
              error={!!props.errors.income}
              name="income"
              mask="R$ 999999999"
              maskChar=" "
            />

            <Label>Tem propriedade ?</Label>
            <InputRadio>
              <input
                type="radio"
                name="has_property"
                value="a"
                checked={props.values.has_property === 'a'}
                onChange={() => props.setFieldValue('has_property', 'a')}
              />
              <InputRadioText>Sim</InputRadioText>
            </InputRadio>
            <InputRadio>
              <input
                type="radio"
                name="has_property"
                value="b"
                checked={props.values.has_property === 'b'}
                onChange={() => props.setFieldValue('has_property', 'b')}
              />
              <InputRadioText>Não</InputRadioText>
            </InputRadio>
            <Button type="submit">SOLICITAR FINANCIAMENTO</Button>
          </Form>
        )}
      </Formik>
    </Container>
  );
};

export default EGI1;
