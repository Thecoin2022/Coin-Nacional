import React from 'react';

import { useHistory } from 'react-router-dom';

import {
  Container,
  Section2,
  Section2Description,
  Section2Title,
  Button,
  Buttons,
  Section3,
  Section3Title,
} from './styles';

const Simulate: React.FC = () => {
  const history = useHistory();

  return (
    <>
      <Container>
        <Section2>
          <Section2Title>
            Faça uma simulação de empréstimo descomplicada
          </Section2Title>

          <Section2Description>
            Precisamos de poucas informações sobre você para te mostrar como o
            nosso crédito cabe no seu bolso.
          </Section2Description>
        </Section2>
      </Container>

      <Section3>
        <Section3Title>Do que você precisa?</Section3Title>

        <Buttons>
          <Button
            onClick={() => {
              history.push('/simulacao/egi');
            }}
          >
            Empréstimo com Garantia de Imóvel
          </Button>
          <Button
            onClick={() => {
              history.push('/simulacao/egv');
            }}
          >
            Empréstimo com Garantía de Veículo
          </Button>
          <Button
            onClick={() => {
              history.push('/simulacao/fi');
            }}
          >
            Financiamento Imobiliário
          </Button>
        </Buttons>
      </Section3>
    </>
  );
};

export default Simulate;
