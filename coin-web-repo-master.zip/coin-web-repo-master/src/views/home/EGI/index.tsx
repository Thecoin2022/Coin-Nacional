import React from 'react';

import { useHistory } from 'react-router-dom';

import { useMediaQuery } from '@material-ui/core';

import {
  Container,
  Head,
  Image,
  Left,
  Title,
  ButtonSimulate1,
  Description,
  Button,
  Buttons,
  Section3,
  Section3Title,
  ButtonContainer,
  Section,
  Left2,
  Image3,
  Description2,
  Title3,
  SectionTitle,
} from './styles';

const About: React.FC = () => {
  const history = useHistory();

  const biggerThan768 = useMediaQuery('(min-width:768px)');

  const timeline = React.useMemo(() => {
    if (biggerThan768) return '/timeline2.svg';
    return '/timeline3.svg';
  }, [biggerThan768]);

  return (
    <>
      <Container>
        <Head>
          <Left>
            <Title>Empréstimo com garantia de imóvel</Title>
            <Description>
              Com as menores taxas de juros do mercado. Home Equity, é a
              modalidade de empréstimo que utiliza o seu imóvel como garantia de
              pagamento, resultando em juros a partir de 0,75% +IPCA.
            </Description>
            <ButtonContainer>
              <ButtonSimulate1
                onClick={() => {
                  history.push('/simulacao/egi');
                }}
              >
                Faça uma simulação
              </ButtonSimulate1>
            </ButtonContainer>
          </Left>
          <Image src="/egi.svg" alt="sobre" />
        </Head>

        <Section>
          <Image3 src="/emp.svg" alt="sobre" />
          <Left2>
            <Title3>Como funciona ?</Title3>
            <Description2>
              O empréstimo utiliza o seu imóvel como garantia de pagamento. Você
              continua sendo o dono do seu imóvel, não se preocupe. No contrato,
              o termo alienação fiduciária indica que o imóvel está sendo usado
              como garantia, o que lhe permite conseguir até 60% do valor do bem
              com taxas de juros a partir de 0,75% até 240 messes para pagar.
              Crédito rápido, saudável e seguro.
            </Description2>
          </Left2>
        </Section>

        <SectionTitle>
          A contratação é simples e pode ser feita em um processo seguro e 100%
          online
        </SectionTitle>

        <Image3 src={timeline} alt="sobre" />
      </Container>
      <Section3>
        <Section3Title>
          O primeiro passo para atingir seus objetivos
        </Section3Title>

        <Buttons>
          <div />
          <Button
            onClick={() => {
              history.push('/simulacao/egi');
            }}
          >
            FAÇA UMA SIMULAÇÃO
          </Button>
          <div />
        </Buttons>
      </Section3>
    </>
  );
};

export default About;
