import styled from 'styled-components';
import ButtonBase from '@material-ui/core/ButtonBase';

export const Container = styled.div`
  flex: 1;
  width: 100%;
  max-width: 1280px;
  margin: 0 auto;
`;

export const Body = styled.div`
  padding: 0 20px;
`;

export const Image = styled.img`
  width: 100%;
  margin-top: 100px;

  @media only screen and (max-width: 768px) {
    margin-top: 40px;
  }
`;

export const Title = styled.div`
  font-size: 32px;
  color: #0a1932;
  font-weight: bold;

  @media only screen and (max-width: 1024px) {
    text-align: center;
  }

  @media only screen and (max-width: 768px) {
    font-size: 24px;
  }
`;

export const Description = styled.div`
  font-size: 18px;
  color: #0a1932;
  margin-bottom: 10px;

  @media only screen and (max-width: 1024px) {
    text-align: center;
  }
`;

export const Head = styled.div`
  max-width: 700px;
  margin-top: 70px;
  margin-bottom: 40px;

  @media only screen and (max-width: 1024px) {
    margin-left: auto;
    margin-top: 40px;
    margin-right: auto;
    padding: 0 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
  }
`;

export const Section1 = styled.div`
  padding: 100px 0;
  background: #0a1932;
  width: 100%;
`;

export const Section1Title = styled.div`
  font-size: 32px;
  color: #fff;
  font-weight: bold;
  text-align: center;
  padding: 0 20px;

  @media only screen and (max-width: 768px) {
    font-size: 24px;
  }
`;

export const Section1TitleHighlight = styled.span`
  font-size: 32px;
  color: #ffe44d;
  font-weight: bold;

  @media only screen and (max-width: 768px) {
    font-size: 24px;
  }
`;

export const Section1Body = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-gap: 100px;
  margin-top: 70px;

  @media only screen and (max-width: 1024px) {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 0 20px;
    grid-gap: 0;
  }
`;

export const Section1Item = styled.div`
  display: flex;
  align-items: flex-start;

  @media only screen and (max-width: 1024px) {
    max-width: 500px;

    & + & {
      margin-top: 50px;
    }
  }
`;

export const Section1ItemIcon = styled.div`
  width: 80px;
`;

export const Section1ItemTexts = styled.div`
  flex: 1;
  margin-left: 20px;
`;

export const Section1ItemTitle = styled.div`
  font-size: 24px;
  font-weight: bold;
  color: #fff;

  @media only screen and (max-width: 1024px) {
    font-size: 18px;
  }
`;

export const Section1ItemDescription = styled.div`
  font-size: 18px;
  color: #fff;
  margin-top: 20px;

  @media only screen and (max-width: 1024px) {
    font-size: 15px;
  }
`;

export const Section2 = styled.div`
  margin: 70px 20px;
`;

export const Section2Title = styled.div`
  font-size: 32px;
  color: #0a1932;
  font-weight: bold;
  text-align: center;

  @media only screen and (max-width: 768px) {
    font-size: 24px;
  }
`;

export const Section2Description = styled.div`
  font-size: 18px;
  color: #0a1932;
  text-align: center;
`;

export const Section2Body = styled.div`
  margin-top: 70px;
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 1fr;
  grid-row-gap: 50px;

  @media only screen and (max-width: 1024px) {
    grid-template-columns: 1fr 1fr;
  }

  @media only screen and (max-width: 606px) {
    grid-template-columns: 1fr;
  }
`;

export const Section2Item = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
`;

export const Button = styled(ButtonBase)`
  background: #ffe44d !important;
  color: #0a1932 !important;
  padding: 15px 20px !important;
  font-size: 15px !important;
  font-weight: bold !important;
  text-align: center !important;
  border-radius: 5px !important;
  text-transform: uppercase !important;
  -webkit-box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);
  -moz-box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);
  box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);

  &:focus {
    outline: 0;
  }

  @media only screen and (max-width: 768px) {
    font-size: 12px !important;
  }
`;
