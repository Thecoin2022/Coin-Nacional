import React from 'react';

import { useHistory } from 'react-router-dom';

import {
  Container,
  Body,
  Image,
  Description,
  Title,
  Head,
  Section1,
  Section1Title,
  Section1TitleHighlight,
  Section1Body,
  Section1Item,
  Section1ItemTexts,
  Section1ItemTitle,
  Section1ItemDescription,
  Section1ItemIcon,
  Section2,
  Section2Body,
  Section2Description,
  Section2Title,
  Section2Item,
  Button,
} from './styles';

const Partners: React.FC = () => {
  const history = useHistory();

  return (
    <>
      <Container>
        <Image src="/partners.svg" alt="parceiros" />
        <Body>
          <Head>
            <Title>Seja um parceiro COIN</Title>
            <Description>
              Faça parte do nosso programa de parceiros: você indica a opção
              certa de empréstimo, conquista o seu cliente e garante uma
              comissão.
            </Description>
            <Button
              onClick={() => {
                history.push('/parceiro');
              }}
            >
              Preencher formulário
            </Button>
          </Head>
        </Body>
      </Container>
      <Section1>
        <Container>
          <Section1Title>
            Por que ser um
            <Section1TitleHighlight> parceiro COIN?</Section1TitleHighlight>
          </Section1Title>
          <Section1Body>
            <Section1Item>
              <Section1ItemIcon>
                <img src="/partners2.svg" alt="parceiro" />
              </Section1ItemIcon>
              <Section1ItemTexts>
                <Section1ItemTitle>
                  Você conquista o cliente com uma solução de crédito saudável
                </Section1ItemTitle>
                <Section1ItemDescription>
                  Taxas a partir de 0,75% ao mês + IPCA e prazos de até 240
                  meses.
                </Section1ItemDescription>
              </Section1ItemTexts>
            </Section1Item>
            <Section1Item>
              <Section1ItemIcon>
                <img src="/partners5.svg" alt="parceiro" />
              </Section1ItemIcon>
              <Section1ItemTexts>
                <Section1ItemTitle>
                  Gerencie suas indicações e conte com a gente
                </Section1ItemTitle>
                <Section1ItemDescription>
                  Acompanhe suas indicações na nossa plataforma exclusiva e
                  garanta todo o apoio para fazer divulgação e tirar suas
                  dúvidas.
                </Section1ItemDescription>
              </Section1ItemTexts>
            </Section1Item>
            <Section1Item>
              <Section1ItemIcon>
                <img src="/partners4.svg" alt="parceiro" />
              </Section1ItemIcon>
              <Section1ItemTexts>
                <Section1ItemTitle>
                  Para descomplicar, ninguém melhor do que a gente
                </Section1ItemTitle>
                <Section1ItemDescription>
                  O processo é 100% online e disponibilizamos o crédito a partir
                  de 10 dias para o cliente.
                </Section1ItemDescription>
              </Section1ItemTexts>
            </Section1Item>
            <Section1Item>
              <Section1ItemIcon>
                <img src="/partners3.svg" alt="parceiro" />
              </Section1ItemIcon>
              <Section1ItemTexts>
                <Section1ItemTitle>Aumente sua receita</Section1ItemTitle>
                <Section1ItemDescription>
                  Receba uma comissão para cada contrato de crédito fechado
                </Section1ItemDescription>
              </Section1ItemTexts>
            </Section1Item>
          </Section1Body>
        </Container>
      </Section1>
      <Container>
        <Body>
          <Section2>
            <Section2Title>Nossos parceiros</Section2Title>
            <Section2Description>
              Conheça quem está promovendo a mudança da economia com a gente.
            </Section2Description>
            <Section2Body>
              <Section2Item>
                <img src="/def.svg" alt="parceiro" />
              </Section2Item>
              <Section2Item>
                <img src="/def.svg" alt="parceiro" />
              </Section2Item>
              <Section2Item>
                <img src="/def.svg" alt="parceiro" />
              </Section2Item>
              <Section2Item>
                <img src="/def.svg" alt="parceiro" />
              </Section2Item>
            </Section2Body>
          </Section2>
        </Body>
      </Container>
    </>
  );
};

export default Partners;
