import React from 'react';

import { useHistory } from 'react-router-dom';

import { useMediaQuery } from '@material-ui/core';

import {
  Container,
  Head,
  Image,
  Left,
  Title,
  ButtonSimulate1,
  Description,
  Button,
  Buttons,
  Section3,
  Section3Title,
  ButtonContainer,
  Section,
  Left2,
  Image3,
  Description2,
  Title3,
  SectionTitle,
} from './styles';

const About: React.FC = () => {
  const history = useHistory();

  const biggerThan768 = useMediaQuery('(min-width:768px)');

  const timeline = React.useMemo(() => {
    if (biggerThan768) return '/timeline6.svg';
    return '/timeline7.svg';
  }, [biggerThan768]);

  return (
    <>
      <Container>
        <Head>
          <Left>
            <Title>Te ajudamos a conquistar o sonho da casa própria</Title>
            <Description>
              Se você precisa comprar um imóvel, novo ou usado, com mais
              flexibilidade no financiamento, nós temos o meio de tornar o seu
              sonho realidade de um jeito fácil e que cabe no seu bolso.
            </Description>
            <ButtonContainer>
              <ButtonSimulate1
                onClick={() => {
                  history.push('/simulacao/fi');
                }}
              >
                Faça uma simulação
              </ButtonSimulate1>
            </ButtonContainer>
          </Left>
          <Image src="/fi.svg" alt="sobre" />
        </Head>

        <Section>
          <Image3 src="/fi2.svg" alt="sobre" />
          <Left2>
            <Title3>Como funciona o financiamento imobiliário?</Title3>
            <Description2>
              Financiamos até 70% do valor do seu imóvel em prestações suaves e
              com o tempo que melhor te atender, aqui você tem as melhores taxas
              do mercado com uma análise simples e uma liberação rápida, tudo
              para que você realize o seu sonho da casa própria com segurança e
              conforto .
            </Description2>
          </Left2>
        </Section>

        <SectionTitle>
          O financiamento com a Coin é simples e feito em um processo seguro e
          100% online
        </SectionTitle>

        <Image3 src={timeline} alt="sobre" />
      </Container>
      <Section3>
        <Section3Title>
          O primeiro passo para atingir seus objetivos
        </Section3Title>

        <Buttons>
          <div />
          <Button
            onClick={() => {
              history.push('/simulacao/fi');
            }}
          >
            FAÇA UMA SIMULAÇÃO
          </Button>
          <div />
        </Buttons>
      </Section3>
    </>
  );
};

export default About;
