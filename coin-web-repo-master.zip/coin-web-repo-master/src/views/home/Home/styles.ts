import styled from 'styled-components';
import ButtonBase from '@material-ui/core/ButtonBase';

export const Container = styled.div`
  width: 100%;
  max-width: 1280px;
  margin: 0 auto;
`;

export const Header = styled.div`
  position: relative;
  z-index: 1;

  @media only screen and (max-width: 768px) {
    margin-bottom: 200px;
  }

  @media only screen and (max-width: 521px) {
    margin-bottom: 300px;
  }
`;

export const Section1 = styled.div`
  position: relative;
`;

export const Section2 = styled.div`
  position: relative;
  margin-top: 100px;
`;

export const Image = styled.img`
  width: 100%;
`;

export const Image2 = styled.img`
  width: 70%;
  margin-top: -100px;
  margin-left: 40%;

  @media only screen and (max-width: 1024px) {
    margin-top: 100px;
    margin-left: 37%;
    width: 90%;
  }

  @media only screen and (max-width: 425px) {
    margin-top: 200px;
    margin-left: 0;
    width: 100%;
  }
`;

export const Image3 = styled.img`
  width: 80%;
  margin-left: -5%;

  @media only screen and (max-width: 1024px) {
    margin-left: -20%;
    margin-top: 200px;
  }

  @media only screen and (max-width: 768px) {
    margin-left: -28%;
    width: 120%;
  }

  @media only screen and (max-width: 425px) {
    width: 100%;
    margin-left: 0;
    margin-top: 250px;
  }
`;

export const Box1 = styled.div`
  position: absolute;
  bottom: 130px;
  left: 200px;
  width: 430px;

  @media only screen and (max-width: 1300px) {
    left: 85px;
  }

  @media only screen and (max-width: 1024px) {
    left: 85px;
    bottom: 350px;
  }

  @media only screen and (max-width: 768px) {
    width: 100%;
    bottom: 750px;
    left: 0;
    padding: 0 50px;
  }

  @media only screen and (max-width: 612px) {
    bottom: 600px;
  }

  @media only screen and (max-width: 493px) {
    bottom: 450px;
  }

  @media only screen and (max-width: 425px) {
    bottom: 400px;
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  @media only screen and (max-width: 385px) {
    bottom: 300px;
    display: flex;
    flex-direction: column;
    align-items: center;
  }
`;

export const Title1 = styled.div`
  color: #fff;
  font-weight: 800;
  font-size: 35px;

  cursor: pointer;

  &:hover {
    text-decoration: underline;
  }

  @media only screen and (max-width: 1024px) {
    font-size: 24px;
  }

  @media only screen and (max-width: 425px) {
    font-size: 21px;
    text-align: center;
  }
`;

export const Box1Body = styled.div`
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  margin-top: 30px;
  margin-bottom: 20px;

  @media only screen and (max-width: 425px) {
    flex-direction: column;
    align-items: center;
    justify-content: unset;
  }
`;

export const Description1 = styled.div`
  color: #fff;
  font-size: 15px;
  font-weight: 500;

  @media only screen and (min-width: 425px) {
    margin-right: 50px;
  }

  @media only screen and (max-width: 425px) {
    text-align: center;
    margin-bottom: 20px;
  }
`;

export const Box2 = styled.div`
  position: absolute;
  top: 50px;
  right: 50px;
  width: 400px;

  @media only screen and (max-width: 1024px) {
    top: 0px;
  }

  @media only screen and (max-width: 768px) {
    width: 100%;
    top: -150px;
    right: 0;
    padding: 0 100px;
  }

  @media only screen and (max-width: 521px) {
    top: -250px;
    padding: 0 50px;
  }

  @media only screen and (max-width: 493px) {
    bottom: 450px;
  }

  @media only screen and (max-width: 425px) {
    bottom: 400px;
  }
`;

export const Title2 = styled.div`
  color: #0a1932;
  font-weight: 800;
  font-size: 35px;
  text-align: center;
  cursor: pointer;

  &:hover {
    text-decoration: underline;
  }

  @media only screen and (max-width: 1024px) {
    font-size: 24px;
  }

  @media only screen and (max-width: 425px) {
    font-size: 21px;
  }
`;

export const Box2Body = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 30px;
`;

export const Description2 = styled.div`
  color: #0a1932;
  font-size: 15px;
  font-weight: 500;
  text-align: center;
  margin-bottom: 20px;
`;

export const Box3 = styled.div`
  position: absolute;
  top: 150px;
  left: 50px;
  width: 400px;

  @media only screen and (max-width: 1024px) {
    top: 50px;
    width: 100%;
    left: 0;
    padding: 0 100px;
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  @media only screen and (max-width: 560px) {
    padding: 0 50px;
  }

  @media only screen and (max-width: 425px) {
    top: 50px;
  }
`;

export const Title3 = styled.div`
  color: #0a1932;
  font-weight: 800;
  font-size: 35px;
  margin-bottom: 10px;

  @media only screen and (max-width: 1024px) {
    font-size: 24px;
    text-align: center;
  }

  @media only screen and (max-width: 425px) {
    font-size: 21px;
  }
`;

export const TitleBefore3 = styled.div`
  color: #0a1932;
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 10px;

  @media only screen and (max-width: 1024px) {
    text-align: center;
  }
`;

export const Description3 = styled.div`
  color: #0a1932;
  font-size: 15px;
  font-weight: 500;
  margin-bottom: 20px;

  @media only screen and (max-width: 1024px) {
    text-align: center;
  }
`;

export const ButtonSimulate1 = styled(ButtonBase)`
  padding: 12px 15px 12px 20px !important;
  background: #ffe44d !important;
  color: #0a1932 !important;
  text-transform: uppercase !important;
  font-weight: bold !important;
  border-radius: 7px !important;
  font-size: 14px !important;
  display: flex !important;
  align-items: center !important;
  -webkit-box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);
  -moz-box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);
  box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);

  &:focus {
    outline: 0;
  }
`;

export const ButtonSimulate2 = styled(ButtonBase)`
  padding: 12px 15px 12px 20px !important;
  background: #0a1932 !important;
  color: #fff !important;
  text-transform: uppercase !important;
  font-weight: bold !important;
  border-radius: 7px !important;
  font-size: 14px !important;
  display: flex !important;
  align-items: center !important;

  &:focus {
    outline: 0;
  }
`;

export const Box4 = styled.div`
  position: absolute;
  top: 0;
  right: 70px;
  width: 350px;

  @media only screen and (max-width: 1024px) {
    width: 100%;
    padding: 0 200px;
    display: flex;
    flex-direction: column;
    align-items: center;
    right: 0;
  }

  @media only screen and (max-width: 768px) {
    padding: 0 100px;
  }

  @media only screen and (max-width: 560px) {
    padding: 0 50px;
  }
`;

export const Title4 = styled.div`
  color: #0a1932;
  font-weight: 800;
  font-size: 35px;
  margin-bottom: 10px;
  cursor: pointer;

  &:hover {
    text-decoration: underline;
  }

  @media only screen and (max-width: 1024px) {
    font-size: 24px;
    text-align: center;
  }

  @media only screen and (max-width: 425px) {
    font-size: 21px;
  }
`;

export const Description4 = styled.div`
  color: #0a1932;
  font-size: 15px;
  font-weight: 500;
  margin-bottom: 20px;

  @media only screen and (max-width: 1024px) {
    text-align: center;
  }
`;

export const Banner = styled.div`
  background: #ffe44d;
  padding: 60px;
  display: flex;
  flex-direction: column;
  align-items: center;

  @media only screen and (max-width: 768px) {
    padding: 60px 20px;
  }
`;

export const BannerTitle = styled.div`
  color: #0a1932;
  font-size: 32px;
  font-weight: 800;
  text-align: center;
  margin-bottom: 30px;

  @media only screen and (max-width: 768px) {
    font-size: 24px;
  }

  @media only screen and (max-width: 425px) {
    font-size: 18px;
  }
`;
