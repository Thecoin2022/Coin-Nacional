import React from 'react';

import { useHistory } from 'react-router-dom';

import { useMediaQuery } from '@material-ui/core';

import {
  Container,
  Image,
  Box1,
  Section1,
  Title1,
  Box1Body,
  Description1,
  Box2,
  Box2Body,
  Description2,
  Title2,
  Header,
  Image2,
  Box3,
  Description3,
  Title3,
  TitleBefore3,
  ButtonSimulate1,
  ButtonSimulate2,
  Image3,
  Section2,
  Box4,
  Description4,
  Title4,
  Banner,
  BannerTitle,
} from './styles';

const Home: React.FC = () => {
  const history = useHistory();

  const biggerThan1300 = useMediaQuery('(min-width:1300px)');
  const biggerThan1163 = useMediaQuery('(min-width:1163px)');
  const biggerThan1024 = useMediaQuery('(min-width:1024px)');
  const biggerThan768 = useMediaQuery('(min-width:768px)');
  const biggerThan425 = useMediaQuery('(min-width:425px)');

  const bottom = React.useMemo(() => {
    if (biggerThan425) return '/bottom.svg';
    return '/bottom2.svg';
  }, [biggerThan425]);

  const header = React.useMemo(() => {
    if (biggerThan425) return '/header.svg';
    return '/header2.svg';
  }, [biggerThan425]);

  const image1 = React.useMemo(() => {
    if (biggerThan1300) return '/home1.svg';
    if (biggerThan1163) return '/home2.svg';
    if (biggerThan1024) return '/home3.svg';
    if (biggerThan768) return '/home4.svg';
    return '/home5.svg';
  }, [biggerThan1300, biggerThan1163, biggerThan1024, biggerThan768]);

  return (
    <>
      <Container>
        <Header>
          <Image2 src={header} alt="header" />

          <Box3>
            <TitleBefore3>Nós somos referência em</TitleBefore3>
            <Title3>Crédito com Garantia de Sucesso!</Title3>

            <Description3>
              Tornamos sua vida financeira mais simples.
            </Description3>

            <ButtonSimulate1
              onClick={() => {
                history.push('/simulacao');
              }}
            >
              Faça sua simulação
            </ButtonSimulate1>
          </Box3>
        </Header>
        <Section1>
          <Image src={image1} alt="home" />
          <Box2>
            <Title2
              onClick={() => {
                history.push('/egi');
              }}
            >
              Empréstimo com Garantia de Imóvel
            </Title2>
            <Box2Body>
              <Description2>
                O empréstimo com garantia de imóvel é a solução ideal para você
                que sonha com a casa própria.
              </Description2>
              <img src="/house.svg" alt="carro" />
            </Box2Body>
          </Box2>
          <Box1>
            <Title1
              onClick={() => {
                history.push('/egv');
              }}
            >
              Empréstimo com Garantia de Veículo
            </Title1>
            <Box1Body>
              <Description1>
                A modalidade de empréstimo para quem deseja comprar um imóvel.
                Casa dos sonhos? Nós realizamos!
              </Description1>
              <img src="/car.svg" alt="carro" />
            </Box1Body>
            <ButtonSimulate2
              onClick={() => {
                history.push('/simulacao');
              }}
            >
              Faça sua simulação
            </ButtonSimulate2>
          </Box1>
        </Section1>
        <Section2>
          <Image3 src={bottom} alt="home" />
          <Box4>
            <Title4
              onClick={() => {
                history.push('/fi');
              }}
            >
              Financiamento Imobiliário
              {biggerThan1024 && <img src="/property.svg" alt="imóvel" />}
            </Title4>

            <Description4>
              A modalidade financiamento imobiliário para quem deseja comprar um
              imóvel. Casa dos sonhos? Nós realizamos!
            </Description4>
            {biggerThan1024 || <img src="/property.svg" alt="imóvel" />}
          </Box4>
        </Section2>
      </Container>
      <Banner>
        <BannerTitle>
          Não existe crédito ruim, ruim é usar o crédito errado
        </BannerTitle>
        <ButtonSimulate2
          onClick={() => {
            history.push('/simulacao');
          }}
        >
          Faça sua simulação
        </ButtonSimulate2>
      </Banner>
    </>
  );
};

export default Home;
