import React from 'react';

import { Formik } from 'formik';

import { useHistory } from 'react-router-dom';

import * as Yup from 'yup';

import api from '../../../services/api';

import {
  Container,
  Body,
  Head,
  Image,
  Right,
  FormBody,
  FormDouble,
  Input,
  Button,
  Textarea,
  Banner,
  BannerTitle,
  Icons,
  Icon,
} from './styles';

const Contact: React.FC = () => {
  const history = useHistory();

  type initialValuesProps = {
    name: string;
    email: string;
    phone: string;
    title: string;
    message: string;
  };

  const initialValues: initialValuesProps = {
    name: '',
    email: '',
    phone: '',
    title: '',
    message: '',
  };

  return (
    <>
      <Head>Fale Conosco</Head>
      <Container>
        <Formik
          initialValues={initialValues}
          validateOnBlur={false}
          validateOnChange={false}
          validationSchema={Yup.object().shape({
            name: Yup.string().required('Campo obrigatório'),
            email: Yup.string().required('Campo obrigatório'),
            phone: Yup.string().required('Campo obrigatório'),
            title: Yup.string().required('Campo obrigatório'),
            message: Yup.string().required('Campo obrigatório'),
          })}
          onSubmit={async (values, actions) => {
            await api.post('/contact', values);

            history.push('/contato/enviado');

            actions.setSubmitting(false);
          }}
        >
          {props => (
            <form onSubmit={props.handleSubmit}>
              <Body>
                <Image src="/contact.svg" alt="contato" />
                <Right>
                  <FormBody>
                    <Input
                      placeholder="Nome Completo"
                      onChange={props.handleChange}
                      onBlur={props.handleBlur}
                      value={props.values.name}
                      error={!!props.errors.name}
                      name="name"
                    />
                    <FormDouble>
                      <Input
                        placeholder="E-mail"
                        onChange={props.handleChange}
                        onBlur={props.handleBlur}
                        value={props.values.email}
                        error={!!props.errors.email}
                        name="email"
                      />
                      <Input
                        placeholder="Telefone"
                        onChange={props.handleChange}
                        onBlur={props.handleBlur}
                        value={props.values.phone}
                        error={!!props.errors.phone}
                        name="phone"
                      />
                    </FormDouble>
                    <Input
                      placeholder="Assunto"
                      onChange={props.handleChange}
                      onBlur={props.handleBlur}
                      value={props.values.title}
                      error={!!props.errors.title}
                      name="title"
                    />
                    <Textarea
                      placeholder="Mensagem"
                      onChange={props.handleChange}
                      onBlur={props.handleBlur}
                      value={props.values.message}
                      error={!!props.errors.message}
                      name="message"
                    />
                  </FormBody>
                  <Button type="submit">Enviar mensagem</Button>
                </Right>
              </Body>
            </form>
          )}
        </Formik>
      </Container>
      <Banner>
        <BannerTitle>Acompanhe nossas redes sociais</BannerTitle>
        <Icons>
          <Icon src="/rede1.svg" alt="instagram" />
          <Icon src="/rede2.svg" alt="facebook" />
          <Icon src="/rede3.svg" alt="twitter" />
          <Icon src="/rede4.svg" alt="whatsapp" />
        </Icons>
      </Banner>
    </>
  );
};

export default Contact;
