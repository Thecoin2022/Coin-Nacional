import styled from 'styled-components';
import ButtonBase from '@material-ui/core/ButtonBase';

export const Container = styled.div`
  background: #e9f2ff;
  flex: 1;
`;

export const Head = styled.div`
  background: #0a1932;
  width: 100%;
  text-align: center;
  font-size: 32px;
  font-weight: 800;
  padding: 70px 20px;
  color: #fff;

  @media only screen and (max-width: 1024px) {
    font-size: 24px;
    font-weight: bold;
    padding: 50px 20px;
  }

  @media only screen and (max-width: 768px) {
    font-size: 18px;
    font-weight: bold;
    padding: 30px 20px;
  }
`;

export const Body = styled.div`
  width: 100%;
  max-width: 1280px;
  margin: 0 auto;
  padding: 70px 20px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-gap: 50px;

  @media only screen and (max-width: 1024px) {
    grid-template-columns: 1fr;
    padding: 70px 100px;
  }

  @media only screen and (max-width: 768px) {
    grid-template-columns: 1fr;
    padding: 70px;
  }

  @media only screen and (max-width: 425px) {
    grid-template-columns: 1fr;
    padding: 70px 30px;
  }
`;

export const Right = styled.div`
  @media only screen and (max-width: 1024px) {
    grid-row-start: 1;
    grid-row-end: 2;
  }
`;

export const Image = styled.img`
  width: 100%;
`;

type InputProps = {
  error?: boolean;
};

export const Input = styled.input<InputProps>`
  padding: 10px 15px;
  border-radius: 5px;
  border: 1px solid ${props => (props.error ? '#f03' : '#90a8d0')};
  min-width: 0;
`;

type TextareaProps = {
  error?: boolean;
};

export const Textarea = styled.textarea<TextareaProps>`
  padding: 10px 15px;
  border-radius: 5px;
  border: 1px solid ${props => (props.error ? '#f03' : '#90a8d0')};
  min-width: 0;
`;

export const FormBody = styled.div`
  display: grid;
  grid-gap: 20px;
  margin-bottom: 40px;
`;

export const FormDouble = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-gap: 20px;

  @media only screen and (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

export const Button = styled(ButtonBase)`
  padding: 12px 15px 12px 20px !important;
  background: #ffe44d !important;
  color: #0a1932 !important;
  text-transform: uppercase !important;
  font-weight: bold !important;
  border-radius: 7px !important;
  font-size: 14px !important;
  display: flex !important;
  align-items: center !important;
  -webkit-box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);
  -moz-box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);
  box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);

  &:focus {
    outline: 0;
  }

  @media only screen and (max-width: 425px) {
    margin: 0 auto !important;
  }
`;

export const Banner = styled.div`
  background: #ffe44d;
  padding: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;

  @media only screen and (max-width: 768px) {
    padding: 60px 20px;
  }
`;

export const BannerTitle = styled.div`
  color: #0a1932;
  font-size: 24px;
  font-weight: 800;
  text-align: center;
  margin-bottom: 10px;

  @media only screen and (max-width: 768px) {
    font-size: 18px;
  }
`;

export const Icons = styled.div`
  display: flex;
  align-items: center;
`;

export const Icon = styled.img`
  & + & {
    margin-left: 13px;
  }
`;
