import React from 'react';

import { useHistory } from 'react-router-dom';

import { useMediaQuery } from '@material-ui/core';

import {
  Container,
  Head,
  Image,
  Left,
  Title,
  ButtonSimulate1,
  Description,
  Button,
  Buttons,
  Section3,
  Section3Title,
  ButtonContainer,
  Section,
  Left2,
  Image3,
  Description2,
  Title3,
  SectionTitle,
} from './styles';

const About: React.FC = () => {
  const history = useHistory();

  const biggerThan768 = useMediaQuery('(min-width:768px)');

  const timeline = React.useMemo(() => {
    if (biggerThan768) return '/timeline4.svg';
    return '/timeline5.svg';
  }, [biggerThan768]);

  return (
    <>
      <Container>
        <Head>
          <Left>
            <Title>Empréstimo com garantia de veículo</Title>
            <Description>
              Seja qual for a sua necessidade, temos a solução! Conheça o
              refinanciamento veicular. Com taxas a partir de 1,39% e
              empréstimos de até 90% do valor do bem!
            </Description>
            <ButtonContainer>
              <ButtonSimulate1
                onClick={() => {
                  history.push('/simulacao/egv');
                }}
              >
                Faça uma simulação
              </ButtonSimulate1>
            </ButtonContainer>
          </Left>
          <Image src="/egv.svg" alt="sobre" />
        </Head>

        <Section>
          <Image3 src="/emp.svg" alt="sobre" />
          <Left2>
            <Title3>Como funciona ?</Title3>
            <Description2>
              Também conhecido como refinanciamento veicular, o empréstimo tem
              taxas de juros partir de 1,39%, transformando até 90% do valor do
              seu veículo em crédito. A análise e aprovação do pedido são
              realizadas com base no seu perfil, e no valor do veículo que será
              usado como garantia. Não se preocupe, mesmo que o carro esteja
              alienado ao banco, você poderá usá-lo todos os dias normalmente.
            </Description2>
          </Left2>
        </Section>

        <SectionTitle>
          A contratação é simples e pode ser feita em um processo seguro e 100%
          online
        </SectionTitle>

        <Image3 src={timeline} alt="sobre" />
      </Container>
      <Section3>
        <Section3Title>
          O primeiro passo para atingir seus objetivos
        </Section3Title>

        <Buttons>
          <div />
          <Button
            onClick={() => {
              history.push('/simulacao/egv');
            }}
          >
            FAÇA UMA SIMULAÇÃO
          </Button>
          <div />
        </Buttons>
      </Section3>
    </>
  );
};

export default About;
