import React from 'react';

import { withStyles } from '@material-ui/core/styles';
import MuiAccordion from '@material-ui/core/Accordion';
import MuiAccordionSummary from '@material-ui/core/AccordionSummary';
import MuiAccordionDetails from '@material-ui/core/AccordionDetails';
import Typography from '@material-ui/core/Typography';

import { useAsync } from 'react-async';
import api from '../../../services/api';

import {
  Container,
  Section,
  SectionDescription,
  SectionTitle,
  Image,
  Collapse,
} from './styles';

const Accordion = withStyles({
  root: {
    border: '1px solid rgba(0, 0, 0, .125)',
    boxShadow: 'none',
    '&:not(:last-child)': {
      borderBottom: 0,
    },
    '&:before': {
      display: 'none',
    },
    '&$expanded': {
      margin: 'auto',
    },
  },
  expanded: {},
})(MuiAccordion);

const AccordionSummary = withStyles({
  root: {
    backgroundColor: 'rgba(0, 0, 0, .03)',
    borderBottom: '1px solid rgba(0, 0, 0, .125)',
    marginBottom: -1,
    fontSize: 24,
    minHeight: 56,
    '&$expanded': {
      minHeight: 56,
    },
    '& .MuiAccordionSummary-content p': {
      fontSize: 18,
      fontFamily: 'Montserrat',
      fontWeight: 600,
    },
  },
  content: {
    '&$expanded': {
      margin: '12px 0',
    },
  },
  expanded: {},
})(MuiAccordionSummary);

const AccordionDetails = withStyles(theme => ({
  root: {
    padding: theme.spacing(2),
    '& p': {
      fontSize: 15,
      fontFamily: 'Montserrat',
      fontWeight: 500,
    },
  },
}))(MuiAccordionDetails);

interface IloadClients {
  questions: Array<{
    id: string;
    question: string;
    answer: string;
  }>;
}

const loadClients = async (): Promise<IloadClients> => {
  const { data: questions } = await api.get(`/questions`);

  return { questions };
};

const Questions: React.FC = (): any => {
  const [expanded, setExpanded] = React.useState<string | false>('panel1');

  const handleChange = (panel: string) => (
    event: React.ChangeEvent<{}>,
    newExpanded: boolean,
  ) => {
    setExpanded(newExpanded ? panel : false);
  };

  const { data, error, isPending } = useAsync({
    promiseFn: loadClients,
  });
  if (isPending) return null;
  if (error) return `Something went wrong: ${error.message}`;
  if (data) {
    return (
      <Container>
        <Image src="/questions.svg" alt="FAQ" />

        <Section>
          <SectionTitle>Perguntas Frequentes</SectionTitle>

          <SectionDescription>
            Separamos algumas das dúvidas mais frequentes para agilizar a sua
            procura, caso ainda tenha dúvidas não hesite em entrar em contato,
            estamos prontos para te atender!
          </SectionDescription>
        </Section>

        <Collapse>
          {data.questions.map((question, idx) => (
            <Accordion
              key={question.id}
              square={false}
              expanded={expanded === `panel${idx + 1}`}
              onChange={handleChange(`panel${idx + 1}`)}
            >
              <AccordionSummary
                aria-controls={`panel${idx + 1}d-content`}
                id={`panel${idx + 1}d-header`}
              >
                <Typography>{question.question}</Typography>
              </AccordionSummary>
              <AccordionDetails>
                <Typography>{question.answer}</Typography>
              </AccordionDetails>
            </Accordion>
          ))}
        </Collapse>
      </Container>
    );
  }

  return null;
};

export default Questions;
