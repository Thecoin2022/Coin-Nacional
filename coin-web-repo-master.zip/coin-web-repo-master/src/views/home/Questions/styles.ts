import styled from 'styled-components';

export const Container = styled.div`
  width: 100%;
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 20px;
`;

export const Section = styled.div`
  padding: 100px 200px;
  display: flex;
  flex-direction: column;
  align-items: center;

  @media only screen and (max-width: 1024px) {
    padding: 100px 150px;
  }

  @media only screen and (max-width: 768px) {
    padding: 55px;
  }

  @media only screen and (max-width: 425px) {
    padding: 15px;
  }
`;

export const SectionTitle = styled.div`
  color: #0a1932;
  font-size: 32px;
  font-weight: bold;
  text-align: center;

  @media only screen and (max-width: 768px) {
    font-size: 24px;
  }
`;

export const SectionDescription = styled.div`
  color: #0a1932;
  font-size: 18px;
  margin-top: 20px;
  text-align: center;

  @media only screen and (max-width: 768px) {
    font-size: 15px;
  }
`;

export const Image = styled.img`
  width: 100%;
  margin-top: 100px;

  @media only screen and (max-width: 768px) {
    margin-top: 10px;
  }
`;

export const Collapse = styled.div`
  margin-bottom: 100px;

  @media only screen and (max-width: 768px) {
    margin-bottom: 30px;
  }
`;
