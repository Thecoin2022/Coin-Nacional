import React from 'react';

import { Formik } from 'formik';

import { useHistory } from 'react-router-dom';

import * as Yup from 'yup';

import api from '../../../services/api';

import {
  Container,
  Section,
  SectionDescription,
  SectionTitle,
  Image,
  Button,
  FormBody,
  FormDouble,
  Input,
  Textarea,
  Body,
} from './styles';

const Questions: React.FC = (): any => {
  const history = useHistory();

  type initialValuesProps = {
    name: string;
    email: string;
    phone: string;
    employees_amount: number | null;
    description: string;
  };

  const initialValues: initialValuesProps = {
    name: '',
    email: '',
    phone: '',
    employees_amount: null,
    description: '',
  };

  return (
    <Container>
      <Section>
        <SectionTitle>Junte-se a nós!</SectionTitle>

        <SectionDescription>
          Faça parte do nosso programa de parceiros: você indica a opção certa
          de empréstimo, conquista o seu cliente e garante uma comissão.
        </SectionDescription>
      </Section>

      <Body>
        <Formik
          initialValues={initialValues}
          validateOnBlur={false}
          validateOnChange={false}
          validationSchema={Yup.object().shape({
            name: Yup.string().required('Campo obrigatório'),
            email: Yup.string().required('Campo obrigatório'),
            phone: Yup.string().required('Campo obrigatório'),
            employees_amount: Yup.number()
              .nullable()
              .required('Campo obrigatório'),
            description: Yup.string(),
          })}
          onSubmit={async (values, actions) => {
            await api.post('/partners', values);

            history.push('/parceiro/obrigado');

            actions.setSubmitting(false);
          }}
        >
          {props => (
            <form onSubmit={props.handleSubmit}>
              <FormBody>
                <Input
                  placeholder="Nome Completo"
                  onChange={props.handleChange}
                  onBlur={props.handleBlur}
                  value={props.values.name}
                  error={!!props.errors.name}
                  name="name"
                />
                <FormDouble>
                  <Input
                    placeholder="E-mail"
                    onChange={props.handleChange}
                    onBlur={props.handleBlur}
                    value={props.values.email}
                    error={!!props.errors.email}
                    name="email"
                  />
                  <Input
                    placeholder="Telefone"
                    onChange={props.handleChange}
                    onBlur={props.handleBlur}
                    value={props.values.phone}
                    error={!!props.errors.phone}
                    name="phone"
                  />
                </FormDouble>
                <Input
                  placeholder="Número de funcionários"
                  type="number"
                  onChange={props.handleChange}
                  onBlur={props.handleBlur}
                  value={props.values.employees_amount as any}
                  error={!!props.errors.employees_amount}
                  name="employees_amount"
                />
                <Textarea
                  placeholder="Adicional ( opcional )"
                  onChange={props.handleChange}
                  onBlur={props.handleBlur}
                  value={props.values.description}
                  error={!!props.errors.description}
                  name="description"
                />
              </FormBody>
              <Button type="submit">Enviar solicitação</Button>
            </form>
          )}
        </Formik>
      </Body>

      <Image src="/partnersform.svg" alt="Parceiro" />
    </Container>
  );
};

export default Questions;
