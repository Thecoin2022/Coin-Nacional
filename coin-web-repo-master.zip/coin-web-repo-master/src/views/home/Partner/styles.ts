import styled from 'styled-components';
import ButtonBase from '@material-ui/core/ButtonBase';

export const Container = styled.div`
  width: 100%;
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 20px;
`;

export const Section = styled.div`
  padding: 100px 200px;
  display: flex;
  flex-direction: column;
  align-items: center;

  @media only screen and (max-width: 1024px) {
    padding: 100px 150px;
  }

  @media only screen and (max-width: 768px) {
    padding: 55px;
  }

  @media only screen and (max-width: 425px) {
    padding: 15px;
  }
`;

export const SectionTitle = styled.div`
  color: #0a1932;
  font-size: 32px;
  font-weight: bold;
  text-align: center;

  @media only screen and (max-width: 768px) {
    font-size: 24px;
  }
`;

export const SectionDescription = styled.div`
  color: #0a1932;
  font-size: 18px;
  margin-top: 20px;
  text-align: center;

  @media only screen and (max-width: 768px) {
    font-size: 15px;
  }
`;

export const Image = styled.img`
  width: 100%;
  margin-bottom: 100px;

  @media only screen and (max-width: 768px) {
    margin-bottom: 40px;
  }
`;

type InputProps = {
  error?: boolean;
};

export const Input = styled.input<InputProps>`
  padding: 10px 15px;
  border-radius: 5px;
  border: 1px solid ${props => (props.error ? '#f03' : '#90a8d0')};
  min-width: 0;
`;

type TextareaProps = {
  error?: boolean;
};

export const Textarea = styled.textarea<TextareaProps>`
  padding: 10px 15px;
  border-radius: 5px;
  border: 1px solid ${props => (props.error ? '#f03' : '#90a8d0')};
  min-width: 0;
`;

export const FormBody = styled.div`
  display: grid;
  grid-gap: 20px;
  margin-bottom: 40px;
`;

export const FormDouble = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-gap: 20px;

  @media only screen and (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

export const Button = styled(ButtonBase)`
  padding: 12px 15px 12px 20px !important;
  background: #ffe44d !important;
  color: #0a1932 !important;
  text-transform: uppercase !important;
  font-weight: bold !important;
  border-radius: 7px !important;
  font-size: 14px !important;
  display: flex !important;
  align-items: center !important;
  -webkit-box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);
  -moz-box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);
  box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);

  &:focus {
    outline: 0;
  }

  @media only screen and (max-width: 425px) {
    margin: 0 auto !important;
  }
`;

export const Body = styled.div`
  max-width: 700px;
  margin: 0 auto;
  margin-bottom: 40px;
`;
