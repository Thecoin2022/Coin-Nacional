import React from 'react';

import { useHistory } from 'react-router-dom';

import {
  Container,
  Body,
  Head,
  Image,
  Right,
  Title,
  Description,
  Button,
  Banner,
  BannerTitle,
  Icon,
  Icons,
} from './styles';

const Thanks: React.FC = () => {
  const history = useHistory();

  return (
    <>
      <Head>Fale Conosco</Head>
      <Container>
        <Body>
          <Image src="/contact.svg" alt="contato" />
          <Right>
            <Title>Obrigado!</Title>
            <Description>Sua mensagem foi enviada.</Description>
            <Button onClick={() => history.push('/contato')}>
              Enviar outra mensagem
            </Button>
          </Right>
        </Body>
      </Container>
      <Banner>
        <BannerTitle>Acompanhe nossas redes sociais</BannerTitle>
        <Icons>
          <Icon src="/rede1.svg" alt="instagram" />
          <Icon src="/rede2.svg" alt="facebook" />
          <Icon src="/rede3.svg" alt="twitter" />
          <Icon src="/rede4.svg" alt="whatsapp" />
        </Icons>
      </Banner>
    </>
  );
};

export default Thanks;
