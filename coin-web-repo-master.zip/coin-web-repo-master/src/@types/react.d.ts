declare namespace React {
  export let icons: {
    [x as string]: string[];
  };
}
