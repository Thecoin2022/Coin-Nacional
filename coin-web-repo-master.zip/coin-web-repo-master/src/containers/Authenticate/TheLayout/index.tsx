import React, { Suspense } from 'react';
import { Route, Switch } from 'react-router-dom';

import routes from '../../../routes/authenticate.routes';

const loading = (
  <div className="pt-3 text-center">
    <div className="sk-spinner sk-spinner-pulse" />
  </div>
);

const TheContent: React.FC = () => {
  return (
    <div>
      <Suspense fallback={loading}>
        <Switch>
          {routes.map((route, idx) => {
            return (
              route.component && (
                <Route
                  key={idx.toString()}
                  path={route.path}
                  exact={route.exact}
                  name={route.name}
                  component={route.component}
                />
              )
            );
          })}
        </Switch>
      </Suspense>
    </div>
  );
};

export default React.memo(TheContent);
