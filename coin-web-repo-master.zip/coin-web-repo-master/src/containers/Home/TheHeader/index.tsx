import React, { useState, CSSProperties } from 'react';
import { useScrollPosition } from '@n8tb1t/use-scroll-position';

import { useMediaQuery } from '@material-ui/core';

import { useHistory } from 'react-router-dom';

import Lottie from 'react-lottie';

import clsx from 'clsx';
import { makeStyles } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import List from '@material-ui/core/List';

import {
  Container,
  Navbar,
  NavbarFixed,
  NavbarBody,
  ButtonAccount,
  ButtonSimulate,
  NavbarRight,
  Divider,
  Li,
  NavbarLeft,
  ButtonAccountFixed,
  ButtonSimulateFixed,
  LiFixed,
  DividerFixed,
  Arrow,
  ItemMobile,
  ButtonAccountMobile,
  ButtonSimulateMobile,
  Logo,
  LogoMobile,
} from './styles';

const useStyles = makeStyles({
  list: {
    width: 250,
  },
  fullList: {
    width: 'auto',
  },
});

const Home: React.FC = () => {
  const biggerThan1250 = useMediaQuery('(min-width:1250px)');

  const history = useHistory();

  const classes = useStyles();

  const [headerStyleFixed, setHeaderStyleFixed] = useState<CSSProperties>({
    transition: 'all 400ms ease-in',
    visibility: 'hidden',
    transform: 'translate(0, -150%)',
  });

  const links = React.useMemo(
    () => [
      {
        name: 'Empréstimos',
        path: '/',
      },
      {
        name: 'Parcerias',
        path: '/parceiros',
      },
      {
        name: 'Sobre nós',
        path: '/sobre',
      },
      {
        name: 'Blog',
        path: '/blog',
      },
      {
        name: 'Fale conosco',
        path: '/contato',
      },
      {
        name: 'FAQ',
        path: '/faq',
      },
    ],
    [],
  );

  const linksDrop = React.useMemo(
    () => [
      {
        name: 'Empréstimo com Garantia de Imóvel',
        path: '/',
      },
      {
        name: 'Empréstimo com Garantia de Veículo',
        path: '/',
      },
      {
        name: 'Financiamento Imobiliário',
        path: '/',
      },
      {
        name: 'Parcerias',
        path: '/parceiros',
      },
      {
        name: 'Sobre nós',
        path: '/sobre',
      },
      {
        name: 'Blog',
        path: '/blog',
      },
      {
        name: 'Fale conosco',
        path: '/contato',
      },
      {
        name: 'FAQ',
        path: '/faq',
      },
    ],
    [],
  );

  useScrollPosition(
    ({ currPos }) => {
      const isVisible = currPos.y < 0;

      const shouldBeStyleFixed: CSSProperties = {
        visibility: isVisible ? 'visible' : 'hidden',
        transition: `all 400ms ${isVisible ? 'ease-in' : 'ease-out'}`,
        transform: isVisible ? 'none' : 'translate(0, -150%)',
      };

      if (
        JSON.stringify(shouldBeStyleFixed) === JSON.stringify(headerStyleFixed)
      )
        return;
      setHeaderStyleFixed(shouldBeStyleFixed);
    },
    [headerStyleFixed],
  );

  const [loop, setLoop] = useState(false);

  const animationData = {
    v: '5.5.2',
    fr: 120,
    ip: 0,
    op: 124,
    w: 192,
    h: 192,
    nm: 'Comp 2',
    ddd: 0,
    assets: [
      {
        id: 'comp_0',
        layers: [
          {
            ddd: 0,
            ind: 1,
            ty: 4,
            nm: 'Arrow-Down Outlines',
            sr: 1,
            ks: {
              o: { a: 0, k: 100, ix: 11 },
              r: { a: 0, k: 0, ix: 10 },
              p: {
                a: 1,
                k: [
                  {
                    i: { x: 0.667, y: 1 },
                    o: { x: 0.333, y: 0 },
                    t: 0,
                    s: [96, 91, 0],
                    to: [0, 2.833, 0],
                    ti: [0, 3.5, 0],
                  },
                  {
                    i: { x: 0.667, y: 1 },
                    o: { x: 0.333, y: 0 },
                    t: 38,
                    s: [96, 108, 0],
                    to: [0, -3.5, 0],
                    ti: [0, 1.333, 0],
                  },
                  {
                    i: { x: 0.667, y: 1 },
                    o: { x: 0.333, y: 0 },
                    t: 60,
                    s: [96, 70, 0],
                    to: [0, -1.333, 0],
                    ti: [0, -3.5, 0],
                  },
                  {
                    i: { x: 0.667, y: 1 },
                    o: { x: 0.167, y: 0 },
                    t: 77,
                    s: [96, 100, 0],
                    to: [0, 3.5, 0],
                    ti: [0, 1.5, 0],
                  },
                  { t: 88, s: [96, 91, 0] },
                ],
                ix: 2,
              },
              a: { a: 0, k: [12, 12, 0], ix: 1 },
              s: { a: 0, k: [825, 825, 100], ix: 6 },
            },
            ao: 0,
            shapes: [
              {
                ty: 'gr',
                it: [
                  {
                    ind: 0,
                    ty: 'sh',
                    ix: 1,
                    ks: {
                      a: 0,
                      k: {
                        i: [
                          [0, 0],
                          [0, 0],
                        ],
                        o: [
                          [0, 0],
                          [0, 0],
                        ],
                        v: [
                          [12, 18],
                          [12, 6],
                        ],
                        c: false,
                      },
                      ix: 2,
                    },
                    nm: 'Path 1',
                    mn: 'ADBE Vector Shape - Group',
                    hd: false,
                  },
                  {
                    ty: 'tm',
                    s: { a: 0, k: 0, ix: 1 },
                    e: {
                      a: 1,
                      k: [
                        {
                          i: { x: [0.667], y: [1] },
                          o: { x: [0.333], y: [0] },
                          t: 0,
                          s: [100],
                        },
                        {
                          i: { x: [0.667], y: [1] },
                          o: { x: [0.333], y: [0] },
                          t: 38,
                          s: [32],
                        },
                        { t: 60, s: [100] },
                      ],
                      ix: 2,
                    },
                    o: { a: 0, k: 0, ix: 3 },
                    m: 1,
                    ix: 2,
                    nm: 'Trim Paths 1',
                    mn: 'ADBE Vector Filter - Trim',
                    hd: false,
                  },
                  {
                    ty: 'st',
                    c: { a: 0, k: [0, 0, 0, 1], ix: 3 },
                    o: { a: 0, k: 100, ix: 4 },
                    w: { a: 0, k: 2, ix: 5 },
                    lc: 2,
                    lj: 2,
                    bm: 0,
                    nm: 'Stroke 1',
                    mn: 'ADBE Vector Graphic - Stroke',
                    hd: false,
                  },
                  {
                    ty: 'tr',
                    p: {
                      a: 1,
                      k: [
                        {
                          i: { x: 0.667, y: 1 },
                          o: { x: 0.333, y: 0 },
                          t: 38,
                          s: [0, 0],
                          to: [0, -0.167],
                          ti: [0, 0],
                        },
                        {
                          i: { x: 0.667, y: 1 },
                          o: { x: 0.333, y: 0 },
                          t: 60,
                          s: [0, -1],
                          to: [0, 0],
                          ti: [0, -0.167],
                        },
                        { t: 77, s: [0, 0] },
                      ],
                      ix: 2,
                    },
                    a: { a: 0, k: [0, 0], ix: 1 },
                    s: { a: 0, k: [100, 100], ix: 3 },
                    r: { a: 0, k: 0, ix: 6 },
                    o: { a: 0, k: 100, ix: 7 },
                    sk: { a: 0, k: 0, ix: 4 },
                    sa: { a: 0, k: 0, ix: 5 },
                    nm: 'Transform',
                  },
                ],
                nm: 'Group 1',
                np: 3,
                cix: 2,
                bm: 0,
                ix: 1,
                mn: 'ADBE Vector Group',
                hd: false,
              },
              {
                ty: 'gr',
                it: [
                  {
                    ind: 0,
                    ty: 'sh',
                    ix: 1,
                    ks: {
                      a: 1,
                      k: [
                        {
                          i: { x: 0.667, y: 1 },
                          o: { x: 0.333, y: 0 },
                          t: 0,
                          s: [
                            {
                              i: [
                                [0, 0],
                                [0, 0],
                                [0, 0],
                              ],
                              o: [
                                [0, 0],
                                [0, 0],
                                [0, 0],
                              ],
                              v: [
                                [-5, -2.5],
                                [0, 2.5],
                                [5, -2.5],
                              ],
                              c: false,
                            },
                          ],
                        },
                        {
                          i: { x: 0.667, y: 1 },
                          o: { x: 0.333, y: 0 },
                          t: 38,
                          s: [
                            {
                              i: [
                                [0, 0],
                                [0, 0],
                                [0, 0],
                              ],
                              o: [
                                [0, 0],
                                [0, 0],
                                [0, 0],
                              ],
                              v: [
                                [-2.612, -1.742],
                                [-0.064, 2.431],
                                [2.484, -1.742],
                              ],
                              c: false,
                            },
                          ],
                        },
                        {
                          i: { x: 0.667, y: 1 },
                          o: { x: 0.167, y: 0 },
                          t: 60,
                          s: [
                            {
                              i: [
                                [0, 0],
                                [0, 0],
                                [0, 0],
                              ],
                              o: [
                                [0, 0],
                                [0, 0],
                                [0, 0],
                              ],
                              v: [
                                [-5.966, -2.5],
                                [-0.05, 2.5],
                                [5.865, -2.5],
                              ],
                              c: false,
                            },
                          ],
                        },
                        {
                          i: { x: 0.667, y: 1 },
                          o: { x: 0.333, y: 0 },
                          t: 77,
                          s: [
                            {
                              i: [
                                [0, 0],
                                [0, 0],
                                [0, 0],
                              ],
                              o: [
                                [0, 0],
                                [0, 0],
                                [0, 0],
                              ],
                              v: [
                                [-4.103, -2.5],
                                [-0.016, 2.5],
                                [4.071, -2.5],
                              ],
                              c: false,
                            },
                          ],
                        },
                        {
                          t: 88,
                          s: [
                            {
                              i: [
                                [0, 0],
                                [0, 0],
                                [0, 0],
                              ],
                              o: [
                                [0, 0],
                                [0, 0],
                                [0, 0],
                              ],
                              v: [
                                [-5, -2.5],
                                [0, 2.5],
                                [5, -2.5],
                              ],
                              c: false,
                            },
                          ],
                        },
                      ],
                      ix: 2,
                    },
                    nm: 'Path 1',
                    mn: 'ADBE Vector Shape - Group',
                    hd: false,
                  },
                  {
                    ty: 'st',
                    c: { a: 0, k: [0, 0, 0, 1], ix: 3 },
                    o: { a: 0, k: 100, ix: 4 },
                    w: { a: 0, k: 2, ix: 5 },
                    lc: 2,
                    lj: 2,
                    bm: 0,
                    nm: 'Stroke 1',
                    mn: 'ADBE Vector Graphic - Stroke',
                    hd: false,
                  },
                  {
                    ty: 'tr',
                    p: { a: 0, k: [12, 16.5], ix: 2 },
                    a: { a: 0, k: [0, 0], ix: 1 },
                    s: { a: 0, k: [87.834, 87.834], ix: 3 },
                    r: { a: 0, k: 0, ix: 6 },
                    o: { a: 0, k: 100, ix: 7 },
                    sk: { a: 0, k: 0, ix: 4 },
                    sa: { a: 0, k: 0, ix: 5 },
                    nm: 'Transform',
                  },
                ],
                nm: 'Group 2',
                np: 2,
                cix: 2,
                bm: 0,
                ix: 2,
                mn: 'ADBE Vector Group',
                hd: false,
              },
            ],
            ip: 0,
            op: 1215,
            st: 0,
            bm: 0,
          },
        ],
      },
    ],
    layers: [
      {
        ddd: 0,
        ind: 1,
        ty: 0,
        nm: 'Arrow-Down Outlines Comp 1',
        refId: 'comp_0',
        sr: 1,
        ks: {
          o: { a: 0, k: 100, ix: 11 },
          r: { a: 0, k: 90, ix: 10 },
          p: { a: 0, k: [96, 96, 0], ix: 2 },
          a: { a: 0, k: [96, 96, 0], ix: 1 },
          s: { a: 0, k: [100, 100, 100], ix: 6 },
        },
        ao: 0,
        w: 192,
        h: 192,
        ip: 0,
        op: 1215,
        st: 0,
        bm: 0,
      },
    ],
    markers: [],
  };

  const defaultOptions = {
    animationData,
    loop,
    autoplay: false,
  };

  const hoverHandler = () => {
    setLoop(true);
  };
  const outHandler = () => {
    setLoop(false);
  };

  const [open, setOpen] = React.useState(false);

  return (
    <Container>
      <NavbarFixed style={headerStyleFixed}>
        <NavbarBody>
          <NavbarLeft>
            <Logo onClick={() => history.push('/')}>
              <img src="/logonavbarfixed.svg" alt="logo" />
            </Logo>
            {biggerThan1250 && (
              <>
                <DividerFixed />
                {links.map(link => (
                  <LiFixed
                    onClick={() => history.push(link.path)}
                    key={link.name}
                  >
                    {link.name}
                  </LiFixed>
                ))}
              </>
            )}
          </NavbarLeft>
          {biggerThan1250 ? (
            <NavbarRight>
              <ButtonAccountFixed
                onClick={() => history.push('/authenticate/login')}
              >
                Minha conta
              </ButtonAccountFixed>
              <ButtonSimulateFixed
                onMouseOver={hoverHandler}
                onMouseOut={outHandler}
                onClick={() => history.push('/simulacao')}
              >
                Simulação
                <Arrow>
                  <Lottie
                    options={defaultOptions}
                    height={20}
                    width={20}
                    isStopped={false}
                  />
                </Arrow>
              </ButtonSimulateFixed>
            </NavbarRight>
          ) : (
            <div onClick={() => setOpen(true)}>
              <img src="/menu.svg" alt="menu" />
            </div>
          )}
        </NavbarBody>
      </NavbarFixed>
      <Navbar>
        <NavbarBody>
          <NavbarLeft>
            <Logo onClick={() => history.push('/')}>
              <img src="/logonavbar.svg" alt="logo" />
            </Logo>
            {biggerThan1250 && (
              <>
                <Divider />
                {links.map(link => (
                  <Li onClick={() => history.push(link.path)} key={link.name}>
                    {link.name}
                  </Li>
                ))}
              </>
            )}
          </NavbarLeft>
          {biggerThan1250 ? (
            <NavbarRight>
              <ButtonAccount
                onClick={() => history.push('/authenticate/login')}
              >
                Minha conta
              </ButtonAccount>
              <ButtonSimulate
                onMouseOver={hoverHandler}
                onMouseOut={outHandler}
                onClick={() => history.push('/simulacao')}
              >
                Simulação
                <Arrow>
                  <Lottie
                    options={defaultOptions}
                    height={20}
                    width={20}
                    isStopped={false}
                  />
                </Arrow>
              </ButtonSimulate>
            </NavbarRight>
          ) : (
            <div onClick={() => setOpen(true)}>
              <img src="/menu.svg" alt="menu" />
            </div>
          )}
        </NavbarBody>
      </Navbar>
      <Drawer anchor="top" open={open} onClose={() => setOpen(false)}>
        <div
          className={clsx(classes.list, classes.fullList)}
          role="presentation"
          onClick={() => setOpen(false)}
          onKeyDown={() => setOpen(false)}
        >
          <LogoMobile onClick={() => history.push('/')}>
            <img src="/logonavbar.svg" alt="logo" />
          </LogoMobile>
          <List>
            {linksDrop.map(link => (
              <ItemMobile
                onClick={() => history.push(link.path)}
                key={link.name}
              >
                {link.name}
              </ItemMobile>
            ))}
          </List>
          <ButtonAccountMobile
            onClick={() => history.push('/authenticate/login')}
          >
            Minha conta
          </ButtonAccountMobile>
          <ButtonSimulateMobile onClick={() => history.push('/simulacao')}>
            Simulação
          </ButtonSimulateMobile>
        </div>
      </Drawer>
    </Container>
  );
};

export default Home;
