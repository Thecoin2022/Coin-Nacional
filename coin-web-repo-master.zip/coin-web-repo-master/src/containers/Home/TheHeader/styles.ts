import styled from 'styled-components';
import ButtonBase from '@material-ui/core/ButtonBase';

export const Container = styled.div`
  width: 100%;
  z-index: 2;
`;

export const Navbar = styled.div`
  height: 70px;
  width: 100%;
`;

export const NavbarFixed = styled.div`
  background: #0a1932;
  position: fixed;
  height: 70px;
  width: 100%;
  z-index: 999;
`;

export const NavbarBody = styled.div`
  width: 100%;
  max-width: 1280px;
  padding: 0 20px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 100%;
`;

export const NavbarRight = styled.div`
  display: flex;
`;

export const NavbarLeft = styled.div`
  display: flex;
  align-items: center;
`;

export const Divider = styled.div`
  height: 47px;
  margin: 0 25px;
  width: 1px;
  background: #bcc0c7;
`;

export const DividerFixed = styled.div`
  height: 47px;
  margin: 0 25px;
  width: 1px;
  background: #0a1932;
`;

export const Li = styled.div`
  cursor: pointer;
  color: #0a1932;
  font-size: 14px;
  text-transform: uppercase;
  font-weight: bold;

  & + & {
    margin-left: 35px;
  }
`;

export const LiFixed = styled.div`
  cursor: pointer;
  color: #fff;
  font-size: 14px;
  text-transform: uppercase;
  font-weight: bold;

  & + & {
    margin-left: 35px;
  }
`;

export const ButtonAccount = styled(ButtonBase)`
  padding: 12px 20px !important;
  background: #0a1932 !important;
  color: #fff !important;
  text-transform: uppercase !important;
  font-weight: bold !important;
  border-radius: 7px !important;
  font-size: 14px !important;

  &:focus {
    outline: 0;
  }
`;

export const ButtonSimulate = styled(ButtonBase)`
  padding: 12px 15px 12px 20px !important;
  background: #ffe44d !important;
  color: #0a1932 !important;
  text-transform: uppercase !important;
  font-weight: bold !important;
  border-radius: 7px !important;
  font-size: 14px !important;
  margin-left: 12px !important;
  display: flex !important;
  align-items: center !important;
  -webkit-box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);
  -moz-box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);
  box-shadow: 0px 0px 12px 0px rgba(255, 228, 77, 0.52);

  &:focus {
    outline: 0;
  }
`;

export const ButtonAccountFixed = styled(ButtonBase)`
  padding: 12px 20px !important;
  background: #fff !important;
  color: #0a1932 !important;
  text-transform: uppercase !important;
  font-weight: bold !important;
  border-radius: 7px !important;
  font-size: 14px !important;

  &:focus {
    outline: 0;
  }
`;

export const ButtonSimulateFixed = styled(ButtonBase)`
  padding: 12px 15px 12px 20px !important;
  background: #ffe44d !important;
  color: #0a1932 !important;
  text-transform: uppercase !important;
  font-weight: bold !important;
  border-radius: 7px !important;
  font-size: 14px !important;
  margin-left: 12px !important;
  display: flex !important;
  align-items: center !important;
  -webkit-box-shadow: 0px 0px 56px 0px rgba(255, 228, 77, 0.34);
  -moz-box-shadow: 0px 0px 56px 0px rgba(255, 228, 77, 0.34);
  box-shadow: 0px 0px 56px 0px rgba(255, 228, 77, 0.34);

  &:focus {
    outline: 0;
  }
`;

export const Arrow = styled.div`
  transform: rotate(180deg);
  margin-left: 10px;
`;

export const ItemMobile = styled.div`
  cursor: pointer;
  color: #0a1932;
  font-size: 18px;
  width: 100%;
  text-align: center;
  font-weight: bold;
  text-transform: uppercase;

  & + & {
    margin-top: 20px;
  }
`;

export const ButtonAccountMobile = styled(ButtonBase)`
  padding: 12px 20px !important;
  width: 100% !important;
  background: #0a1932 !important;
  color: #fff !important;
  text-transform: uppercase !important;
  font-weight: bold !important;
  font-size: 18px !important;
  margin-top: 20px !important;

  &:focus {
    outline: 0;
  }
`;

export const ButtonSimulateMobile = styled(ButtonBase)`
  padding: 12px 20px !important;
  width: 100% !important;
  background: #ffe44d !important;
  color: #0a1932 !important;
  text-transform: uppercase !important;
  font-weight: bold !important;
  font-size: 18px !important;

  &:focus {
    outline: 0;
  }
`;

export const Logo = styled.div`
  cursor: pointer;
`;

export const LogoMobile = styled.div`
  cursor: pointer;
  margin: 20px 0;
  display: flex;
  justify-content: center;
`;
