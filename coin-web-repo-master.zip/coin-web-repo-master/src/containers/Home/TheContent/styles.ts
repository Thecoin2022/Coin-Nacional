import styled from 'styled-components';

export const Container = styled.main`
  flex: 1;
  background: #fff;
  display: flex;
  flex-direction: column;
`;
