import React, { Suspense } from 'react';
import { Route, Switch } from 'react-router-dom';

import routes from '../../../routes/home.routes';

import { Container } from './styles';

const loading = (
  <div className="pt-3 text-center">
    <div className="sk-spinner sk-spinner-pulse" />
  </div>
);

const TheContent: React.FC = () => {
  return (
    <Container>
      <Suspense fallback={loading}>
        <Switch>
          {routes.map((route, idx) => {
            return (
              route.component && (
                <Route
                  key={idx.toString()}
                  path={route.path}
                  exact={route.exact}
                  name={route.name}
                  component={route.component}
                />
              )
            );
          })}
        </Switch>
      </Suspense>
    </Container>
  );
};

export default React.memo(TheContent);
