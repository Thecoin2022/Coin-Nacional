import React from 'react';

import { RouteComponentProps } from 'react-router-dom';

import TheContent from '../TheContent';
import TheHeader from '../TheHeader';
import TheFooter from '../TheFooter';

import { Container } from './styles';

const TheLayout: React.FC<RouteComponentProps> = () => {
  return (
    <Container>
      <TheHeader />
      <TheContent />
      <TheFooter />
    </Container>
  );
};

export default TheLayout;
