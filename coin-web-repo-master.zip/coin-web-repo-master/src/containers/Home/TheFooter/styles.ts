import styled from 'styled-components';

export const Container = styled.div`
  background: #0a1932;
`;

export const Body = styled.div`
  width: 100%;
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 20px;
`;

export const Head = styled.div`
  padding: 70px 0;

  @media only screen and (max-width: 768px) {
    padding: 30px 0;
  }
`;

export const Bottom = styled.div`
  background: #05132a;
  padding: 30px 0;

  @media only screen and (max-width: 768px) {
    padding: 20px 0;
  }
`;

export const HeadBody = styled.div`
  display: grid;
  grid-gap: 45px;
  grid-template-columns: 1fr 1fr 1fr 1fr;

  @media only screen and (max-width: 768px) {
    grid-template-columns: 1fr 1fr;
    grid-gap: 30px;
  }

  @media only screen and (max-width: 425px) {
    grid-template-columns: 1fr;
  }
`;

export const BottomBody = styled.div`
  display: grid;
  grid-gap: 45px;
  grid-template-columns: 1fr 1fr;
  color: #fff;
  font-size: 15px;

  @media only screen and (max-width: 768px) {
    grid-template-columns: 1fr;
    grid-gap: 20px;
    text-align: center;
  }
`;

export const Box = styled.div`
  @media only screen and (max-width: 425px) {
    display: flex;
    flex-direction: column;
    align-items: center;
  }
`;

export const BottomCopy = styled.div`
  margin-top: 20px;
  text-align: center;
  color: #fff;
  font-size: 15px;
`;

export const Title = styled.div`
  font-weight: bold;
  font-size: 24px;
  color: #fff;
  text-transform: uppercase;

  @media only screen and (max-width: 768px) {
    font-size: 18px;
  }
`;

export const Item = styled.div`
  color: #fff;
  font-size: 16px;
  margin-top: 20px;

  @media only screen and (max-width: 425px) {
    text-align: center;
  }
`;
