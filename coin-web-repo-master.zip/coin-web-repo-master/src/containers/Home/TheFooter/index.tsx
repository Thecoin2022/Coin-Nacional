import React from 'react';

import { useMediaQuery } from '@material-ui/core';

import {
  Container,
  Body,
  Bottom,
  Head,
  HeadBody,
  BottomBody,
  BottomCopy,
  Title,
  Item,
  Box,
} from './styles';

const TheFooter: React.FC = () => {
  const lessThan768 = useMediaQuery('(max-width:768px)');

  return (
    <Container>
      <Head>
        <Body>
          <HeadBody>
            <Box>
              {lessThan768 ? (
                <img src="/logofootermobile.svg" alt="logo" />
              ) : (
                <img src="/logofooter.svg" alt="logo" />
              )}
            </Box>
            {lessThan768 && <div />}
            <Box>
              <Title>Produtos</Title>
              <Item>Empréstimo com garantia de Imóvel</Item>
              <Item>Empréstimo com garantia de Veículo</Item>
              <Item>Financiamento imobiliário</Item>
            </Box>
            <Box>
              <Title>Coin</Title>
              <Item>Sobre nós</Item>
              <Item>Blog</Item>
              <Item>Empréstimos</Item>
              <Item>Perguntas frequentes</Item>
              <Item>Parcerias</Item>
            </Box>
            <Box>
              <Title>Fale conosco</Title>
              <Item>(xx) xxxxx-xxxx</Item>
              <Item>contato@coin.com.br</Item>
            </Box>
          </HeadBody>
        </Body>
      </Head>
      <Bottom>
        <Body>
          <BottomBody>
            <div>
              Lorem ipsum ultricies semper diam rhoncus tristique blandit, leo
              aliquet conubia morbi donec risus nec senectus, suspendisse
              himenaeos vulputate varius leo phasellus. aenean tincidunt sapien
              at nullam commodo pretium dictumst curae curabitur, iaculis rutrum
              elit vehicula aptent torquent potenti quisque.
            </div>
            <div>
              Lorem ipsum ultricies semper diam rhoncus tristique blandit, leo
              aliquet conubia morbi donec risus nec senectus, suspendisse
              himenaeos vulputate varius leo phasellus. aenean tincidunt sapien
              at nullam commodo pretium dictumst curae curabitur, iaculis rutrum
              elit vehicula aptent torquent potenti quisque.
            </div>
          </BottomBody>
          <BottomCopy>
            Lorem ipsum curabitur rutrum a eleifend vulputate ad sodales
            adipiscing malesuada est ipsum
          </BottomCopy>
        </Body>
      </Bottom>
    </Container>
  );
};

export default TheFooter;
