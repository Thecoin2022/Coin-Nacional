export default [
  {
    _tag: 'CSidebarNavItem',
    name: 'Dashboard',
    to: '/partner/dashboard',
    icon: 'cil-speedometer',
    badge: {
      color: 'info',
      text: 'PARCEIRO',
    },
  },
  {
    _tag: 'CSidebarNavTitle',
    _children: ['Institucional'],
  },
  {
    _tag: 'CSidebarNavItem',
    name: 'Simulações',
    to: '/partner/customers',
    icon: 'cil-sitemap',
  },
];
