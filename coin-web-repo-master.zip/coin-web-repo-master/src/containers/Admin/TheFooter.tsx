import React from 'react';
import { CFooter } from '@coreui/react';

const TheFooter: React.FC = () => {
  return (
    <CFooter fixed={false}>
      <div>
        <span className="ml-1" />
      </div>
      <div className="mfs-auto">
        <span className="mr-1">Desenvolvido por Nozzen - </span>
        <a
          href="https://www.nozzen.com.br/"
          target="_blank"
          rel="noopener noreferrer"
        >
          https://www.nozzen.com.br/
        </a>
      </div>
    </CFooter>
  );
};

export default React.memo(TheFooter);
