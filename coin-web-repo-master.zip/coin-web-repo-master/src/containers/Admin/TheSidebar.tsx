import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  CCreateElement,
  CSidebar,
  CSidebarBrand,
  CSidebarNav,
  CSidebarNavDivider,
  CSidebarNavTitle,
  CSidebarNavDropdown,
  CSidebarMinimizer,
  CSidebarNavItem,
} from '@coreui/react';

import CIcon from '@coreui/icons-react';

// sidebar nav config
import navigation from './_nav';

import { Istate } from '../../store';

const TheSidebar = () => {
  const dispatch = useDispatch();
  const show = useSelector((state: Istate) => state.sidebarShow);

  return (
    <CSidebar
      show={show}
      onShowChange={(val: string) => {
        dispatch({ type: 'set', sidebarShow: val });
      }}
      className={['custom-coreui-sidebar']}
    >
      <CSidebarBrand className="d-md-down-none" to="/">
        <CIcon className="c-sidebar-brand-full" name="logo" height={35} />
        <CIcon
          className="c-sidebar-brand-minimized"
          name="sygnet"
          height={35}
        />
      </CSidebarBrand>
      <CSidebarNav>
        <CCreateElement
          items={navigation}
          components={{
            CSidebarNavDivider,
            CSidebarNavDropdown,
            CSidebarNavItem: (propsSidebarNavItem: any) => (
              <CSidebarNavItem
                {...propsSidebarNavItem}
                className="custom-coreui-sidebar-nav-item"
              />
            ),
            CSidebarNavTitle,
          }}
        />
      </CSidebarNav>
      <CSidebarMinimizer className="c-d-md-down-none" />
    </CSidebar>
  );
};

export default React.memo(TheSidebar);
