import React from 'react';
import {
  CDropdown,
  CDropdownItem,
  CDropdownMenu,
  CDropdownToggle,
} from '@coreui/react';
import CIcon from '@coreui/icons-react';

import { cilAccountLogout } from '@coreui/icons';

import { useAuth } from '../../hooks/auth';

const TheHeaderDropdown: React.FC = () => {
  const { signOut, user } = useAuth();

  return (
    <CDropdown inNav className="c-header-nav-items mx-2">
      <CDropdownToggle className="c-header-nav-link" caret={false}>
        <div>{user.name}</div>
      </CDropdownToggle>
      <CDropdownMenu className="pt-0" placement="bottom-end">
        <CDropdownItem header tag="div" color="light" className="text-center">
          <strong>Minha conta</strong>
        </CDropdownItem>
        <CDropdownItem onClick={signOut}>
          <CIcon content={cilAccountLogout} className="mfe-2" />
          Sair
        </CDropdownItem>
      </CDropdownMenu>
    </CDropdown>
  );
};

export default TheHeaderDropdown;
