export default [
  {
    _tag: 'CSidebarNavItem',
    name: 'Dashboard',
    to: '/admin/dashboard',
    icon: 'cil-speedometer',
    badge: {
      color: 'info',
      text: 'ADMIN',
    },
  },
  {
    _tag: 'CSidebarNavTitle',
    _children: ['Institucional'],
  },
  {
    _tag: 'CSidebarNavItem',
    name: 'Simulações',
    to: '/admin/customers',
    icon: 'cil-sitemap',
  },
  {
    _tag: 'CSidebarNavItem',
    name: 'Parceiros',
    to: '/admin/partners',
    icon: 'cil-briefcase',
  },
  {
    _tag: 'CSidebarNavItem',
    name: 'Perguntas Frequentes',
    to: '/admin/questions',
    icon: 'cil-chat-bubble',
  },
  {
    _tag: 'CSidebarNavItem',
    name: 'Postagens',
    to: '/admin/posts',
    icon: 'cil-short-text',
  },
  {
    _tag: 'CSidebarNavTitle',
    _children: ['Gerenciamento'],
  },
  {
    _tag: 'CSidebarNavItem',
    name: 'Status',
    to: '/admin/statuses',
    icon: 'cil-bookmark',
  },
  {
    _tag: 'CSidebarNavItem',
    name: 'Bancos',
    to: '/admin/banks',
    icon: 'cil-bank',
  },
  {
    _tag: 'CSidebarNavItem',
    name: 'Propriedades',
    to: '/admin/properties',
    icon: 'cil-building',
  },
  {
    _tag: 'CSidebarNavItem',
    name: 'Tipos de Financiamento',
    to: '/admin/types',
    icon: 'cil-dollar',
  },
];
