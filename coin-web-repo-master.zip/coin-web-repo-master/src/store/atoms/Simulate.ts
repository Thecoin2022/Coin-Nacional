import { atom } from 'recoil';

const SimulateId = atom<string>({
  key: 'SimulateId',
  default: '',
});

export { SimulateId };
