import React from 'react';

import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from 'react-router-dom';

import ScrollToTop from './components/ScrollToTop';

import { useAuth } from './hooks/auth';

import './scss/style.scss';

const loading = (
  <div className="pt-3 text-center">
    <div className="sk-spinner sk-spinner-pulse" />
  </div>
);

const Home = React.lazy(() => import('./containers/Home/TheLayout'));
const Authenticate = React.lazy(
  () => import('./containers/Authenticate/TheLayout'),
);
const Admin = React.lazy(() => import('./containers/Admin/TheLayout'));
const Partner = React.lazy(() => import('./containers/Partner/TheLayout'));

const App: React.FC = () => {
  return (
    <Router>
      <ScrollToTop />
      <React.Suspense fallback={loading}>
        <Switch>
          <LoggedRoute path="/authenticate" name="Authenticate">
            <Authenticate />
          </LoggedRoute>

          <PrivateRoute path="/admin" name="Admin">
            <AdminRoute>
              <Admin />
            </AdminRoute>
          </PrivateRoute>

          <PrivateRoute path="/partner" name="Partner">
            <PartnerRoute>
              <Partner />
            </PartnerRoute>
          </PrivateRoute>
          <Route path="/" name="Home" component={Home} />
        </Switch>
      </React.Suspense>
    </Router>
  );
};

const PrivateRoute: React.FC<any> = ({ children, ...rest }) => {
  const { user } = useAuth();

  return (
    <Route
      {...rest}
      render={({ location }) => {
        return user ? (
          children
        ) : (
          <Redirect
            to={{
              pathname: '/authenticate/login',
              state: { from: location },
            }}
          />
        );
      }}
    />
  );
};

const LoggedRoute: React.FC<any> = ({ children, ...rest }) => {
  const { user } = useAuth();

  return (
    <Route
      {...rest}
      render={({ location }) => {
        if (!user) {
          return children;
        }

        if (user.isAdmin) {
          return (
            <Redirect
              to={{
                pathname: '/admin/dashboard',
                state: { from: location },
              }}
            />
          );
        }

        if (user.isPartner) {
          return (
            <Redirect
              to={{
                pathname: '/partner/dashboard',
                state: { from: location },
              }}
            />
          );
        }

        return null;
      }}
    />
  );
};

const AdminRoute: React.FC<any> = ({ children }) => {
  const { user } = useAuth();

  if (user.isPartner) {
    return (
      <Redirect
        to={{
          pathname: '/partner/dashboard',
        }}
      />
    );
  }

  return children;
};

const PartnerRoute: React.FC<any> = ({ children }) => {
  const { user } = useAuth();

  if (user.isAdmin) {
    return (
      <Redirect
        to={{
          pathname: '/admin/dashboard',
        }}
      />
    );
  }

  return children;
};

export default App;
