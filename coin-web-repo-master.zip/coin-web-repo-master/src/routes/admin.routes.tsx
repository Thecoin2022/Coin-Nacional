import React from 'react';

import { CFade } from '@coreui/react';

import { RouteComponentProps } from 'react-router-dom';

const Dashboard = React.lazy(() => import('../views/admin/Dashboard'));

const Statuses = React.lazy(() => import('../views/admin/Statuses/Statuses'));
const Status = React.lazy(() => import('../views/admin/Statuses/Status'));
const NewStatus = React.lazy(() => import('../views/admin/Statuses/NewStatus'));

const Banks = React.lazy(() => import('../views/admin/Banks/Banks'));
const Bank = React.lazy(() => import('../views/admin/Banks/Bank'));
const NewBank = React.lazy(() => import('../views/admin/Banks/NewBank'));

const Properties = React.lazy(
  () => import('../views/admin/Properties/Properties'),
);
const Property = React.lazy(() => import('../views/admin/Properties/Property'));
const NewProperty = React.lazy(
  () => import('../views/admin/Properties/NewProperty'),
);

const Types = React.lazy(() => import('../views/admin/Types/Types'));
const Type = React.lazy(() => import('../views/admin/Types/Type'));
const NewType = React.lazy(() => import('../views/admin/Types/NewType'));

const Questions = React.lazy(
  () => import('../views/admin/Questions/Questions'),
);
const Question = React.lazy(() => import('../views/admin/Questions/Question'));
const NewQuestion = React.lazy(
  () => import('../views/admin/Questions/NewQuestion'),
);

const Posts = React.lazy(() => import('../views/admin/Posts/Posts'));
const Post = React.lazy(() => import('../views/admin/Posts/Post'));
const NewPost = React.lazy(() => import('../views/admin/Posts/NewPost'));

const Partners = React.lazy(() => import('../views/admin/Partners/Partners'));
const Partner = React.lazy(() => import('../views/admin/Partners/Partner'));
const NewPartner = React.lazy(
  () => import('../views/admin/Partners/NewPartner'),
);

const Customers = React.lazy(
  () => import('../views/admin/Customers/Customers'),
);
const NewEGI = React.lazy(() => import('../views/admin/Customers/NewEGI'));
const NewEGV = React.lazy(() => import('../views/admin/Customers/NewEGV'));
const NewFI = React.lazy(() => import('../views/admin/Customers/NewFI'));
const EGI = React.lazy(() => import('../views/admin/Customers/EGI'));
const EGV = React.lazy(() => import('../views/admin/Customers/EGV'));
const FI = React.lazy(() => import('../views/admin/Customers/FI'));

interface Iroutes {
  path: string;
  exact: boolean;
  name: string;
  component?: React.FC<RouteComponentProps>;
}

interface IContainer {
  children: React.ReactNode;
}

const Container: React.FC<IContainer> = ({ children }) => (
  <CFade>{children}</CFade>
);

const routes: Iroutes[] = [
  {
    path: '/admin/dashboard',
    exact: true,
    name: 'Dashboard',
    component: props => (
      <Container>
        <Dashboard {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/statuses',
    exact: true,
    name: 'Status',
    component: props => (
      <Container>
        <Statuses {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/statuses/new',
    exact: true,
    name: 'Novo Status',
    component: props => (
      <Container>
        <NewStatus {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/statuses/:id',
    exact: true,
    name: 'Alterar Status',
    component: props => (
      <Container>
        <Status {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/banks',
    exact: true,
    name: 'Bancos',
    component: props => (
      <Container>
        <Banks {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/banks/new',
    exact: true,
    name: 'Novo Banco',
    component: props => (
      <Container>
        <NewBank {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/banks/:id',
    exact: true,
    name: 'Alterar Banco',
    component: props => (
      <Container>
        <Bank {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/properties',
    exact: true,
    name: 'Propriedades',
    component: props => (
      <Container>
        <Properties {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/properties/new',
    exact: true,
    name: 'Nova Propriedade',
    component: props => (
      <Container>
        <NewProperty {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/properties/:id',
    exact: true,
    name: 'Alterar Propriedade',
    component: props => (
      <Container>
        <Property {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/types',
    exact: true,
    name: 'Tipos de Financiamento',
    component: props => (
      <Container>
        <Types {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/types/new',
    exact: true,
    name: 'Novo Tipo de Financiamento',
    component: props => (
      <Container>
        <NewType {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/types/:id',
    exact: true,
    name: 'Alterar Tipo de Financiamento',
    component: props => (
      <Container>
        <Type {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/questions',
    exact: true,
    name: 'Perguntas Frequentes',
    component: props => (
      <Container>
        <Questions {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/questions/new',
    exact: true,
    name: 'Nova Pergunta Frequente',
    component: props => (
      <Container>
        <NewQuestion {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/questions/:id',
    exact: true,
    name: 'Alterar Pergunta Frequente',
    component: props => (
      <Container>
        <Question {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/posts',
    exact: true,
    name: 'Postagens',
    component: props => (
      <Container>
        <Posts {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/posts/new',
    exact: true,
    name: 'Nova Postagem',
    component: props => (
      <Container>
        <NewPost {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/posts/:id',
    exact: true,
    name: 'Alterar Postagem',
    component: props => (
      <Container>
        <Post {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/partners',
    exact: true,
    name: 'Parceiros',
    component: props => (
      <Container>
        <Partners {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/partners/new',
    exact: true,
    name: 'Novo Parceiro',
    component: props => (
      <Container>
        <NewPartner {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/partners/:id',
    exact: true,
    name: 'Alterar Parceiro',
    component: props => (
      <Container>
        <Partner {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/customers',
    exact: true,
    name: 'Simulações',
    component: props => (
      <Container>
        <Customers {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/customers/newegi',
    exact: true,
    name: 'Nova Simulação de Empréstimo com Garantia de Imóvel',
    component: props => (
      <Container>
        <NewEGI {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/customers/newegv',
    exact: true,
    name: 'Nova Simulação de Empréstimo com Garantia de Veículo',
    component: props => (
      <Container>
        <NewEGV {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/customers/newfi',
    exact: true,
    name: 'Nova Simulação de Financiamento Imobiliário',
    component: props => (
      <Container>
        <NewFI {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/customers/egi/:id',
    exact: true,
    name: 'Alterar Simulação de Empréstimo com Garantia de Imóvel',
    component: props => (
      <Container>
        <EGI {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/customers/egv/:id',
    exact: true,
    name: 'Alterar Simulação de Empréstimo com Garantia de Veículo',
    component: props => (
      <Container>
        <EGV {...props} />
      </Container>
    ),
  },
  {
    path: '/admin/customers/fi/:id',
    exact: true,
    name: 'Alterar Simulação de Financiamento Imobiliário',
    component: props => (
      <Container>
        <FI {...props} />
      </Container>
    ),
  },
];

export default routes;
