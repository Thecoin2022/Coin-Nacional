import React from 'react';

import { CFade } from '@coreui/react';

import { RouteComponentProps } from 'react-router-dom';

const EGI = React.lazy(() => import('../views/home/Simulate/Journey/EGI'));
const EGV = React.lazy(() => import('../views/home/Simulate/Journey/EGV'));
const FI = React.lazy(() => import('../views/home/Simulate/Journey/FI'));
const Data = React.lazy(() => import('../views/home/Simulate/Journey/Data'));
const Result = React.lazy(
  () => import('../views/home/Simulate/Journey/Result'),
);
const Complements = React.lazy(
  () => import('../views/home/Simulate/Journey/Complements'),
);

interface Iroutes {
  path: string;
  exact: boolean;
  name: string;
  component?: React.FC<RouteComponentProps>;
}

interface IContainer {
  children: React.ReactNode;
}

const Container: React.FC<IContainer> = ({ children }) => (
  <CFade className={['container-simlulate']}>{children}</CFade>
);

const routes: Iroutes[] = [
  {
    path: '/simulacao/egi',
    exact: true,
    name: 'Simulação',
    component: props => (
      <Container>
        <EGI {...props} />
      </Container>
    ),
  },
  {
    path: '/simulacao/egv',
    exact: true,
    name: 'Simulação',
    component: props => (
      <Container>
        <EGV {...props} />
      </Container>
    ),
  },
  {
    path: '/simulacao/fi',
    exact: true,
    name: 'Simulação',
    component: props => (
      <Container>
        <FI {...props} />
      </Container>
    ),
  },
  {
    path: '/simulacao/dados',
    exact: true,
    name: 'Simulação',
    component: props => (
      <Container>
        <Data {...props} />
      </Container>
    ),
  },
  {
    path: '/simulacao/resultado',
    exact: true,
    name: 'Simulação',
    component: props => (
      <Container>
        <Result {...props} />
      </Container>
    ),
  },
  {
    path: '/simulacao/complemento',
    exact: true,
    name: 'Simulação',
    component: props => (
      <Container>
        <Complements {...props} />
      </Container>
    ),
  },
];

export default routes;
