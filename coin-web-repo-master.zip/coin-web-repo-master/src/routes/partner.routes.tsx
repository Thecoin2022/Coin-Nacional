import React from 'react';

import { CFade } from '@coreui/react';

import { RouteComponentProps } from 'react-router-dom';

const Dashboard = React.lazy(() => import('../views/partner/Dashboard'));

const Customers = React.lazy(
  () => import('../views/partner/Customers/Customers'),
);
const NewEGI = React.lazy(() => import('../views/partner/Customers/NewEGI'));
const NewEGV = React.lazy(() => import('../views/partner/Customers/NewEGV'));
const NewFI = React.lazy(() => import('../views/partner/Customers/NewFI'));
const EGI = React.lazy(() => import('../views/partner/Customers/EGI'));
const EGV = React.lazy(() => import('../views/partner/Customers/EGV'));
const FI = React.lazy(() => import('../views/partner/Customers/FI'));

interface Iroutes {
  path: string;
  exact: boolean;
  name: string;
  component?: React.FC<RouteComponentProps>;
}

interface IContainer {
  children: React.ReactNode;
}

const Container: React.FC<IContainer> = ({ children }) => (
  <CFade>{children}</CFade>
);

const routes: Iroutes[] = [
  {
    path: '/partner/dashboard',
    exact: true,
    name: 'Dashboard',
    component: props => (
      <Container>
        <Dashboard {...props} />
      </Container>
    ),
  },
  {
    path: '/partner/customers',
    exact: true,
    name: 'Simulações',
    component: props => (
      <Container>
        <Customers {...props} />
      </Container>
    ),
  },
  {
    path: '/partner/customers/newegi',
    exact: true,
    name: 'Nova Simulação de Empréstimo com Garantia de Imóvel',
    component: props => (
      <Container>
        <NewEGI {...props} />
      </Container>
    ),
  },
  {
    path: '/partner/customers/newegv',
    exact: true,
    name: 'Nova Simulação de Empréstimo com Garantia de Veículo',
    component: props => (
      <Container>
        <NewEGV {...props} />
      </Container>
    ),
  },
  {
    path: '/partner/customers/newfi',
    exact: true,
    name: 'Nova Simulação de Financiamento Imobiliário',
    component: props => (
      <Container>
        <NewFI {...props} />
      </Container>
    ),
  },
  {
    path: '/partner/customers/egi/:id',
    exact: true,
    name: 'Alterar Simulação de Empréstimo com Garantia de Imóvel',
    component: props => (
      <Container>
        <EGI {...props} />
      </Container>
    ),
  },
  {
    path: '/partner/customers/egv/:id',
    exact: true,
    name: 'Alterar Simulação de Empréstimo com Garantia de Veículo',
    component: props => (
      <Container>
        <EGV {...props} />
      </Container>
    ),
  },
  {
    path: '/partner/customers/fi/:id',
    exact: true,
    name: 'Alterar Simulação de Financiamento Imobiliário',
    component: props => (
      <Container>
        <FI {...props} />
      </Container>
    ),
  },
];

export default routes;
