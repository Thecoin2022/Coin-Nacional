import React from 'react';

import { CFade } from '@coreui/react';

import { RouteComponentProps } from 'react-router-dom';

import Home from '../views/home/Home';
import Contact from '../views/home/Contact';
import Thanks from '../views/home/Thanks';
import Partners from '../views/home/Partners';
import About from '../views/home/About';
import Questions from '../views/home/Questions';
import Partner from '../views/home/Partner';
import PartnerThanks from '../views/home/PartnerThanks';
import Post from '../views/home/Post';
import Posts from '../views/home/Posts';
import EGI from '../views/home/EGI';
import EGV from '../views/home/EGV';
import FI from '../views/home/FI';

import Simulate from '../views/home/Simulate';
import Journey from '../views/home/Simulate/Journey';
import SimulateThanks from '../views/home/Simulate/Thanks';

interface Iroutes {
  path: string;
  exact: boolean;
  name: string;
  component?: React.FC<RouteComponentProps>;
}

interface IContainer {
  children: React.ReactNode;
}

const Container: React.FC<IContainer> = ({ children }) => (
  <CFade className={['container-home']}>{children}</CFade>
);

const routes: Iroutes[] = [
  {
    path: '/',
    exact: true,
    name: 'Home',
    component: props => (
      <Container>
        <Home {...props} />
      </Container>
    ),
  },
  {
    path: '/contato',
    exact: true,
    name: 'Contato',
    component: props => (
      <Container>
        <Contact {...props} />
      </Container>
    ),
  },
  {
    path: '/contato/enviado',
    exact: true,
    name: 'Obrigado',
    component: props => (
      <Container>
        <Thanks {...props} />
      </Container>
    ),
  },
  {
    path: '/parceiros',
    exact: true,
    name: 'Parceiros',
    component: props => (
      <Container>
        <Partners {...props} />
      </Container>
    ),
  },
  {
    path: '/sobre',
    exact: true,
    name: 'Sobre nós',
    component: props => (
      <Container>
        <About {...props} />
      </Container>
    ),
  },
  {
    path: '/faq',
    exact: true,
    name: 'FAQ',
    component: props => (
      <Container>
        <Questions {...props} />
      </Container>
    ),
  },
  {
    path: '/parceiro',
    exact: true,
    name: 'Parceiro',
    component: props => (
      <Container>
        <Partner {...props} />
      </Container>
    ),
  },
  {
    path: '/parceiro/obrigado',
    exact: true,
    name: 'Obrigado Parceiro',
    component: props => (
      <Container>
        <PartnerThanks {...props} />
      </Container>
    ),
  },
  {
    path: '/blog',
    exact: true,
    name: 'Postagens',
    component: props => (
      <Container>
        <Posts {...props} />
      </Container>
    ),
  },
  {
    path: '/blog/:id',
    exact: true,
    name: 'Postagem',
    component: props => (
      <Container>
        <Post {...props} />
      </Container>
    ),
  },
  {
    path: '/simulacao',
    exact: true,
    name: 'Simulação',
    component: props => (
      <Container>
        <Simulate {...props} />
      </Container>
    ),
  },
  {
    path: '/simulacao/obrigado',
    exact: true,
    name: 'Simulação Obrigado',
    component: props => (
      <Container>
        <SimulateThanks {...props} />
      </Container>
    ),
  },
  {
    path: '/simulacao',
    exact: false,
    name: 'Simulação',
    component: props => (
      <Container>
        <Journey {...props} />
      </Container>
    ),
  },
  {
    path: '/egi',
    exact: false,
    name: 'Simulação',
    component: props => (
      <Container>
        <EGI {...props} />
      </Container>
    ),
  },
  {
    path: '/egv',
    exact: false,
    name: 'Simulação',
    component: props => (
      <Container>
        <EGV {...props} />
      </Container>
    ),
  },
  {
    path: '/fi',
    exact: false,
    name: 'Simulação',
    component: props => (
      <Container>
        <FI {...props} />
      </Container>
    ),
  },
];

export default routes;
