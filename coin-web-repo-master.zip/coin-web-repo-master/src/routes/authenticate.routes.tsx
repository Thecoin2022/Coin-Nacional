import React from 'react';

import { CFade } from '@coreui/react';

import { RouteComponentProps } from 'react-router-dom';

const Login = React.lazy(() => import('../views/authenticate/Login'));
const Forgot = React.lazy(() => import('../views/authenticate/Login/Forgot'));
const Reset = React.lazy(() => import('../views/authenticate/Login/Reset'));

interface Iroutes {
  path: string;
  exact: boolean;
  name: string;
  component?: React.FC<RouteComponentProps>;
}

interface IContainer {
  children: React.ReactNode;
}

const Container: React.FC<IContainer> = ({ children }) => (
  <CFade>{children}</CFade>
);

const routes: Iroutes[] = [
  {
    path: '/authenticate/login',
    exact: true,
    name: 'Login',
    component: props => (
      <Container>
        <Login {...props} />
      </Container>
    ),
  },
  {
    path: '/authenticate/forgot',
    exact: true,
    name: 'Esqueci minha senha',
    component: props => (
      <Container>
        <Forgot {...props} />
      </Container>
    ),
  },
  {
    path: '/authenticate/reset/:token',
    exact: true,
    name: 'Resetar minha senha',
    component: props => (
      <Container>
        <Reset {...props} />
      </Container>
    ),
  },
];

export default routes;
