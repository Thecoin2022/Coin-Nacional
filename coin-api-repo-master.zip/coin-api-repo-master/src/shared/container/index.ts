import { container } from 'tsyringe';

import '@modules/users/providers';
import './providers';

import IUsersRepository from '@modules/users/repositories/IUsersRepository';
import UsersRepository from '@modules/users/infra/typeorm/repositories/UsersRepository';

import IUsersTokensRepository from '@modules/users/repositories/IUsersTokensRepository';
import UserTokensRepository from '@modules/users/infra/typeorm/repositories/UserTokenRepository';

import ICustomersRepository from '@modules/customers/repositories/ICustomersRepository';
import CustomersRepository from '@modules/customers/infra/typeorm/repositories/CustomersRepository';

import IStatusesRepository from '@modules/statuses/repositories/IStatusesRepository';
import StatusesRepository from '@modules/statuses/infra/typeorm/repositories/StatusesRepository';

import IBanksRepository from '@modules/banks/repositories/IBanksRepository';
import BanksRepository from '@modules/banks/infra/typeorm/repositories/BanksRepository';

import ITypesRepository from '@modules/types/repositories/ITypesRepository';
import TypesRepository from '@modules/types/infra/typeorm/repositories/TypesRepository';

import IPropertiesRepository from '@modules/properties/repositories/IPropertiesRepository';
import PropertiesRepository from '@modules/properties/infra/typeorm/repositories/PropertiesRepository';

import IQuestionsRepository from '@modules/questions/repositories/IQuestionsRepository';
import QuestionsRepository from '@modules/questions/infra/typeorm/repositories/QuestionsRepository';

import IPostsRepository from '@modules/posts/repositories/IPostsRepository';
import PostsRepository from '@modules/posts/infra/typeorm/repositories/PostsRepository';

import IPartnersRepository from '@modules/partners/repositories/IPartnersRepository';
import PartnersRepository from '@modules/partners/infra/typeorm/repositories/PartnersRepository';

container.registerSingleton<IUsersRepository>(
  'UsersRepository',
  UsersRepository,
);

container.registerSingleton<IUsersTokensRepository>(
  'UserTokensRepository',
  UserTokensRepository,
);

container.registerSingleton<ICustomersRepository>(
  'CustomersRepository',
  CustomersRepository,
);

container.registerSingleton<IStatusesRepository>(
  'StatusesRepository',
  StatusesRepository,
);

container.registerSingleton<IBanksRepository>(
  'BanksRepository',
  BanksRepository,
);

container.registerSingleton<ITypesRepository>(
  'TypesRepository',
  TypesRepository,
);

container.registerSingleton<IPropertiesRepository>(
  'PropertiesRepository',
  PropertiesRepository,
);

container.registerSingleton<IQuestionsRepository>(
  'QuestionsRepository',
  QuestionsRepository,
);

container.registerSingleton<IPostsRepository>(
  'PostsRepository',
  PostsRepository,
);

container.registerSingleton<IPartnersRepository>(
  'PartnersRepository',
  PartnersRepository,
);
