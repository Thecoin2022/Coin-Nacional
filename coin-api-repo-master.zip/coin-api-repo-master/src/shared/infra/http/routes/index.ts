import { Router } from 'express';

import usersRouter from '@modules/users/infra/http/routes/users.routes';
import sessionsRouter from '@modules/users/infra/http/routes/sessions.routes';
import passwordRouter from '@modules/users/infra/http/routes/password.routes';
import profileRouter from '@modules/users/infra/http/routes/profile.routes';

import customersRouter from '@modules/customers/infra/http/routes/customers.routes';
import statusesRouter from '@modules/statuses/infra/http/routes/statuses.routes';
import banksRouter from '@modules/banks/infra/http/routes/banks.routes';
import typesRouter from '@modules/types/infra/http/routes/types.routes';
import propertiesRouter from '@modules/properties/infra/http/routes/properties.routes';
import questionsRouter from '@modules/questions/infra/http/routes/questions.routes';
import postsRouter from '@modules/posts/infra/http/routes/posts.routes';
import partnersRouter from '@modules/partners/infra/http/routes/partners.routes';
import contactRouter from '@modules/contact/infra/http/routes/contact.routes';

const routes = Router({ mergeParams: true });

routes.use('/users', usersRouter);
routes.use('/sessions', sessionsRouter);
routes.use('/password', passwordRouter);
routes.use('/profile', profileRouter);

routes.use('/customers', customersRouter);
routes.use('/statuses', statusesRouter);
routes.use('/banks', banksRouter);
routes.use('/types', typesRouter);
routes.use('/properties', propertiesRouter);
routes.use('/questions', questionsRouter);
routes.use('/posts', postsRouter);
routes.use('/partners', partnersRouter);
routes.use('/contact', contactRouter);

export default routes;
