import {
  MigrationInterface,
  QueryRunner,
  Table,
  TableForeignKey,
} from 'typeorm';

export default class CreateCustomers1601692269587
  implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.createTable(
      new Table({
        name: 'customers',
        columns: [
          {
            name: 'id',
            type: 'uuid',
            isPrimary: true,
            generationStrategy: 'uuid',
            default: 'uuid_generate_v4()',
          },
          {
            name: 'user_id',
            type: 'uuid',
            isNullable: true,
          },
          {
            name: 'type_id',
            type: 'uuid',
            isNullable: true,
          },
          {
            name: 'step',
            type: 'int',
          },
          {
            name: 'status_id',
            type: 'uuid',
            isNullable: true,
          },
          {
            name: 'name',
            type: 'varchar',
            isNullable: true,
          },
          {
            name: 'mother_name',
            type: 'varchar',
            isNullable: true,
          },
          {
            name: 'document_type',
            type: 'varchar',
            isNullable: true,
          },
          {
            name: 'document',
            type: 'varchar',
            isNullable: true,
          },
          {
            name: 'email',
            type: 'varchar',
            isNullable: true,
          },
          {
            name: 'phone',
            type: 'varchar',
            isNullable: true,
          },
          {
            name: 'birth',
            type: 'timestamp',
            isNullable: true,
          },
          {
            name: 'cep',
            type: 'varchar',
          },
          {
            name: 'amount',
            type: 'int',
          },
          {
            name: 'months',
            type: 'int',
          },
          {
            name: 'income',
            type: 'int',
            isNullable: true,
          },
          {
            name: 'has_property',
            type: 'boolean',
          },
          {
            name: 'vehicle_owner',
            type: 'boolean',
          },
          {
            name: 'vehicle_year',
            type: 'int',
            isNullable: true,
          },
          {
            name: 'vehicle_financed',
            type: 'boolean',
          },
          {
            name: 'installments',
            type: 'int',
            isNullable: true,
          },
          {
            name: 'financed_amount',
            type: 'int',
            isNullable: true,
          },
          {
            name: 'property_id',
            type: 'uuid',
            isNullable: true,
          },
          {
            name: 'bank_id',
            type: 'uuid',
            isNullable: true,
          },
          {
            name: 'created_at',
            type: 'timestamp',
            default: 'now()',
          },
          {
            name: 'updated_at',
            type: 'timestamp',
            default: 'now()',
          },
        ],
      }),
    );

    await queryRunner.createForeignKey(
      'customers',
      new TableForeignKey({
        name: 'CustomerUser',
        columnNames: ['user_id'],
        referencedColumnNames: ['id'],
        referencedTableName: 'users',
        onDelete: 'SET NULL',
        onUpdate: 'CASCADE',
      }),
    );

    await queryRunner.createForeignKey(
      'customers',
      new TableForeignKey({
        name: 'CustomerType',
        columnNames: ['type_id'],
        referencedColumnNames: ['id'],
        referencedTableName: 'types',
        onDelete: 'SET NULL',
        onUpdate: 'CASCADE',
      }),
    );

    await queryRunner.createForeignKey(
      'customers',
      new TableForeignKey({
        name: 'CustomerStatus',
        columnNames: ['status_id'],
        referencedColumnNames: ['id'],
        referencedTableName: 'statuses',
        onDelete: 'SET NULL',
        onUpdate: 'CASCADE',
      }),
    );

    await queryRunner.createForeignKey(
      'customers',
      new TableForeignKey({
        name: 'CustomerProperty',
        columnNames: ['property_id'],
        referencedColumnNames: ['id'],
        referencedTableName: 'properties',
        onDelete: 'SET NULL',
        onUpdate: 'CASCADE',
      }),
    );

    await queryRunner.createForeignKey(
      'customers',
      new TableForeignKey({
        name: 'CustomerBank',
        columnNames: ['bank_id'],
        referencedColumnNames: ['id'],
        referencedTableName: 'banks',
        onDelete: 'SET NULL',
        onUpdate: 'CASCADE',
      }),
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.dropForeignKey('customers', 'CustomerBank');

    await queryRunner.dropForeignKey('customers', 'CustomerProperty');

    await queryRunner.dropForeignKey('customers', 'CustomerStatus');

    await queryRunner.dropForeignKey('customers', 'CustomerType');

    await queryRunner.dropForeignKey('customers', 'CustomerUser');

    await queryRunner.dropTable('customers');
  }
}
