export default {
  jwt: {
    secret: '594be328577e50533dd6dfcf91b83aae',
    expiresIn: '1d',
  },
};
