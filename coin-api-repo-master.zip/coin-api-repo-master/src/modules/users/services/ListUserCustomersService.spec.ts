import FakeCustomersRepository from '@modules/customers/repositories/fakes/FakeCustomersRepository';
import FakeUsersRepository from '../repositories/fakes/FakeUsersRepository';
import ListUserCustomersService from './ListUserCustomersService';

let fakeUsersRepository: FakeUsersRepository;
let fakeCustomersRepository: FakeCustomersRepository;

let listUserCustomers: ListUserCustomersService;

describe('ListUserCustomers', () => {
  beforeEach(() => {
    fakeUsersRepository = new FakeUsersRepository();
    fakeCustomersRepository = new FakeCustomersRepository();

    listUserCustomers = new ListUserCustomersService(fakeCustomersRepository);
  });

  it('should be able to list user customers', async () => {
    const user = await fakeUsersRepository.create({
      name: 'John Doe',
      email: 'johndoe@example.com',
      password: '123456',
    });

    await fakeCustomersRepository.create({
      amount: 20,
      cep: '74000000',
      months: 48,
      status_id: 'non-valid-status-id',
      type_id: 'non-valid-type-id',
    });

    const customer = await fakeCustomersRepository.create({
      user_id: user.id,
      amount: 10,
      cep: '75000000',
      months: 48,
      status_id: 'non-valid-status-id',
      type_id: 'non-valid-type-id',
    });

    const customers = await listUserCustomers.execute({ user_id: user.id });

    expect(customers).toStrictEqual([customer]);
  });
});
