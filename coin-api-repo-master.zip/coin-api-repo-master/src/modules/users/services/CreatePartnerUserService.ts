import path from 'path';

import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';

import IMailProvider from '@shared/container/providers/MailProvider/models/IMailProvider';
import IPartnersRepository from '@modules/partners/repositories/IPartnersRepository';

import User from '../infra/typeorm/entities/User';
import IUsersRepository from '../repositories/IUsersRepository';
import IHashProvider from '../providers/HashProvider/models/IHashProvider';
import IRandomProvider from '../providers/RandomProvider/models/IRandomProvider';

interface IRequest {
  partner_id?: string;
}

@injectable()
class CreateUserService {
  constructor(
    @inject('UsersRepository')
    private usersRepository: IUsersRepository,

    @inject('PartnersRepository')
    private partnersRepository: IPartnersRepository,

    @inject('MailProvider')
    private mailProvider: IMailProvider,

    @inject('RandomProvider')
    private randomProvider: IRandomProvider,

    @inject('HashProvider')
    private hashProvider: IHashProvider,
  ) {}

  public async execute({ partner_id }: IRequest): Promise<User> {
    const partner = await this.partnersRepository.findById(partner_id);

    if (!partner) {
      throw new AppError('Partner does not exists');
    }

    const checkUserExists = await this.usersRepository.findByEmail(
      partner.email,
    );

    if (checkUserExists) {
      throw new AppError('Partner email address already used');
    }

    const password = await this.randomProvider.generateString(12);

    const hashedPassword = await this.hashProvider.generateHash(password);

    const user = await this.usersRepository.create({
      name: partner.name,
      email: partner.email,
      isAdmin: false,
      isPartner: true,
      partner_id,
      password: hashedPassword,
    });

    const forgotPasswordTemplate = path.resolve(
      __dirname,
      '..',
      'views',
      'create_partner_user.hbs',
    );

    this.mailProvider.sendMail({
      to: {
        name: user.name,
        email: user.email,
      },
      subject: '[Coin] Sua conta foi aprovada!',
      templateData: {
        file: forgotPasswordTemplate,
        variables: {
          name: user.name,
          password,
          link: `${process.env.APP_WEB_URL}/authenticate/login`,
        },
      },
    });

    return user;
  }
}

export default CreateUserService;
