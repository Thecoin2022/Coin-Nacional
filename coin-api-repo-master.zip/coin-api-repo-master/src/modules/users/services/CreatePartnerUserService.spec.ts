import AppError from '@shared/errors/AppError';

import FakePartnersRepository from '@modules/partners/repositories/fakes/FakePartnersRepository';
import FakeMailProdiver from '@shared/container/providers/MailProvider/fakes/FakeMailProvider';
import FakeUsersRepository from '../repositories/fakes/FakeUsersRepository';
import FakeHashProvider from '../providers/HashProvider/fakes/FakeHashProvider';
import CreatePartnerUserService from './CreatePartnerUserService';
import FakeRandomProvider from '../providers/RandomProvider/fakes/FakeRandomProvider';

let fakeUsersRepository: FakeUsersRepository;
let fakePartnersRepository: FakePartnersRepository;
let fakeMailProdiver: FakeMailProdiver;
let fakeRandomProvider: FakeRandomProvider;
let fakeHashProvider: FakeHashProvider;

let createPartnerUser: CreatePartnerUserService;

describe('CreatePartnerUser', () => {
  beforeEach(() => {
    fakeUsersRepository = new FakeUsersRepository();
    fakePartnersRepository = new FakePartnersRepository();
    fakeMailProdiver = new FakeMailProdiver();
    fakeRandomProvider = new FakeRandomProvider();
    fakeHashProvider = new FakeHashProvider();

    createPartnerUser = new CreatePartnerUserService(
      fakeUsersRepository,
      fakePartnersRepository,
      fakeMailProdiver,
      fakeRandomProvider,
      fakeHashProvider,
    );
  });

  it('should be able to create a new user from partner', async () => {
    const partner = await fakePartnersRepository.create({
      name: 'John Doe',
      email: 'johndoe@gmail.com',
      phone: '62988888888',
      employees_amount: 50,
    });

    const user = await createPartnerUser.execute({
      partner_id: partner.id,
    });

    expect(user).toHaveProperty('id');
  });

  it('should not be able to create a new user from non existing provider', async () => {
    expect(
      createPartnerUser.execute({
        partner_id: 'non-existing-provider-id',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });

  it('should not be able to create a new user with same email from another', async () => {
    const partner = await fakePartnersRepository.create({
      name: 'John Doe',
      email: 'johndoe@gmail.com',
      phone: '62988888888',
      employees_amount: 50,
    });

    await createPartnerUser.execute({
      partner_id: partner.id,
    });

    const otherPartner = await fakePartnersRepository.create({
      name: 'John Tre',
      email: 'johndoe@gmail.com',
      phone: '63988888888',
      employees_amount: 60,
    });

    expect(
      createPartnerUser.execute({
        partner_id: otherPartner.id,
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
