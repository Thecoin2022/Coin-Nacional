import { injectable, inject } from 'tsyringe';

import Customer from '@modules/customers/infra/typeorm/entities/Customer';
import ICustomersRepository from '@modules/customers/repositories/ICustomersRepository';

interface IRequest {
  user_id: string;
}

@injectable()
class ListUserCustomersService {
  constructor(
    @inject('CustomersRepository')
    private customersRepository: ICustomersRepository,
  ) {}

  public async execute({ user_id }: IRequest): Promise<Customer[]> {
    const customers = await this.customersRepository.findByUserId(user_id);

    return customers;
  }
}

export default ListUserCustomersService;
