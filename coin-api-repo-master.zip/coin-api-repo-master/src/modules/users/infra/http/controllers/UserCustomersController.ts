import { Request, Response } from 'express';

import { container } from 'tsyringe';

import ListUserCustomersService from '@modules/users/services/ListUserCustomersService';

export default class UserCustomersController {
  public async index(req: Request, res: Response): Promise<Response> {
    const listUserCustomers = container.resolve(ListUserCustomersService);

    const customers = await listUserCustomers.execute({ user_id: req.user.id });

    return res.json(customers);
  }
}
