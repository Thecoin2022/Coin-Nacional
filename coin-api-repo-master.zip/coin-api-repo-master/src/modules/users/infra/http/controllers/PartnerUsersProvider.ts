import { Request, Response } from 'express';

import { container } from 'tsyringe';

import CreatePartnerUserService from '@modules/users/services/CreatePartnerUserService';

export default class PartnerUsersProvider {
  public async create(req: Request, res: Response): Promise<Response> {
    const createProviderUser = container.resolve(CreatePartnerUserService);

    const user = await createProviderUser.execute(req.body);

    delete user.password;

    return res.json(user);
  }
}
