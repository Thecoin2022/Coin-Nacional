import { Router } from 'express';
import { celebrate, Segments, Joi } from 'celebrate';

import PartnerUsersProvider from '../controllers/PartnerUsersProvider';

import ensureAuthenticated from '../middlewares/ensureAuthenticated';

const partnerUsersRouter = Router();
const partnerUsersProvider = new PartnerUsersProvider();

partnerUsersRouter.use(ensureAuthenticated);

partnerUsersRouter.post(
  '/',
  celebrate({
    [Segments.BODY]: {
      partner_id: Joi.string().required(),
    },
  }),
  partnerUsersProvider.create,
);

export default partnerUsersRouter;
