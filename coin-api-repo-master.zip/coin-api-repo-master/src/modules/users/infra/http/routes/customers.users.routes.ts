import { Router } from 'express';

import UserCustomersController from '../controllers/UserCustomersController';

import ensureAuthenticated from '../middlewares/ensureAuthenticated';

const customersUsersRouter = Router();
const userCustomersController = new UserCustomersController();

customersUsersRouter.use(ensureAuthenticated);

customersUsersRouter.get('/', userCustomersController.index);

export default customersUsersRouter;
