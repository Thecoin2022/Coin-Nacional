import Question from '../infra/typeorm/entities/Question';
import ICreateQuestionDTO from '../dtos/ICreateQuestionDTO';

export default interface IQuestionsRepository {
  findById(id: string): Promise<Question | undefined>;
  create(data: ICreateQuestionDTO): Promise<Question>;
  delete(question: Question): Promise<void>;
  list(): Promise<Question[]>;
  save(question: Question): Promise<Question>;
}
