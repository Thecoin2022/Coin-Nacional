import { uuid } from 'uuidv4';

import IQuestionsRepository from '@modules/questions/repositories/IQuestionsRepository';
import ICreateQuestionDTO from '@modules/questions/dtos/ICreateQuestionDTO';

import Question from '../../infra/typeorm/entities/Question';

class QuestionsRepository implements IQuestionsRepository {
  private questions: Question[] = [];

  public async findById(id: string): Promise<Question | undefined> {
    const findQuestion = this.questions.find(question => question.id === id);

    return findQuestion;
  }

  public async create(questionData: ICreateQuestionDTO): Promise<Question> {
    const question = new Question();

    Object.assign(question, { id: uuid() }, questionData);

    this.questions.push(question);

    return question;
  }

  public async delete(question: Question): Promise<void> {
    this.questions = this.questions.filter(
      findQuestion => findQuestion.id !== question.id,
    );
  }

  public async list(): Promise<Question[]> {
    return this.questions;
  }

  public async save(question: Question): Promise<Question> {
    const findIndex = this.questions.findIndex(
      findQuestion => findQuestion.id === question.id,
    );

    this.questions[findIndex] = question;

    return question;
  }
}

export default QuestionsRepository;
