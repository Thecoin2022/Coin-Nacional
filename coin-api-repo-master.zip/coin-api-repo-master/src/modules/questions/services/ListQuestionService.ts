import { injectable, inject } from 'tsyringe';

import Question from '../infra/typeorm/entities/Question';
import IQuestionsRepository from '../repositories/IQuestionsRepository';

@injectable()
class ListQuestionService {
  constructor(
    @inject('QuestionsRepository')
    private questionsRepository: IQuestionsRepository,
  ) {}

  public async execute(): Promise<Question[]> {
    const questions = await this.questionsRepository.list();

    return questions;
  }
}

export default ListQuestionService;
