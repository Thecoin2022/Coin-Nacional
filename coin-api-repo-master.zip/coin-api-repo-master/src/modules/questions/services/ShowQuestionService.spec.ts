import AppError from '@shared/errors/AppError';
import FakeQuestionsRepository from '../repositories/fakes/FakeQuestionsRepository';
import ShowQuestionService from './ShowQuestionService';

let fakeQuestionsRepository: FakeQuestionsRepository;

let showQuestion: ShowQuestionService;

describe('ShowQuestion', () => {
  beforeEach(() => {
    fakeQuestionsRepository = new FakeQuestionsRepository();

    showQuestion = new ShowQuestionService(fakeQuestionsRepository);
  });

  it('should be able to show a question', async () => {
    const question = await fakeQuestionsRepository.create({
      question: 'why?',
      answer: 'couse',
    });

    const findQuestion = await showQuestion.execute({
      question_id: question.id,
    });

    expect(findQuestion).toBe(question);
  });

  it('should not be able to show a non existing question', async () => {
    expect(
      showQuestion.execute({
        question_id: 'non-existing-question-id',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
