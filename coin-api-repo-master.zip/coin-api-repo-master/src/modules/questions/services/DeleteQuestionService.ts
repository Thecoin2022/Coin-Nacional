import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';
import IQuestionsRepository from '../repositories/IQuestionsRepository';

interface IRequest {
  question_id: string;
}

@injectable()
class DeleteQuestionService {
  constructor(
    @inject('QuestionsRepository')
    private questionsRepository: IQuestionsRepository,
  ) {}

  public async execute({ question_id }: IRequest): Promise<void> {
    const question = await this.questionsRepository.findById(question_id);

    if (!question) {
      throw new AppError('Question not found', 404);
    }

    await this.questionsRepository.delete(question);
  }
}

export default DeleteQuestionService;
