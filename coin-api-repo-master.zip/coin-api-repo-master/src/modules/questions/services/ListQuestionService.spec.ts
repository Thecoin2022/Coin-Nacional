import FakeQuestionsRepository from '../repositories/fakes/FakeQuestionsRepository';
import ListQuestionService from './ListQuestionService';

let fakeQuestionsRepository: FakeQuestionsRepository;

let listQuestion: ListQuestionService;

describe('ListQuestion', () => {
  beforeEach(() => {
    fakeQuestionsRepository = new FakeQuestionsRepository();

    listQuestion = new ListQuestionService(fakeQuestionsRepository);
  });

  it('should be able to list questions', async () => {
    const question = await fakeQuestionsRepository.create({
      question: 'why?',
      answer: 'couse',
    });

    const questions = await listQuestion.execute();

    expect(questions).toStrictEqual([question]);
  });
});
