import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';
import Question from '../infra/typeorm/entities/Question';
import IQuestionsRepository from '../repositories/IQuestionsRepository';

interface IRequest {
  question_id: string;
  question: string;
  answer: string;
}

@injectable()
class UpdateQuestionService {
  constructor(
    @inject('QuestionsRepository')
    private questionsRepository: IQuestionsRepository,
  ) {}

  public async execute({
    question_id,
    ...restQuestionData
  }: IRequest): Promise<Question> {
    const question = await this.questionsRepository.findById(question_id);

    if (!question) {
      throw new AppError('Question not found', 404);
    }

    Object.assign(question, restQuestionData);

    await this.questionsRepository.save(question);

    return question;
  }
}

export default UpdateQuestionService;
