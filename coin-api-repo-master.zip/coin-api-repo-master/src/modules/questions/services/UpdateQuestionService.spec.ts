import AppError from '@shared/errors/AppError';
import FakeQuestionsRepository from '../repositories/fakes/FakeQuestionsRepository';
import UpdateQuestionService from './UpdateQuestionService';

let fakeQuestionsRepository: FakeQuestionsRepository;

let updateQuestion: UpdateQuestionService;

describe('UpdateQuestion', () => {
  beforeEach(() => {
    fakeQuestionsRepository = new FakeQuestionsRepository();

    updateQuestion = new UpdateQuestionService(fakeQuestionsRepository);
  });

  it('should be able to update a question', async () => {
    const question = await fakeQuestionsRepository.create({
      question: 'why?',
      answer: 'couse',
    });

    await updateQuestion.execute({
      question_id: question.id,
      question: 'when?',
      answer: 'becouse',
    });

    expect(question).toHaveProperty('id');
    expect(question.question).toBe('when?');
    expect(question.answer).toBe('becouse');
  });

  it('should not be able to update a non existing question', async () => {
    expect(
      updateQuestion.execute({
        question_id: 'non-existing-question-id',
        question: 'when?',
        answer: 'becouse',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
