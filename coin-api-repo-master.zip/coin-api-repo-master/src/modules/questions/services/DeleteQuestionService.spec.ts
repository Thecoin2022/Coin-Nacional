import AppError from '@shared/errors/AppError';
import FakeQuestionsRepository from '../repositories/fakes/FakeQuestionsRepository';
import DeleteQuestionService from './DeleteQuestionService';

let fakeQuestionsRepository: FakeQuestionsRepository;

let deleteQuestion: DeleteQuestionService;

describe('DeleteQuestion', () => {
  beforeEach(() => {
    fakeQuestionsRepository = new FakeQuestionsRepository();

    deleteQuestion = new DeleteQuestionService(fakeQuestionsRepository);
  });

  it('should be able to delete a question', async () => {
    const question = await fakeQuestionsRepository.create({
      question: 'why?',
      answer: 'couse',
    });

    await deleteQuestion.execute({
      question_id: question.id,
    });

    const findQuestion = await fakeQuestionsRepository.findById(question.id);

    expect(findQuestion).toBeUndefined();
  });

  it('should not be able to delete a non existing question', async () => {
    expect(
      deleteQuestion.execute({
        question_id: 'non-existing-question-id',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
