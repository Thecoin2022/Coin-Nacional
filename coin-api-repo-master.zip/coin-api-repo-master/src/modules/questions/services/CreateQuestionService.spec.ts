import FakeQuestionsRepository from '../repositories/fakes/FakeQuestionsRepository';
import CreateQuestionService from './CreateQuestionService';

let fakeQuestionsRepository: FakeQuestionsRepository;

let createQuestion: CreateQuestionService;

describe('CreateQuestion', () => {
  beforeEach(() => {
    fakeQuestionsRepository = new FakeQuestionsRepository();

    createQuestion = new CreateQuestionService(fakeQuestionsRepository);
  });

  it('should be able to create a new question', async () => {
    const question = await createQuestion.execute({
      question: 'why?',
      answer: 'couse',
    });

    expect(question).toHaveProperty('id');
    expect(question.question).toBe('why?');
    expect(question.answer).toBe('couse');
  });
});
