import { injectable, inject } from 'tsyringe';

import Question from '../infra/typeorm/entities/Question';
import IQuestionsRepository from '../repositories/IQuestionsRepository';

interface IRequest {
  question: string;
  answer: string;
}

@injectable()
class CreateQuestionService {
  constructor(
    @inject('QuestionsRepository')
    private questionsRepository: IQuestionsRepository,
  ) {}

  public async execute(questionData: IRequest): Promise<Question> {
    const question = await this.questionsRepository.create(questionData);

    return question;
  }
}

export default CreateQuestionService;
