import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';

import Question from '../infra/typeorm/entities/Question';
import IQuestionsRepository from '../repositories/IQuestionsRepository';

interface IRequest {
  question_id: string;
}

@injectable()
class ShowQuestionService {
  constructor(
    @inject('QuestionsRepository')
    private questionsRepository: IQuestionsRepository,
  ) {}

  public async execute({ question_id }: IRequest): Promise<Question> {
    const question = await this.questionsRepository.findById(question_id);

    if (!question) {
      throw new AppError('Question not found', 404);
    }

    return question;
  }
}

export default ShowQuestionService;
