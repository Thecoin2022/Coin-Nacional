export default interface ICreateQuestionDTO {
  question: string;
  answer: string;
}
