import { getRepository, Repository } from 'typeorm';

import IQuestionsRepository from '@modules/questions/repositories/IQuestionsRepository';
import ICreateQuestionDTO from '@modules/questions/dtos/ICreateQuestionDTO';

import Question from '../entities/Question';

class QuestionsRepository implements IQuestionsRepository {
  private ormRepository: Repository<Question>;

  constructor() {
    this.ormRepository = getRepository(Question);
  }

  public async findById(id: string): Promise<Question | undefined> {
    const question = await this.ormRepository.findOne(id);

    return question;
  }

  public async create(questionData: ICreateQuestionDTO): Promise<Question> {
    const question = this.ormRepository.create(questionData);

    await this.ormRepository.save(question);

    return question;
  }

  public async list(): Promise<Question[]> {
    const questions = await this.ormRepository.find();

    return questions;
  }

  public async delete(question: Question): Promise<void> {
    await this.ormRepository.delete({ id: question.id });
  }

  public async save(question: Question): Promise<Question> {
    return this.ormRepository.save(question);
  }
}

export default QuestionsRepository;
