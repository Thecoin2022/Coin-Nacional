import { Router } from 'express';

import { celebrate, Segments, Joi } from 'celebrate';

import ensureAuthenticated from '@modules/users/infra/http/middlewares/ensureAuthenticated';

import QuestionsController from '../controllers/QuestionsController';

const questionsRouter = Router({ mergeParams: true });
const questionsController = new QuestionsController();

questionsRouter.get('/', questionsController.index);

questionsRouter.use(ensureAuthenticated);

questionsRouter.get(
  '/:id',
  celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().uuid().required(),
    },
  }),
  questionsController.show,
);

questionsRouter.post(
  '/',
  celebrate({
    [Segments.BODY]: {
      question: Joi.string().required(),
      answer: Joi.string().required(),
    },
  }),
  questionsController.create,
);

questionsRouter.patch(
  '/:id',
  celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().uuid().required(),
    },
    [Segments.BODY]: {
      question: Joi.string().required(),
      answer: Joi.string().required(),
    },
  }),
  questionsController.update,
);

questionsRouter.delete(
  '/:id',
  celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().uuid().required(),
    },
  }),
  questionsController.delete,
);

export default questionsRouter;
