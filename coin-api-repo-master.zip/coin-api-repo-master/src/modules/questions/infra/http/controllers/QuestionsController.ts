import { Request, Response } from 'express';

import { container } from 'tsyringe';

import CreateQuestionService from '@modules/questions/services/CreateQuestionService';
import UpdateQuestionService from '@modules/questions/services/UpdateQuestionService';
import DeleteQuestionService from '@modules/questions/services/DeleteQuestionService';
import ListQuestionService from '@modules/questions/services/ListQuestionService';
import ShowQuestionService from '@modules/questions/services/ShowQuestionService';

export default class QuestionsController {
  public async index(req: Request, res: Response): Promise<Response> {
    const listQuestion = container.resolve(ListQuestionService);

    const questions = await listQuestion.execute();

    return res.json(questions);
  }

  public async show(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const showQuestion = container.resolve(ShowQuestionService);

    const question = await showQuestion.execute({ question_id: id });

    return res.json(question);
  }

  public async create(req: Request, res: Response): Promise<Response> {
    const createQuestion = container.resolve(CreateQuestionService);

    const question = await createQuestion.execute(req.body);

    return res.json(question);
  }

  public async update(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const updateQuestion = container.resolve(UpdateQuestionService);

    const question = await updateQuestion.execute({
      question_id: id,
      ...req.body,
    });

    return res.json(question);
  }

  public async delete(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const deleteQuestion = container.resolve(DeleteQuestionService);

    await deleteQuestion.execute({
      question_id: id,
    });

    return res.json();
  }
}
