import { Request, Response } from 'express';

import { container } from 'tsyringe';

import SendContactEmailService from '@modules/contact/services/SendContactEmailService';

export default class PartnerUsersProvider {
  public async create(req: Request, res: Response): Promise<Response> {
    const sendContactEmail = container.resolve(SendContactEmailService);

    await sendContactEmail.execute(req.body);

    return res.json();
  }
}
