import { Router } from 'express';
import { celebrate, Segments, Joi } from 'celebrate';

import ContactController from '../controllers/ContactController';

const contactRouter = Router();
const contactController = new ContactController();

contactRouter.post(
  '/',
  celebrate({
    [Segments.BODY]: {
      name: Joi.string().required(),
      email: Joi.string().required(),
      phone: Joi.string().required(),
      title: Joi.string().required(),
      message: Joi.string().required(),
    },
  }),
  contactController.create,
);

export default contactRouter;
