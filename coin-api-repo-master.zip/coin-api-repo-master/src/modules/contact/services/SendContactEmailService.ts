import 'reflect-metadata';
import { injectable, inject } from 'tsyringe';
import path from 'path';

import IMailProvider from '@shared/container/providers/MailProvider/models/IMailProvider';

interface IRequest {
  name: string;
  email: string;
  phone: string;
  title: string;
  message: string;
}

@injectable()
class SendContactEmailService {
  constructor(
    @inject('MailProvider')
    private mailProvider: IMailProvider,
  ) {}

  public async execute(dataEmail: IRequest): Promise<void> {
    const forgotPasswordTemplate = path.resolve(
      __dirname,
      '..',
      'views',
      'send_contact_email.hbs',
    );

    await this.mailProvider.sendMail({
      to: {
        name: 'Vinicius',
        email: 'johndoe@gmail.com',
      },
      subject: '[Coin] Recuperação de senha',
      templateData: {
        file: forgotPasswordTemplate,
        variables: {
          ...dataEmail,
        },
      },
    });
  }
}

export default SendContactEmailService;
