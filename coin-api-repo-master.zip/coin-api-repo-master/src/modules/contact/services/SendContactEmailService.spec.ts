import FakeMailProvider from '@shared/container/providers/MailProvider/fakes/FakeMailProvider';
import SendContactEmailService from './SendContactEmailService';

let fakeMailProvider: FakeMailProvider;
let sendContactEmailService: SendContactEmailService;

describe('SendContactEmail', () => {
  beforeEach(() => {
    fakeMailProvider = new FakeMailProvider();

    sendContactEmailService = new SendContactEmailService(fakeMailProvider);
  });

  it('should send contact email', async () => {
    const sendMail = jest.spyOn(fakeMailProvider, 'sendMail');

    await sendContactEmailService.execute({
      email: 'email@email.com',
      message: 'message',
      name: 'John Doe',
      phone: '62988888888',
      title: 'title',
    });

    expect(sendMail).toHaveBeenCalled();
  });
});
