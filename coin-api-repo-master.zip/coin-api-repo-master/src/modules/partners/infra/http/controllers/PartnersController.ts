import { Request, Response } from 'express';

import { container } from 'tsyringe';

import CreatePartnerService from '@modules/partners/services/CreatePartnerService';
import UpdatePartnerService from '@modules/partners/services/UpdatePartnerService';
import DeletePartnerService from '@modules/partners/services/DeletePartnerService';
import ListPartnerService from '@modules/partners/services/ListPartnerService';
import ShowPartnerService from '@modules/partners/services/ShowPartnerService';

export default class PartnersController {
  public async index(req: Request, res: Response): Promise<Response> {
    const listPartner = container.resolve(ListPartnerService);

    const partners = await listPartner.execute();

    return res.json(partners);
  }

  public async show(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const showPartner = container.resolve(ShowPartnerService);

    const partner = await showPartner.execute({ partner_id: id });

    return res.json(partner);
  }

  public async create(req: Request, res: Response): Promise<Response> {
    const createPartner = container.resolve(CreatePartnerService);

    const partner = await createPartner.execute(req.body);

    return res.json(partner);
  }

  public async update(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const updatePartner = container.resolve(UpdatePartnerService);

    const partner = await updatePartner.execute({
      partner_id: id,
      ...req.body,
    });

    return res.json(partner);
  }

  public async delete(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const deletePartner = container.resolve(DeletePartnerService);

    await deletePartner.execute({
      partner_id: id,
    });

    return res.json();
  }
}
