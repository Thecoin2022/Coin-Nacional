import { Router } from 'express';

import { celebrate, Segments, Joi } from 'celebrate';

import ensureAuthenticated from '@modules/users/infra/http/middlewares/ensureAuthenticated';

import PartnersController from '../controllers/PartnersController';

const partnersRouter = Router({ mergeParams: true });
const partnersController = new PartnersController();

partnersRouter.use(ensureAuthenticated);

partnersRouter.get('/', partnersController.index);

partnersRouter.get(
  '/:id',
  celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().uuid().required(),
    },
  }),
  partnersController.show,
);

partnersRouter.post(
  '/',
  celebrate({
    [Segments.BODY]: {
      name: Joi.string().required(),
      email: Joi.string().required(),
      phone: Joi.string().required(),
      employees_amount: Joi.number().required(),
      description: Joi.string().empty(''),
    },
  }),
  partnersController.create,
);

partnersRouter.patch(
  '/:id',
  celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().uuid().required(),
    },
    [Segments.BODY]: {
      name: Joi.string(),
      email: Joi.string(),
      phone: Joi.string(),
      employees_amount: Joi.number(),
      description: Joi.string(),
      approved: Joi.boolean(),
    },
  }),
  partnersController.update,
);

partnersRouter.delete(
  '/:id',
  celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().uuid().required(),
    },
  }),
  partnersController.delete,
);

export default partnersRouter;
