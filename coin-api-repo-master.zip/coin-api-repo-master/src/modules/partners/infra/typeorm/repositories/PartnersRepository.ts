import { getRepository, Repository } from 'typeorm';

import IPartnersRepository from '@modules/partners/repositories/IPartnersRepository';
import ICreatePartnerDTO from '@modules/partners/dtos/ICreatePartnerDTO';

import Partner from '../entities/Partner';

class PartnersRepository implements IPartnersRepository {
  private ormRepository: Repository<Partner>;

  constructor() {
    this.ormRepository = getRepository(Partner);
  }

  public async findById(id: string): Promise<Partner | undefined> {
    const partner = await this.ormRepository.findOne(id);

    return partner;
  }

  public async create(partnerData: ICreatePartnerDTO): Promise<Partner> {
    const partner = this.ormRepository.create(partnerData);

    await this.ormRepository.save(partner);

    return partner;
  }

  public async list(): Promise<Partner[]> {
    const partners = await this.ormRepository.find();

    return partners;
  }

  public async delete(partner: Partner): Promise<void> {
    await this.ormRepository.delete({ id: partner.id });
  }

  public async save(partner: Partner): Promise<Partner> {
    return this.ormRepository.save(partner);
  }
}

export default PartnersRepository;
