export default interface ICreatePartnerDTO {
  name: string;
  email: string;
  phone: string;
  employees_amount: number;
  description?: string;
}
