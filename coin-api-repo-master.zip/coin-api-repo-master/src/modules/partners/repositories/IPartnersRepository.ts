import Partner from '../infra/typeorm/entities/Partner';
import ICreatePartnerDTO from '../dtos/ICreatePartnerDTO';

export default interface IPartnersRepository {
  findById(id: string): Promise<Partner | undefined>;
  create(data: ICreatePartnerDTO): Promise<Partner>;
  delete(partner: Partner): Promise<void>;
  list(): Promise<Partner[]>;
  save(partner: Partner): Promise<Partner>;
}
