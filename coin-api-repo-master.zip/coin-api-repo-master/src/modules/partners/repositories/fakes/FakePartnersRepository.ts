import { uuid } from 'uuidv4';

import IPartnersRepository from '@modules/partners/repositories/IPartnersRepository';
import ICreatePartnerDTO from '@modules/partners/dtos/ICreatePartnerDTO';

import Partner from '../../infra/typeorm/entities/Partner';

class PartnersRepository implements IPartnersRepository {
  private partners: Partner[] = [];

  public async findById(id: string): Promise<Partner | undefined> {
    const findPartner = this.partners.find(partner => partner.id === id);

    return findPartner;
  }

  public async create(partnerData: ICreatePartnerDTO): Promise<Partner> {
    const partner = new Partner();

    Object.assign(partner, { id: uuid() }, partnerData);

    this.partners.push(partner);

    return partner;
  }

  public async delete(partner: Partner): Promise<void> {
    this.partners = this.partners.filter(
      findPartner => findPartner.id !== partner.id,
    );
  }

  public async list(): Promise<Partner[]> {
    return this.partners;
  }

  public async save(partner: Partner): Promise<Partner> {
    const findIndex = this.partners.findIndex(
      findPartner => findPartner.id === partner.id,
    );

    this.partners[findIndex] = partner;

    return partner;
  }
}

export default PartnersRepository;
