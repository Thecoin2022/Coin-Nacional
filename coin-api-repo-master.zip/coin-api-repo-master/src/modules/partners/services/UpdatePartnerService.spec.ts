import AppError from '@shared/errors/AppError';
import FakePartnersRepository from '../repositories/fakes/FakePartnersRepository';
import UpdatePartnerService from './UpdatePartnerService';

let fakePartnersRepository: FakePartnersRepository;

let updatePartner: UpdatePartnerService;

describe('UpdatePartner', () => {
  beforeEach(() => {
    fakePartnersRepository = new FakePartnersRepository();

    updatePartner = new UpdatePartnerService(fakePartnersRepository);
  });

  it('should be able to update a partner', async () => {
    const partner = await fakePartnersRepository.create({
      name: 'serasa',
      email: 'serasa@example.com',
      employees_amount: 50,
      phone: '62988888888',
    });

    await updatePartner.execute({
      partner_id: partner.id,
      name: 'flambas',
      email: 'flambas@example.com',
      employees_amount: 40,
      phone: '63988888888',
      approved: true,
    });

    expect(partner).toHaveProperty('id');
    expect(partner.name).toBe('flambas');
    expect(partner.email).toBe('flambas@example.com');
    expect(partner.employees_amount).toBe(40);
    expect(partner.phone).toBe('63988888888');
    expect(partner.approved).toBeTruthy();
  });

  it('should not be able to update a non existing partner', async () => {
    expect(
      updatePartner.execute({
        partner_id: 'non-existing-partner-id',
        name: 'flambas',
        email: 'flambas@example.com',
        employees_amount: 40,
        phone: '63988888888',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
