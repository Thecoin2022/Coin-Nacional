import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';
import Partner from '../infra/typeorm/entities/Partner';
import IPartnersRepository from '../repositories/IPartnersRepository';

interface IRequest {
  partner_id: string;
  name?: string;
  email?: string;
  phone?: string;
  employees_amount?: number;
  description?: string;
  approved?: boolean;
}

@injectable()
class UpdatePartnerService {
  constructor(
    @inject('PartnersRepository')
    private partnersRepository: IPartnersRepository,
  ) {}

  public async execute({
    partner_id,
    ...restPartnerData
  }: IRequest): Promise<Partner> {
    const partner = await this.partnersRepository.findById(partner_id);

    if (!partner) {
      throw new AppError('Partner not found', 404);
    }

    Object.assign(partner, restPartnerData);

    await this.partnersRepository.save(partner);

    return partner;
  }
}

export default UpdatePartnerService;
