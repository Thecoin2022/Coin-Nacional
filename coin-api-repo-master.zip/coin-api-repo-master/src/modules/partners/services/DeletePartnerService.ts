import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';
import IPartnersRepository from '../repositories/IPartnersRepository';

interface IRequest {
  partner_id: string;
}

@injectable()
class DeletePartnerService {
  constructor(
    @inject('PartnersRepository')
    private partnersRepository: IPartnersRepository,
  ) {}

  public async execute({ partner_id }: IRequest): Promise<void> {
    const partner = await this.partnersRepository.findById(partner_id);

    if (!partner) {
      throw new AppError('Partner not found', 404);
    }

    await this.partnersRepository.delete(partner);
  }
}

export default DeletePartnerService;
