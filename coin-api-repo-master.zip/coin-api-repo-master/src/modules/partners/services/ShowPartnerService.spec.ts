import AppError from '@shared/errors/AppError';
import FakePartnersRepository from '../repositories/fakes/FakePartnersRepository';
import ShowPartnerService from './ShowPartnerService';

let fakePartnersRepository: FakePartnersRepository;

let showPartner: ShowPartnerService;

describe('ShowPartner', () => {
  beforeEach(() => {
    fakePartnersRepository = new FakePartnersRepository();

    showPartner = new ShowPartnerService(fakePartnersRepository);
  });

  it('should be able to show a partner', async () => {
    const partner = await fakePartnersRepository.create({
      name: 'serasa',
      email: 'serasa@example.com',
      employees_amount: 50,
      phone: '62988888888',
    });

    const findPartner = await showPartner.execute({
      partner_id: partner.id,
    });

    expect(findPartner).toBe(partner);
  });

  it('should not be able to show a non existing partner', async () => {
    expect(
      showPartner.execute({
        partner_id: 'non-existing-partner-id',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
