import FakePartnersRepository from '../repositories/fakes/FakePartnersRepository';
import ListPartnerService from './ListPartnerService';

let fakePartnersRepository: FakePartnersRepository;

let listPartner: ListPartnerService;

describe('ListPartner', () => {
  beforeEach(() => {
    fakePartnersRepository = new FakePartnersRepository();

    listPartner = new ListPartnerService(fakePartnersRepository);
  });

  it('should be able to list partners', async () => {
    const partner = await fakePartnersRepository.create({
      name: 'serasa',
      email: 'serasa@example.com',
      employees_amount: 50,
      phone: '62988888888',
    });

    const partners = await listPartner.execute();

    expect(partners).toStrictEqual([partner]);
  });
});
