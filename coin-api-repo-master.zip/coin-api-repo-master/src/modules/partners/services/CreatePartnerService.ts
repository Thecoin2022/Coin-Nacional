import { injectable, inject } from 'tsyringe';

import Partner from '../infra/typeorm/entities/Partner';
import IPartnersRepository from '../repositories/IPartnersRepository';

interface IRequest {
  name: string;
  email: string;
  phone: string;
  employees_amount: number;
  description?: string;
}

@injectable()
class CreatePartnerService {
  constructor(
    @inject('PartnersRepository')
    private partnersRepository: IPartnersRepository,
  ) {}

  public async execute(partnerData: IRequest): Promise<Partner> {
    const partner = await this.partnersRepository.create(partnerData);

    return partner;
  }
}

export default CreatePartnerService;
