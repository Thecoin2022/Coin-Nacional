import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';

import Partner from '../infra/typeorm/entities/Partner';
import IPartnersRepository from '../repositories/IPartnersRepository';

interface IRequest {
  partner_id: string;
}

@injectable()
class ShowPartnerService {
  constructor(
    @inject('PartnersRepository')
    private partnersRepository: IPartnersRepository,
  ) {}

  public async execute({ partner_id }: IRequest): Promise<Partner> {
    const partner = await this.partnersRepository.findById(partner_id);

    if (!partner) {
      throw new AppError('Partner not found', 404);
    }

    return partner;
  }
}

export default ShowPartnerService;
