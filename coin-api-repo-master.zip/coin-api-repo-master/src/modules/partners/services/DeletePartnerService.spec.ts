import AppError from '@shared/errors/AppError';
import FakePartnersRepository from '../repositories/fakes/FakePartnersRepository';
import DeletePartnerService from './DeletePartnerService';

let fakePartnersRepository: FakePartnersRepository;

let deletePartner: DeletePartnerService;

describe('DeletePartner', () => {
  beforeEach(() => {
    fakePartnersRepository = new FakePartnersRepository();

    deletePartner = new DeletePartnerService(fakePartnersRepository);
  });

  it('should be able to delete a partner', async () => {
    const partner = await fakePartnersRepository.create({
      name: 'serasa',
      email: 'serasa@example.com',
      employees_amount: 50,
      phone: '62988888888',
    });

    await deletePartner.execute({
      partner_id: partner.id,
    });

    const findPartner = await fakePartnersRepository.findById(partner.id);

    expect(findPartner).toBeUndefined();
  });

  it('should not be able to delete a non existing partner', async () => {
    expect(
      deletePartner.execute({
        partner_id: 'non-existing-partner-id',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
