import FakePartnersRepository from '../repositories/fakes/FakePartnersRepository';
import CreatePartnerService from './CreatePartnerService';

let fakePartnersRepository: FakePartnersRepository;

let createPartner: CreatePartnerService;

describe('CreatePartner', () => {
  beforeEach(() => {
    fakePartnersRepository = new FakePartnersRepository();

    createPartner = new CreatePartnerService(fakePartnersRepository);
  });

  it('should be able to create a new partner', async () => {
    const partner = await createPartner.execute({
      name: 'serasa',
      email: 'serasa@example.com',
      employees_amount: 50,
      phone: '62988888888',
    });

    expect(partner).toHaveProperty('id');
    expect(partner.name).toBe('serasa');
    expect(partner.email).toBe('serasa@example.com');
    expect(partner.employees_amount).toBe(50);
    expect(partner.phone).toBe('62988888888');
    expect(partner.approved).toBeFalsy();
  });
});
