import { injectable, inject } from 'tsyringe';

import Partner from '../infra/typeorm/entities/Partner';
import IPartnersRepository from '../repositories/IPartnersRepository';

@injectable()
class ListPartnerService {
  constructor(
    @inject('PartnersRepository')
    private partnersRepository: IPartnersRepository,
  ) {}

  public async execute(): Promise<Partner[]> {
    const partners = await this.partnersRepository.list();

    return partners;
  }
}

export default ListPartnerService;
