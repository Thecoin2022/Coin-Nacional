export default interface ICreateTypeDTO {
  name: string;
}
