import { injectable, inject } from 'tsyringe';

import Type from '../infra/typeorm/entities/Type';
import ITypesRepository from '../repositories/ITypesRepository';

@injectable()
class ListTypeService {
  constructor(
    @inject('TypesRepository')
    private typesRepository: ITypesRepository,
  ) {}

  public async execute(): Promise<Type[]> {
    const types = await this.typesRepository.list();

    return types;
  }
}

export default ListTypeService;
