import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';

import Type from '../infra/typeorm/entities/Type';
import ITypesRepository from '../repositories/ITypesRepository';

interface IRequest {
  type_id: string;
}

@injectable()
class ShowTypeService {
  constructor(
    @inject('TypesRepository')
    private typesRepository: ITypesRepository,
  ) {}

  public async execute({ type_id }: IRequest): Promise<Type> {
    const type = await this.typesRepository.findById(type_id);

    if (!type) {
      throw new AppError('Type not found', 404);
    }

    return type;
  }
}

export default ShowTypeService;
