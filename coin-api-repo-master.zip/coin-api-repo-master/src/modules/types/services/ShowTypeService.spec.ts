import AppError from '@shared/errors/AppError';
import FakeTypesRepository from '../repositories/fakes/FakeTypesRepository';
import ShowTypeService from './ShowTypeService';

let fakeTypesRepository: FakeTypesRepository;

let showType: ShowTypeService;

describe('ShowType', () => {
  beforeEach(() => {
    fakeTypesRepository = new FakeTypesRepository();

    showType = new ShowTypeService(fakeTypesRepository);
  });

  it('should be able to show a type', async () => {
    const type = await fakeTypesRepository.create({
      name: 'available',
    });

    const findType = await showType.execute({
      type_id: type.id,
    });

    expect(findType).toBe(type);
  });

  it('should not be able to show a non existing type', async () => {
    expect(
      showType.execute({
        type_id: 'non-existing-type-id',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
