import FakeTypesRepository from '../repositories/fakes/FakeTypesRepository';
import ListTypeService from './ListTypeService';

let fakeTypesRepository: FakeTypesRepository;

let listType: ListTypeService;

describe('ListType', () => {
  beforeEach(() => {
    fakeTypesRepository = new FakeTypesRepository();

    listType = new ListTypeService(fakeTypesRepository);
  });

  it('should be able to list types', async () => {
    const type = await fakeTypesRepository.create({
      name: 'itau',
    });

    const types = await listType.execute();

    expect(types).toStrictEqual([type]);
  });
});
