import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';
import ITypesRepository from '../repositories/ITypesRepository';

interface IRequest {
  type_id: string;
}

@injectable()
class DeleteTypeService {
  constructor(
    @inject('TypesRepository')
    private typesRepository: ITypesRepository,
  ) {}

  public async execute({ type_id }: IRequest): Promise<void> {
    const type = await this.typesRepository.findById(type_id);

    if (!type) {
      throw new AppError('Type not found', 404);
    }

    await this.typesRepository.delete(type);
  }
}

export default DeleteTypeService;
