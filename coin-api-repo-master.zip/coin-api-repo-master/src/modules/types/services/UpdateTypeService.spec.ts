import AppError from '@shared/errors/AppError';
import FakeTypesRepository from '../repositories/fakes/FakeTypesRepository';
import UpdateTypeService from './UpdateTypeService';

let fakeTypesRepository: FakeTypesRepository;

let updateType: UpdateTypeService;

describe('UpdateType', () => {
  beforeEach(() => {
    fakeTypesRepository = new FakeTypesRepository();

    updateType = new UpdateTypeService(fakeTypesRepository);
  });

  it('should be able to update a type', async () => {
    const type = await fakeTypesRepository.create({
      name: 'available',
    });

    await updateType.execute({
      type_id: type.id,
      name: 'other-name',
    });

    expect(type).toHaveProperty('id');
    expect(type.name).toBe('other-name');
  });

  it('should not be able to update a non existing type', async () => {
    expect(
      updateType.execute({
        type_id: 'non-existing-type-id',
        name: 'other-name',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
