import { injectable, inject } from 'tsyringe';

import Type from '../infra/typeorm/entities/Type';
import ITypesRepository from '../repositories/ITypesRepository';

interface IRequest {
  name: string;
}

@injectable()
class CreateTypeService {
  constructor(
    @inject('TypesRepository')
    private typesRepository: ITypesRepository,
  ) {}

  public async execute(typeData: IRequest): Promise<Type> {
    const type = await this.typesRepository.create(typeData);

    return type;
  }
}

export default CreateTypeService;
