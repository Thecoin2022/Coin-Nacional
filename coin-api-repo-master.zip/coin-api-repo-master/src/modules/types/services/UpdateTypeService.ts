import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';
import Type from '../infra/typeorm/entities/Type';
import ITypesRepository from '../repositories/ITypesRepository';

interface IRequest {
  type_id: string;
  name: string;
}

@injectable()
class UpdateTypeService {
  constructor(
    @inject('TypesRepository')
    private typesRepository: ITypesRepository,
  ) {}

  public async execute({ type_id, ...restTypeData }: IRequest): Promise<Type> {
    const type = await this.typesRepository.findById(type_id);

    if (!type) {
      throw new AppError('Type not found', 404);
    }

    Object.assign(type, restTypeData);

    await this.typesRepository.save(type);

    return type;
  }
}

export default UpdateTypeService;
