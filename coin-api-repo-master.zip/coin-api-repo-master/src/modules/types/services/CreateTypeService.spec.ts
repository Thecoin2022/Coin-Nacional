import FakeTypesRepository from '../repositories/fakes/FakeTypesRepository';
import CreateTypeService from './CreateTypeService';

let fakeTypesRepository: FakeTypesRepository;

let createType: CreateTypeService;

describe('CreateType', () => {
  beforeEach(() => {
    fakeTypesRepository = new FakeTypesRepository();

    createType = new CreateTypeService(fakeTypesRepository);
  });

  it('should be able to create a new type', async () => {
    const type = await createType.execute({
      name: 'Imovel',
    });

    expect(type).toHaveProperty('id');
    expect(type.name).toBe('Imovel');
  });
});
