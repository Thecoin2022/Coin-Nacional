import AppError from '@shared/errors/AppError';
import FakeTypesRepository from '../repositories/fakes/FakeTypesRepository';
import DeleteTypeService from './DeleteTypeService';

let fakeTypesRepository: FakeTypesRepository;

let deleteType: DeleteTypeService;

describe('DeleteType', () => {
  beforeEach(() => {
    fakeTypesRepository = new FakeTypesRepository();

    deleteType = new DeleteTypeService(fakeTypesRepository);
  });

  it('should be able to delete a type', async () => {
    const type = await fakeTypesRepository.create({
      name: 'available',
    });

    await deleteType.execute({
      type_id: type.id,
    });

    const findType = await fakeTypesRepository.findById(type.id);

    expect(findType).toBeUndefined();
  });

  it('should not be able to delete a non existing type', async () => {
    expect(
      deleteType.execute({
        type_id: 'non-existing-type-id',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
