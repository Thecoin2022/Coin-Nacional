import { Request, Response } from 'express';

import { container } from 'tsyringe';

import CreateTypeService from '@modules/types/services/CreateTypeService';
import UpdateTypeService from '@modules/types/services/UpdateTypeService';
import DeleteTypeService from '@modules/types/services/DeleteTypeService';
import ListTypeService from '@modules/types/services/ListTypeService';
import ShowTypeService from '@modules/types/services/ShowTypeService';

export default class TypesController {
  public async index(req: Request, res: Response): Promise<Response> {
    const listType = container.resolve(ListTypeService);

    const types = await listType.execute();

    return res.json(types);
  }

  public async show(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const showType = container.resolve(ShowTypeService);

    const type = await showType.execute({ type_id: id });

    return res.json(type);
  }

  public async create(req: Request, res: Response): Promise<Response> {
    const createType = container.resolve(CreateTypeService);

    const type = await createType.execute(req.body);

    return res.json(type);
  }

  public async update(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const updateType = container.resolve(UpdateTypeService);

    const type = await updateType.execute({
      type_id: id,
      ...req.body,
    });

    return res.json(type);
  }

  public async delete(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const deleteType = container.resolve(DeleteTypeService);

    await deleteType.execute({
      type_id: id,
    });

    return res.json();
  }
}
