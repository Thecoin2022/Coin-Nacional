import { getRepository, Repository } from 'typeorm';

import IBanksRepository from '@modules/banks/repositories/IBanksRepository';
import ICreateBankDTO from '@modules/banks/dtos/ICreateBankDTO';

import Type from '../entities/Type';

class TypesRepository implements IBanksRepository {
  private ormRepository: Repository<Type>;

  constructor() {
    this.ormRepository = getRepository(Type);
  }

  public async findById(id: string): Promise<Type | undefined> {
    const type = await this.ormRepository.findOne(id);

    return type;
  }

  public async create(typeData: ICreateBankDTO): Promise<Type> {
    const type = this.ormRepository.create(typeData);

    await this.ormRepository.save(type);

    return type;
  }

  public async list(): Promise<Type[]> {
    const types = await this.ormRepository.find();

    return types;
  }

  public async delete(type: Type): Promise<void> {
    await this.ormRepository.delete({ id: type.id });
  }

  public async save(type: Type): Promise<Type> {
    return this.ormRepository.save(type);
  }
}

export default TypesRepository;
