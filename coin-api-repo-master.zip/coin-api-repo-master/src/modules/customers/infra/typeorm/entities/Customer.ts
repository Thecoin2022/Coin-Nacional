import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity('customers')
class Customer {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid', nullable: true })
  user_id: string;

  @Column({ type: 'uuid', nullable: true })
  type_id: string;

  @Column('int')
  step = 1;

  @Column({ type: 'uuid', nullable: true })
  status_id: string;

  @Column({ default: null, nullable: true })
  name: string;

  @Column({ default: null, nullable: true })
  mother_name: string;

  @Column({ default: null, nullable: true })
  document_type: string;

  @Column({ default: null, nullable: true })
  document: string;

  @Column({ default: null, nullable: true })
  email: string;

  @Column({ default: null, nullable: true })
  phone: string;

  @Column({ type: 'timestamp', default: null, nullable: true })
  birth: Date;

  @Column()
  cep: string;

  @Column('int')
  amount: number;

  @Column('int')
  months: number;

  @Column({ type: 'int', default: null, nullable: true })
  income: number;

  @Column('boolean')
  has_property = false;

  @Column('boolean')
  vehicle_owner = false;

  @Column({ type: 'int', default: null, nullable: true })
  vehicle_year: number;

  @Column('boolean')
  vehicle_financed = false;

  @Column({ type: 'int', default: null, nullable: true })
  installments: number;

  @Column({ type: 'int', default: null, nullable: true })
  financed_amount: number;

  @Column({ type: 'uuid', default: null, nullable: true })
  property_id: string;

  @Column({ type: 'uuid', default: null, nullable: true })
  bank_id: string;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date;
}

export default Customer;
