import { Router } from 'express';

import { celebrate, Segments, Joi } from 'celebrate';

import CustomersController from '../controllers/CustomersController';

const customersRouter = Router({ mergeParams: true });
const customersController = new CustomersController();

customersRouter.get('/', customersController.index);

customersRouter.get(
  '/:id',
  celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().uuid().required(),
    },
  }),
  customersController.show,
);

customersRouter.post(
  '/',
  celebrate({
    [Segments.BODY]: {
      user_id: Joi.string(),
      amount: Joi.number().required(),
      months: Joi.number().required(),
      cep: Joi.string().required(),
      status_id: Joi.string().required(),
      type_id: Joi.string().required(),
      step: Joi.number(),
      name: Joi.string(),
      mother_name: Joi.string(),
      document_type: Joi.string(),
      document: Joi.string(),
      email: Joi.string(),
      phone: Joi.string(),
      birth: Joi.date(),
      income: Joi.number(),
      has_property: Joi.boolean(),
      vehicle_owner: Joi.boolean(),
      vehicle_year: Joi.number(),
      vehicle_financed: Joi.boolean(),
      property_id: Joi.string(),
    },
  }),
  customersController.create,
);

customersRouter.patch(
  '/:id',
  celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().uuid().required(),
    },
    [Segments.BODY]: {
      amount: Joi.number(),
      months: Joi.number(),
      cep: Joi.string(),
      status_id: Joi.string(),
      type_id: Joi.string(),
      step: Joi.number(),
      name: Joi.string(),
      mother_name: Joi.string(),
      document_type: Joi.string(),
      document: Joi.string(),
      email: Joi.string(),
      phone: Joi.string(),
      birth: Joi.date(),
      income: Joi.number(),
      has_property: Joi.boolean(),
      vehicle_owner: Joi.boolean(),
      vehicle_year: Joi.number(),
      vehicle_financed: Joi.boolean(),
      installments: Joi.number(),
      financed_amount: Joi.number(),
      property_id: Joi.string(),
      bank_id: Joi.string().allow(null),
    },
  }),
  customersController.update,
);

customersRouter.delete(
  '/:id',
  celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().uuid().required(),
    },
  }),
  customersController.delete,
);

export default customersRouter;
