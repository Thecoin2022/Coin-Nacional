import path from 'path';

import { format } from 'date-fns';

import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';
import IMailProvider from '@shared/container/providers/MailProvider/models/IMailProvider';
import ITypesRepository from '@modules/types/repositories/ITypesRepository';

import Customer from '../infra/typeorm/entities/Customer';
import ICustomersRepository from '../repositories/ICustomersRepository';

interface IRequest {
  customer_id: string;
  amount?: number;
  months?: number;
  cep?: string;
  status_id?: string;
  type_id?: string;
  step?: number;
  name?: string;
  mother_name?: string;
  document_type?: string;
  document?: string;
  email?: string;
  phone?: string;
  birth?: Date;
  income?: number;
  has_property?: boolean;
  vehicle_owner?: boolean;
  vehicle_year?: number;
  vehicle_financed?: boolean;
  installments?: number;
  financed_amount?: number;
  property_id?: string;
  bank_id?: string;
}

@injectable()
class UpdateCustomerService {
  constructor(
    @inject('CustomersRepository')
    private customersRepository: ICustomersRepository,

    @inject('TypesRepository')
    private typesRepository: ITypesRepository,

    @inject('MailProvider')
    private mailProvider: IMailProvider,
  ) {}

  public async execute({
    customer_id,
    ...restCustomerData
  }: IRequest): Promise<Customer> {
    const customer = await this.customersRepository.findById(customer_id);

    if (!customer) {
      throw new AppError('Customer not found', 404);
    }

    Object.assign(customer, restCustomerData);

    await this.customersRepository.save(customer);

    if (restCustomerData.step === 2) {
      const type = await this.typesRepository.findById(customer.type_id);

      const simulateCreateTemplate = path.resolve(
        __dirname,
        '..',
        'views',
        'simulate_data.hbs',
      );

      this.mailProvider.sendMail({
        to: {
          name: 'COIN',
          email: 'contato@coin.com.br',
        },
        subject: '[COIN] Simulação completa',
        templateData: {
          file: simulateCreateTemplate,
          variables: {
            name: customer.name,
            document_type: customer.document_type,
            document: customer.document,
            birth: format(customer.birth, 'dd/MM/yyyy'),
            email: customer.email,
            phone: customer.phone,
            cep: customer.cep,
            months: customer.months,
            amount: new Intl.NumberFormat('pt-BR').format(customer.amount),
            type: type.name,
          },
        },
      });
    }

    return customer;
  }
}

export default UpdateCustomerService;
