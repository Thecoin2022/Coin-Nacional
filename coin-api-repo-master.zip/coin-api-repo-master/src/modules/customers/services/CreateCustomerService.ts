import path from 'path';
import { injectable, inject } from 'tsyringe';

import IMailProvider from '@shared/container/providers/MailProvider/models/IMailProvider';
import Customer from '../infra/typeorm/entities/Customer';
import ICustomersRepository from '../repositories/ICustomersRepository';

interface IRequest {
  user_id?: string;
  amount: number;
  months: number;
  cep: string;
  status_id: string;
  type_id: string;
  step?: number;
  name?: string;
  mother_name?: string;
  document_type?: string;
  document?: string;
  email?: string;
  phone?: string;
  birth?: Date;
  income?: number;
  has_property?: boolean;
  vehicle_owner?: boolean;
  vehicle_year?: number;
  vehicle_financed?: boolean;
  property_id?: string;
}

@injectable()
class CreateCustomerService {
  constructor(
    @inject('CustomersRepository')
    private customersRepository: ICustomersRepository,

    @inject('MailProvider')
    private mailProvider: IMailProvider,
  ) {}

  public async execute(customerData: IRequest): Promise<Customer> {
    const customer = await this.customersRepository.create(customerData);

    const simulateCreateTemplate = path.resolve(
      __dirname,
      '..',
      'views',
      'simulate_create.hbs',
    );

    this.mailProvider.sendMail({
      to: {
        name: 'COIN',
        email: 'contato@coin.com.br',
      },
      subject: '[COIN] Simulação iniciada',
      templateData: {
        file: simulateCreateTemplate,
        variables: {},
      },
    });

    return customer;
  }
}

export default CreateCustomerService;
