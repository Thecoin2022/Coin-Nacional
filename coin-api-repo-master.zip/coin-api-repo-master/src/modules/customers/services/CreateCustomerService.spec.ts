import FakeMailProdiver from '@shared/container/providers/MailProvider/fakes/FakeMailProvider';

import FakeCustomersRepository from '../repositories/fakes/FakeCustomersRepository';
import CreateCustomerService from './CreateCustomerService';

let fakeCustomersRepository: FakeCustomersRepository;
let fakeMailProdiver: FakeMailProdiver;

let createCustomer: CreateCustomerService;

describe('CreateCustomer', () => {
  beforeEach(() => {
    fakeCustomersRepository = new FakeCustomersRepository();
    fakeMailProdiver = new FakeMailProdiver();

    createCustomer = new CreateCustomerService(
      fakeCustomersRepository,
      fakeMailProdiver,
    );
  });

  it('should be able to create a new customer', async () => {
    const customer = await createCustomer.execute({
      amount: 10,
      cep: '75000000',
      months: 48,
      status_id: 'non-valid-status-id',
      type_id: 'non-valid-type-id',
    });

    expect(customer).toHaveProperty('id');
    expect(customer.amount).toBe(10);
    expect(customer.cep).toBe('75000000');
    expect(customer.months).toBe(48);
    expect(customer.status_id).toBe('non-valid-status-id');
    expect(customer.type_id).toBe('non-valid-type-id');
  });
});
