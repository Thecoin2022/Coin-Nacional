import AppError from '@shared/errors/AppError';
import FakeMailProdiver from '@shared/container/providers/MailProvider/fakes/FakeMailProvider';
import FakeTypesRepository from '@modules/types/repositories/fakes/FakeTypesRepository';

import FakeCustomersRepository from '../repositories/fakes/FakeCustomersRepository';
import UpdateCustomerService from './UpdateCustomerService';

let fakeCustomersRepository: FakeCustomersRepository;
let fakeMailProdiver: FakeMailProdiver;
let fakeTypesRepository: FakeTypesRepository;

let updateCustomer: UpdateCustomerService;

describe('UpdateCustomer', () => {
  beforeEach(() => {
    fakeCustomersRepository = new FakeCustomersRepository();
    fakeTypesRepository = new FakeTypesRepository();
    fakeMailProdiver = new FakeMailProdiver();

    updateCustomer = new UpdateCustomerService(
      fakeCustomersRepository,
      fakeTypesRepository,
      fakeMailProdiver,
    );
  });

  it('should be able to update a customer', async () => {
    const customer = await fakeCustomersRepository.create({
      amount: 10,
      cep: '75000000',
      months: 48,
      status_id: 'non-valid-status-id',
      type_id: 'non-valid-type-id',
    });

    const date = new Date();

    await updateCustomer.execute({
      customer_id: customer.id,
      name: 'John Doe',
      email: 'johndoe@gmail.com',
      phone: '23988888888',
      birth: date,
    });

    expect(customer).toHaveProperty('id');
    expect(customer.name).toBe('John Doe');
    expect(customer.email).toBe('johndoe@gmail.com');
    expect(customer.phone).toBe('23988888888');
    expect(customer.birth).toBe(date);
  });

  it('should not be able to update a non existing customer', async () => {
    expect(
      updateCustomer.execute({
        customer_id: 'non-existing-customer-id',
        name: 'John Doe',
        email: 'johndoe@gmail.com',
        phone: '23988888888',
        birth: new Date(),
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
