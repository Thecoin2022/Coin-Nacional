import AppError from '@shared/errors/AppError';
import FakeCustomersRepository from '../repositories/fakes/FakeCustomersRepository';
import DeleteCustomerService from './DeleteCustomerService';

let fakeCustomersRepository: FakeCustomersRepository;

let deleteCustomer: DeleteCustomerService;

describe('DeleteCustomer', () => {
  beforeEach(() => {
    fakeCustomersRepository = new FakeCustomersRepository();

    deleteCustomer = new DeleteCustomerService(fakeCustomersRepository);
  });

  it('should be able to delete a customer', async () => {
    const customer = await fakeCustomersRepository.create({
      amount: 10,
      cep: '75000000',
      months: 48,
      status_id: 'non-valid-status-id',
      type_id: 'non-valid-type-id',
    });

    await deleteCustomer.execute({
      customer_id: customer.id,
    });

    const findCustomer = await fakeCustomersRepository.findById(customer.id);

    expect(findCustomer).toBeUndefined();
  });

  it('should not be able to delete a non existing customer', async () => {
    expect(
      deleteCustomer.execute({
        customer_id: 'non-existing-customer-id',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
