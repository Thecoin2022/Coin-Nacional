import FakeCustomersRepository from '../repositories/fakes/FakeCustomersRepository';
import ListCustomerService from './ListCustomerService';

let fakeCustomersRepository: FakeCustomersRepository;

let listCustomer: ListCustomerService;

describe('ListCustomer', () => {
  beforeEach(() => {
    fakeCustomersRepository = new FakeCustomersRepository();

    listCustomer = new ListCustomerService(fakeCustomersRepository);
  });

  it('should be able to list customers', async () => {
    const customer = await fakeCustomersRepository.create({
      amount: 10,
      cep: '75000000',
      months: 48,
      status_id: 'non-valid-status-id',
      type_id: 'non-valid-type-id',
    });

    const customers = await listCustomer.execute();

    expect(customers).toStrictEqual([customer]);
  });
});
