import Customer from '../infra/typeorm/entities/Customer';
import ICreateCustomerDTO from '../dtos/ICreateCustomerDTO';

export default interface IUsersRepository {
  findById(id: string): Promise<Customer | undefined>;
  findByUserId(userId: string): Promise<Customer[]>;
  create(data: ICreateCustomerDTO): Promise<Customer>;
  delete(user: Customer): Promise<void>;
  list(): Promise<Customer[]>;
  save(user: Customer): Promise<Customer>;
}
