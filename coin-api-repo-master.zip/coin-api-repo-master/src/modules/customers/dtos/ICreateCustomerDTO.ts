export default interface ICreateCustomerDTO {
  user_id?: string;
  amount: number;
  months: number;
  cep: string;
  status_id: string;
  type_id: string;
  step?: number;
  name?: string;
  mother_name?: string;
  document_type?: string;
  document?: string;
  email?: string;
  phone?: string;
  birth?: Date;
  income?: number;
  has_property?: boolean;
  vehicle_owner?: boolean;
  vehicle_year?: number;
  vehicle_financed?: boolean;
  property_id?: string;
}
