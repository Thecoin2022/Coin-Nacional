export default interface ICreatePropertyDTO {
  name: string;
}
