import { getRepository, Repository } from 'typeorm';

import IPropertiesRepository from '@modules/properties/repositories/IPropertiesRepository';
import ICreatePropertyDTO from '@modules/properties/dtos/ICreatePropertyDTO';

import Property from '../entities/Property';

class PropertiesRepository implements IPropertiesRepository {
  private ormRepository: Repository<Property>;

  constructor() {
    this.ormRepository = getRepository(Property);
  }

  public async findById(id: string): Promise<Property | undefined> {
    const property = await this.ormRepository.findOne(id);

    return property;
  }

  public async create(propertyData: ICreatePropertyDTO): Promise<Property> {
    const property = this.ormRepository.create(propertyData);

    await this.ormRepository.save(property);

    return property;
  }

  public async list(): Promise<Property[]> {
    const propertys = await this.ormRepository.find();

    return propertys;
  }

  public async delete(property: Property): Promise<void> {
    await this.ormRepository.delete({ id: property.id });
  }

  public async save(property: Property): Promise<Property> {
    return this.ormRepository.save(property);
  }
}

export default PropertiesRepository;
