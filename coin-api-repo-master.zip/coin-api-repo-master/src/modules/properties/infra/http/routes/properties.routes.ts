import { Router } from 'express';

import { celebrate, Segments, Joi } from 'celebrate';

import ensureAuthenticated from '@modules/users/infra/http/middlewares/ensureAuthenticated';

import PropertiesController from '../controllers/PropertiesController';

const propertiesRouter = Router({ mergeParams: true });
const propertiesController = new PropertiesController();

propertiesRouter.get('/', propertiesController.index);

propertiesRouter.use(ensureAuthenticated);

propertiesRouter.get(
  '/:id',
  celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().uuid().required(),
    },
  }),
  propertiesController.show,
);

propertiesRouter.post(
  '/',
  celebrate({
    [Segments.BODY]: {
      name: Joi.string().required(),
    },
  }),
  propertiesController.create,
);

propertiesRouter.patch(
  '/:id',
  celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().uuid().required(),
    },
    [Segments.BODY]: {
      name: Joi.string().required(),
    },
  }),
  propertiesController.update,
);

propertiesRouter.delete(
  '/:id',
  celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().uuid().required(),
    },
  }),
  propertiesController.delete,
);

export default propertiesRouter;
