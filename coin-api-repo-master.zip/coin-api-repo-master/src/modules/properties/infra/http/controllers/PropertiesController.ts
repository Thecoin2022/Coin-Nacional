import { Request, Response } from 'express';

import { container } from 'tsyringe';

import CreatePropertyService from '@modules/properties/services/CreatePropertyService';
import UpdatePropertyService from '@modules/properties/services/UpdatePropertyService';
import DeletePropertyService from '@modules/properties/services/DeletePropertyService';
import ListPropertyService from '@modules/properties/services/ListPropertyService';
import ShowPropertyService from '@modules/properties/services/ShowPropertyService';

export default class PropertiesController {
  public async index(req: Request, res: Response): Promise<Response> {
    const listProperty = container.resolve(ListPropertyService);

    const properties = await listProperty.execute();

    return res.json(properties);
  }

  public async show(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const showProperty = container.resolve(ShowPropertyService);

    const property = await showProperty.execute({ property_id: id });

    return res.json(property);
  }

  public async create(req: Request, res: Response): Promise<Response> {
    const createProperty = container.resolve(CreatePropertyService);

    const property = await createProperty.execute(req.body);

    return res.json(property);
  }

  public async update(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const updateProperty = container.resolve(UpdatePropertyService);

    const property = await updateProperty.execute({
      property_id: id,
      ...req.body,
    });

    return res.json(property);
  }

  public async delete(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const deleteProperty = container.resolve(DeletePropertyService);

    await deleteProperty.execute({
      property_id: id,
    });

    return res.json();
  }
}
