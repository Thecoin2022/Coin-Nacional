import Property from '../infra/typeorm/entities/Property';
import ICreatePropertyDTO from '../dtos/ICreatePropertyDTO';

export default interface IPropertiesRepository {
  findById(id: string): Promise<Property | undefined>;
  create(data: ICreatePropertyDTO): Promise<Property>;
  delete(property: Property): Promise<void>;
  list(): Promise<Property[]>;
  save(property: Property): Promise<Property>;
}
