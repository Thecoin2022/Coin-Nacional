import { uuid } from 'uuidv4';

import IPropertiesRepository from '@modules/properties/repositories/IPropertiesRepository';
import ICreatePropertyDTO from '@modules/properties/dtos/ICreatePropertyDTO';

import Property from '../../infra/typeorm/entities/Property';

class PropertiesRepository implements IPropertiesRepository {
  private properties: Property[] = [];

  public async findById(id: string): Promise<Property | undefined> {
    const findProperty = this.properties.find(property => property.id === id);

    return findProperty;
  }

  public async create(propertyData: ICreatePropertyDTO): Promise<Property> {
    const property = new Property();

    Object.assign(property, { id: uuid() }, propertyData);

    this.properties.push(property);

    return property;
  }

  public async delete(property: Property): Promise<void> {
    this.properties = this.properties.filter(
      findProperty => findProperty.id !== property.id,
    );
  }

  public async list(): Promise<Property[]> {
    return this.properties;
  }

  public async save(property: Property): Promise<Property> {
    const findIndex = this.properties.findIndex(
      findProperty => findProperty.id === property.id,
    );

    this.properties[findIndex] = property;

    return property;
  }
}

export default PropertiesRepository;
