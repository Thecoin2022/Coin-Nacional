import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';
import IPropertiesRepository from '../repositories/IPropertiesRepository';

interface IRequest {
  property_id: string;
}

@injectable()
class DeletePropertyService {
  constructor(
    @inject('PropertiesRepository')
    private propertiesRepository: IPropertiesRepository,
  ) {}

  public async execute({ property_id }: IRequest): Promise<void> {
    const property = await this.propertiesRepository.findById(property_id);

    if (!property) {
      throw new AppError('Property not found', 404);
    }

    await this.propertiesRepository.delete(property);
  }
}

export default DeletePropertyService;
