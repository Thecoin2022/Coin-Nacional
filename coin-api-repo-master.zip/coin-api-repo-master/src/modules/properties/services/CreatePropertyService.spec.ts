import FakePropertiesRepository from '../repositories/fakes/FakePropertiesRepository';
import CreatePropertyService from './CreatePropertyService';

let fakePropertiesRepository: FakePropertiesRepository;

let createProperty: CreatePropertyService;

describe('CreateProperty', () => {
  beforeEach(() => {
    fakePropertiesRepository = new FakePropertiesRepository();

    createProperty = new CreatePropertyService(fakePropertiesRepository);
  });

  it('should be able to create a new property', async () => {
    const property = await createProperty.execute({
      name: 'Apartamento',
    });

    expect(property).toHaveProperty('id');
    expect(property.name).toBe('Apartamento');
  });
});
