import { injectable, inject } from 'tsyringe';

import Property from '../infra/typeorm/entities/Property';
import IPropertiesRepository from '../repositories/IPropertiesRepository';

@injectable()
class ListPropertyService {
  constructor(
    @inject('PropertiesRepository')
    private propertiesRepository: IPropertiesRepository,
  ) {}

  public async execute(): Promise<Property[]> {
    const properties = await this.propertiesRepository.list();

    return properties;
  }
}

export default ListPropertyService;
