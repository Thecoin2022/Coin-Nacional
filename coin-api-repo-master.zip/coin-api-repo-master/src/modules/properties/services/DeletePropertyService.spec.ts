import AppError from '@shared/errors/AppError';
import FakePropertiesRepository from '../repositories/fakes/FakePropertiesRepository';
import DeletePropertyService from './DeletePropertyService';

let fakePropertiesRepository: FakePropertiesRepository;

let deleteProperty: DeletePropertyService;

describe('DeleteProperty', () => {
  beforeEach(() => {
    fakePropertiesRepository = new FakePropertiesRepository();

    deleteProperty = new DeletePropertyService(fakePropertiesRepository);
  });

  it('should be able to delete a property', async () => {
    const property = await fakePropertiesRepository.create({
      name: 'available',
    });

    await deleteProperty.execute({
      property_id: property.id,
    });

    const findProperty = await fakePropertiesRepository.findById(property.id);

    expect(findProperty).toBeUndefined();
  });

  it('should not be able to delete a non existing property', async () => {
    expect(
      deleteProperty.execute({
        property_id: 'non-existing-property-id',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
