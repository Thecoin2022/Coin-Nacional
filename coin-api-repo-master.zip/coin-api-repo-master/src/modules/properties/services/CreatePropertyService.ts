import { injectable, inject } from 'tsyringe';

import Property from '../infra/typeorm/entities/Property';
import IPropertiesRepository from '../repositories/IPropertiesRepository';

interface IRequest {
  name: string;
}

@injectable()
class CreatePropertyService {
  constructor(
    @inject('PropertiesRepository')
    private propertiesRepository: IPropertiesRepository,
  ) {}

  public async execute(propertyData: IRequest): Promise<Property> {
    const property = await this.propertiesRepository.create(propertyData);

    return property;
  }
}

export default CreatePropertyService;
