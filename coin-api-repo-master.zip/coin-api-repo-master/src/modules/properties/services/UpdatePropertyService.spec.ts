import AppError from '@shared/errors/AppError';
import FakePropertiesRepository from '../repositories/fakes/FakePropertiesRepository';
import UpdatePropertyService from './UpdatePropertyService';

let fakePropertiesRepository: FakePropertiesRepository;

let updateProperty: UpdatePropertyService;

describe('UpdateProperty', () => {
  beforeEach(() => {
    fakePropertiesRepository = new FakePropertiesRepository();

    updateProperty = new UpdatePropertyService(fakePropertiesRepository);
  });

  it('should be able to update a property', async () => {
    const property = await fakePropertiesRepository.create({
      name: 'available',
    });

    await updateProperty.execute({
      property_id: property.id,
      name: 'other-name',
    });

    expect(property).toHaveProperty('id');
    expect(property.name).toBe('other-name');
  });

  it('should not be able to update a non existing property', async () => {
    expect(
      updateProperty.execute({
        property_id: 'non-existing-property-id',
        name: 'other-name',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
