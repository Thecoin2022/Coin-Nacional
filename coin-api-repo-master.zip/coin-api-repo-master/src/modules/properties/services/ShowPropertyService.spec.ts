import AppError from '@shared/errors/AppError';
import FakePropertiesRepository from '../repositories/fakes/FakePropertiesRepository';
import ShowPropertyService from './ShowPropertyService';

let fakePropertiesRepository: FakePropertiesRepository;

let showProperty: ShowPropertyService;

describe('ShowProperty', () => {
  beforeEach(() => {
    fakePropertiesRepository = new FakePropertiesRepository();

    showProperty = new ShowPropertyService(fakePropertiesRepository);
  });

  it('should be able to show a property', async () => {
    const property = await fakePropertiesRepository.create({
      name: 'available',
    });

    const findProperty = await showProperty.execute({
      property_id: property.id,
    });

    expect(findProperty).toBe(property);
  });

  it('should not be able to show a non existing property', async () => {
    expect(
      showProperty.execute({
        property_id: 'non-existing-property-id',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
