import FakePropertiesRepository from '../repositories/fakes/FakePropertiesRepository';
import ListPropertyService from './ListPropertyService';

let fakePropertiesRepository: FakePropertiesRepository;

let listProperty: ListPropertyService;

describe('ListProperty', () => {
  beforeEach(() => {
    fakePropertiesRepository = new FakePropertiesRepository();

    listProperty = new ListPropertyService(fakePropertiesRepository);
  });

  it('should be able to list properties', async () => {
    const property = await fakePropertiesRepository.create({
      name: 'Apartamento',
    });

    const properties = await listProperty.execute();

    expect(properties).toStrictEqual([property]);
  });
});
