import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';
import IPostsRepository from '../repositories/IPostsRepository';

interface IRequest {
  post_id: string;
}

@injectable()
class DeletePostService {
  constructor(
    @inject('PostsRepository')
    private postsRepository: IPostsRepository,
  ) {}

  public async execute({ post_id }: IRequest): Promise<void> {
    const post = await this.postsRepository.findById(post_id);

    if (!post) {
      throw new AppError('Post not found', 404);
    }

    await this.postsRepository.delete(post);
  }
}

export default DeletePostService;
