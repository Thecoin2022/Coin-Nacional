import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';

import Post from '../infra/typeorm/entities/Post';
import IPostsRepository from '../repositories/IPostsRepository';

interface IRequest {
  post_id: string;
}

@injectable()
class ShowPostService {
  constructor(
    @inject('PostsRepository')
    private postsRepository: IPostsRepository,
  ) {}

  public async execute({ post_id }: IRequest): Promise<Post> {
    const post = await this.postsRepository.findById(post_id);

    if (!post) {
      throw new AppError('Post not found', 404);
    }

    return post;
  }
}

export default ShowPostService;
