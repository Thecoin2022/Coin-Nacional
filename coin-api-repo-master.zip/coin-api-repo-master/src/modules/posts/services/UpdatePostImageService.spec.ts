import AppError from '@shared/errors/AppError';
import FakeStorageProvider from '@shared/container/providers/StorageProvider/fakes/FakeStorageProvider';
import FakePostsRepository from '../repositories/fakes/FakePostsRepository';
import UpdatePostImageService from './UpdatePostImageService';

let fakePostsRepository: FakePostsRepository;
let fakeStorageProvider: FakeStorageProvider;

let updatePostImage: UpdatePostImageService;

describe('UpdatePostImage', () => {
  beforeEach(() => {
    fakePostsRepository = new FakePostsRepository();
    fakeStorageProvider = new FakeStorageProvider();

    updatePostImage = new UpdatePostImageService(
      fakePostsRepository,
      fakeStorageProvider,
    );
  });

  it('should be able to update image', async () => {
    const post = await fakePostsRepository.create({
      title: 'title',
      content: 'content',
    });

    await updatePostImage.execute({
      post_id: post.id,
      imageFilename: 'image.jpg',
    });

    expect(post.image).toBe('image.jpg');
  });

  it('should not be able to update image from non existing post', async () => {
    expect(
      updatePostImage.execute({
        post_id: 'non-existing-post',
        imageFilename: 'image.jpg',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });

  it('should delete old image when updating new one', async () => {
    const deleteFile = jest.spyOn(fakeStorageProvider, 'deleteFile');

    const post = await fakePostsRepository.create({
      title: 'title',
      content: 'content',
    });

    await updatePostImage.execute({
      post_id: post.id,
      imageFilename: 'image.jpg',
    });

    await updatePostImage.execute({
      post_id: post.id,
      imageFilename: 'image2.jpg',
    });

    expect(deleteFile).toHaveBeenCalledWith('image.jpg');
    expect(post.image).toBe('image2.jpg');
  });
});
