import { injectable, inject } from 'tsyringe';

import Post from '../infra/typeorm/entities/Post';
import IPostsRepository from '../repositories/IPostsRepository';

interface IRequest {
  title: string;
  image?: string;
  content: string;
}

@injectable()
class CreatePostService {
  constructor(
    @inject('PostsRepository')
    private postsRepository: IPostsRepository,
  ) {}

  public async execute(postData: IRequest): Promise<Post> {
    const post = await this.postsRepository.create(postData);

    return post;
  }
}

export default CreatePostService;
