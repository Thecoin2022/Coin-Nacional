import AppError from '@shared/errors/AppError';
import FakePostsRepository from '../repositories/fakes/FakePostsRepository';
import ShowPostService from './ShowPostService';

let fakePostsRepository: FakePostsRepository;

let showPost: ShowPostService;

describe('ShowPost', () => {
  beforeEach(() => {
    fakePostsRepository = new FakePostsRepository();

    showPost = new ShowPostService(fakePostsRepository);
  });

  it('should be able to show a post', async () => {
    const post = await fakePostsRepository.create({
      title: 'title',
      content: 'content',
    });

    const findPost = await showPost.execute({
      post_id: post.id,
    });

    expect(findPost).toBe(post);
  });

  it('should not be able to show a non existing post', async () => {
    expect(
      showPost.execute({
        post_id: 'non-existing-post-id',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
