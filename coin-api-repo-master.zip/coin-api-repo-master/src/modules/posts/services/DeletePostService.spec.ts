import AppError from '@shared/errors/AppError';
import FakePostsRepository from '../repositories/fakes/FakePostsRepository';
import DeletePostService from './DeletePostService';

let fakePostsRepository: FakePostsRepository;

let deletePost: DeletePostService;

describe('DeletePost', () => {
  beforeEach(() => {
    fakePostsRepository = new FakePostsRepository();

    deletePost = new DeletePostService(fakePostsRepository);
  });

  it('should be able to delete a post', async () => {
    const post = await fakePostsRepository.create({
      title: 'title',
      content: 'content',
    });

    await deletePost.execute({
      post_id: post.id,
    });

    const findPost = await fakePostsRepository.findById(post.id);

    expect(findPost).toBeUndefined();
  });

  it('should not be able to delete a non existing post', async () => {
    expect(
      deletePost.execute({
        post_id: 'non-existing-post-id',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
