import FakePostsRepository from '../repositories/fakes/FakePostsRepository';
import CreatePostService from './CreatePostService';

let fakePostsRepository: FakePostsRepository;

let createPost: CreatePostService;

describe('CreatePost', () => {
  beforeEach(() => {
    fakePostsRepository = new FakePostsRepository();

    createPost = new CreatePostService(fakePostsRepository);
  });

  it('should be able to create a new post', async () => {
    const post = await createPost.execute({
      title: 'title',
      content: 'content',
    });

    expect(post).toHaveProperty('id');
    expect(post.title).toBe('title');
    expect(post.content).toBe('content');
  });
});
