import AppError from '@shared/errors/AppError';
import FakePostsRepository from '../repositories/fakes/FakePostsRepository';
import UpdatePostService from './UpdatePostService';

let fakePostsRepository: FakePostsRepository;

let updatePost: UpdatePostService;

describe('UpdatePost', () => {
  beforeEach(() => {
    fakePostsRepository = new FakePostsRepository();

    updatePost = new UpdatePostService(fakePostsRepository);
  });

  it('should be able to update a post', async () => {
    const post = await fakePostsRepository.create({
      title: 'title',
      content: 'content',
    });

    await updatePost.execute({
      post_id: post.id,
      title: 'diff-title',
      content: 'diff-content',
    });

    expect(post).toHaveProperty('id');
    expect(post.title).toBe('diff-title');
    expect(post.content).toBe('diff-content');
  });

  it('should not be able to update a non existing post', async () => {
    expect(
      updatePost.execute({
        post_id: 'non-existing-post-id',
        title: 'diff-title',
        content: 'diff-content',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
