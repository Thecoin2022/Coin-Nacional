import FakePostsRepository from '../repositories/fakes/FakePostsRepository';
import ListPostService from './ListPostService';

let fakePostsRepository: FakePostsRepository;

let listPost: ListPostService;

describe('ListPost', () => {
  beforeEach(() => {
    fakePostsRepository = new FakePostsRepository();

    listPost = new ListPostService(fakePostsRepository);
  });

  it('should be able to list posts', async () => {
    const post = await fakePostsRepository.create({
      title: 'title',
      content: 'content',
    });

    const posts = await listPost.execute();

    expect(posts).toStrictEqual([post]);
  });
});
