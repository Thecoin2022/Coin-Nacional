import Post from '../infra/typeorm/entities/Post';
import ICreatePostDTO from '../dtos/ICreatePostDTO';

export default interface IPostsRepository {
  findById(id: string): Promise<Post | undefined>;
  create(data: ICreatePostDTO): Promise<Post>;
  delete(post: Post): Promise<void>;
  list(): Promise<Post[]>;
  save(post: Post): Promise<Post>;
}
