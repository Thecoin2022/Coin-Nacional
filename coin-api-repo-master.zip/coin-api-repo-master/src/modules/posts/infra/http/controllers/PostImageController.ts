import { Request, Response } from 'express';

import { container } from 'tsyringe';

import UpdatePostImageService from '@modules/posts/services/UpdatePostImageService';

export default class PostImageController {
  public async update(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const updatePostImage = container.resolve(UpdatePostImageService);

    const post = await updatePostImage.execute({
      post_id: id,
      imageFilename: req.file.filename,
    });

    return res.json(post);
  }
}
