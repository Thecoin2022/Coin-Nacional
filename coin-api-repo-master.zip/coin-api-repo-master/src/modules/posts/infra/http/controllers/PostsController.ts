import { Request, Response } from 'express';

import { container } from 'tsyringe';

import CreatePostService from '@modules/posts/services/CreatePostService';
import UpdatePostService from '@modules/posts/services/UpdatePostService';
import DeletePostService from '@modules/posts/services/DeletePostService';
import ListPostService from '@modules/posts/services/ListPostService';
import ShowPostService from '@modules/posts/services/ShowPostService';

export default class PostsController {
  public async index(req: Request, res: Response): Promise<Response> {
    const listPost = container.resolve(ListPostService);

    const posts = await listPost.execute();

    return res.json(posts);
  }

  public async show(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const showPost = container.resolve(ShowPostService);

    const post = await showPost.execute({ post_id: id });

    return res.json(post);
  }

  public async create(req: Request, res: Response): Promise<Response> {
    const createPost = container.resolve(CreatePostService);

    const post = await createPost.execute(req.body);

    return res.json(post);
  }

  public async update(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const updatePost = container.resolve(UpdatePostService);

    const post = await updatePost.execute({
      post_id: id,
      ...req.body,
    });

    return res.json(post);
  }

  public async delete(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const deletePost = container.resolve(DeletePostService);

    await deletePost.execute({
      post_id: id,
    });

    return res.json();
  }
}
