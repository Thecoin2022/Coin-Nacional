export default interface ICreatePostDTO {
  title: string;
  image?: string;
  content: string;
}
