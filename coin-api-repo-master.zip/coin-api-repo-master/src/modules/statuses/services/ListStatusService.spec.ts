import FakeStatusesRepository from '../repositories/fakes/FakeStatusesRepository';
import ListStatusService from './ListStatusService';

let fakeStatusesRepository: FakeStatusesRepository;

let listStatus: ListStatusService;

describe('ListStatus', () => {
  beforeEach(() => {
    fakeStatusesRepository = new FakeStatusesRepository();

    listStatus = new ListStatusService(fakeStatusesRepository);
  });

  it('should be able to list statuses', async () => {
    const status = await fakeStatusesRepository.create({
      name: 'available',
    });

    const statuses = await listStatus.execute();

    expect(statuses).toStrictEqual([status]);
  });
});
