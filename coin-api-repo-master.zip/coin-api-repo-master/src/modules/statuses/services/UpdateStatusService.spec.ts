import AppError from '@shared/errors/AppError';
import FakeStatusesRepository from '../repositories/fakes/FakeStatusesRepository';
import UpdateStatusService from './UpdateStatusService';

let fakeStatusesRepository: FakeStatusesRepository;

let updateStatus: UpdateStatusService;

describe('UpdateStatus', () => {
  beforeEach(() => {
    fakeStatusesRepository = new FakeStatusesRepository();

    updateStatus = new UpdateStatusService(fakeStatusesRepository);
  });

  it('should be able to update a status', async () => {
    const status = await fakeStatusesRepository.create({
      color: '#ddd',
      text_color: '#000',
      name: 'available',
    });

    await updateStatus.execute({
      status_id: status.id,
      name: 'other-name',
      color: '#eee',
      text_color: '#aaa',
    });

    expect(status).toHaveProperty('id');
    expect(status.name).toBe('other-name');
  });

  it('should not be able to update a non existing status', async () => {
    expect(
      updateStatus.execute({
        status_id: 'non-existing-status-id',
        name: 'other-name',
        color: '#eee',
        text_color: '#aaa',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
