import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';

import Status from '../infra/typeorm/entities/Status';
import IStatusesRepository from '../repositories/IStatusesRepository';

interface IRequest {
  status_id: string;
}

@injectable()
class ShowStatusService {
  constructor(
    @inject('StatusesRepository')
    private statusesRepository: IStatusesRepository,
  ) {}

  public async execute({ status_id }: IRequest): Promise<Status> {
    const status = await this.statusesRepository.findById(status_id);

    if (!status) {
      throw new AppError('Status not found', 404);
    }

    return status;
  }
}

export default ShowStatusService;
