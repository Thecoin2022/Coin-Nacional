import { injectable, inject } from 'tsyringe';

import Status from '../infra/typeorm/entities/Status';
import IStatusesRepository from '../repositories/IStatusesRepository';

@injectable()
class ListStatusService {
  constructor(
    @inject('StatusesRepository')
    private statusesRepository: IStatusesRepository,
  ) {}

  public async execute(): Promise<Status[]> {
    const statuses = await this.statusesRepository.list();

    return statuses;
  }
}

export default ListStatusService;
