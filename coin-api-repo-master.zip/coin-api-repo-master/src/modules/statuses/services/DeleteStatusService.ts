import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';
import IStatusesRepository from '../repositories/IStatusesRepository';

interface IRequest {
  status_id: string;
}

@injectable()
class UpdateStatusService {
  constructor(
    @inject('StatusesRepository')
    private statusesRepository: IStatusesRepository,
  ) {}

  public async execute({ status_id }: IRequest): Promise<void> {
    const status = await this.statusesRepository.findById(status_id);

    if (!status) {
      throw new AppError('Status not found', 404);
    }

    await this.statusesRepository.delete(status);
  }
}

export default UpdateStatusService;
