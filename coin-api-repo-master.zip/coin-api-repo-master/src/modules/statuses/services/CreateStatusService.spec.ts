import FakeStatusesRepository from '../repositories/fakes/FakeStatusesRepository';
import CreateStatusService from './CreateStatusService';

let fakeStatusesRepository: FakeStatusesRepository;

let createStatus: CreateStatusService;

describe('CreateStatus', () => {
  beforeEach(() => {
    fakeStatusesRepository = new FakeStatusesRepository();

    createStatus = new CreateStatusService(fakeStatusesRepository);
  });

  it('should be able to create a new status', async () => {
    const status = await createStatus.execute({
      color: '#ddd',
      text_color: '#000',
      name: 'available',
    });

    expect(status).toHaveProperty('id');
    expect(status.name).toBe('available');
  });
});
