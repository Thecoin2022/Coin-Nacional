import AppError from '@shared/errors/AppError';
import FakeStatusesRepository from '../repositories/fakes/FakeStatusesRepository';
import ShowStatusService from './ShowStatusService';

let fakeStatusesRepository: FakeStatusesRepository;

let showStatus: ShowStatusService;

describe('ShowStatus', () => {
  beforeEach(() => {
    fakeStatusesRepository = new FakeStatusesRepository();

    showStatus = new ShowStatusService(fakeStatusesRepository);
  });

  it('should be able to show a status', async () => {
    const status = await fakeStatusesRepository.create({
      name: 'available',
    });

    const findStatus = await showStatus.execute({
      status_id: status.id,
    });

    expect(findStatus).toBe(status);
  });

  it('should not be able to show a non existing status', async () => {
    expect(
      showStatus.execute({
        status_id: 'non-existing-status-id',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
