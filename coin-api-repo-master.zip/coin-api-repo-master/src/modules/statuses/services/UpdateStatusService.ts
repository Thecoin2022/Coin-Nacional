import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';
import Status from '../infra/typeorm/entities/Status';
import IStatusesRepository from '../repositories/IStatusesRepository';

interface IRequest {
  status_id: string;
  name: string;
  color: string;
  text_color: string;
}

@injectable()
class UpdateStatusService {
  constructor(
    @inject('StatusesRepository')
    private statusesRepository: IStatusesRepository,
  ) {}

  public async execute({
    status_id,
    ...restStatusData
  }: IRequest): Promise<Status> {
    const status = await this.statusesRepository.findById(status_id);

    if (!status) {
      throw new AppError('Status not found', 404);
    }

    Object.assign(status, restStatusData);

    await this.statusesRepository.save(status);

    return status;
  }
}

export default UpdateStatusService;
