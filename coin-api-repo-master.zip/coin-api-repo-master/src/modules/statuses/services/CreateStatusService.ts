import { injectable, inject } from 'tsyringe';

import Status from '../infra/typeorm/entities/Status';
import IStatusesRepository from '../repositories/IStatusesRepository';

interface IRequest {
  name: string;
  color: string;
  text_color: string;
}

@injectable()
class CreateStatusService {
  constructor(
    @inject('StatusesRepository')
    private statusesRepository: IStatusesRepository,
  ) {}

  public async execute(statusData: IRequest): Promise<Status> {
    const status = await this.statusesRepository.create(statusData);

    return status;
  }
}

export default CreateStatusService;
