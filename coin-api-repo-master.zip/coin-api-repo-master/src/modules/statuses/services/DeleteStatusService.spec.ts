import AppError from '@shared/errors/AppError';
import FakeStatusesRepository from '../repositories/fakes/FakeStatusesRepository';
import DeleteStatusService from './DeleteStatusService';

let fakeStatusesRepository: FakeStatusesRepository;

let deleteStatus: DeleteStatusService;

describe('DeleteStatus', () => {
  beforeEach(() => {
    fakeStatusesRepository = new FakeStatusesRepository();

    deleteStatus = new DeleteStatusService(fakeStatusesRepository);
  });

  it('should be able to delete a status', async () => {
    const status = await fakeStatusesRepository.create({
      name: 'available',
    });

    await deleteStatus.execute({
      status_id: status.id,
    });

    const findStatus = await fakeStatusesRepository.findById(status.id);

    expect(findStatus).toBeUndefined();
  });

  it('should not be able to delete a non existing status', async () => {
    expect(
      deleteStatus.execute({
        status_id: 'non-existing-status-id',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
