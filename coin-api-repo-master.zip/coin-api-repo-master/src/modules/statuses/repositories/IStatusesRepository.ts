import Status from '../infra/typeorm/entities/Status';
import ICreateStatusDTO from '../dtos/ICreateStatusDTO';

export default interface IStatusesRepository {
  findById(id: string): Promise<Status | undefined>;
  create(data: ICreateStatusDTO): Promise<Status>;
  delete(status: Status): Promise<void>;
  list(): Promise<Status[]>;
  save(status: Status): Promise<Status>;
}
