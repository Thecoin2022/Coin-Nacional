import { uuid } from 'uuidv4';

import IStatusesRepository from '@modules/statuses/repositories/IStatusesRepository';
import ICreateStatusDTO from '@modules/statuses/dtos/ICreateStatusDTO';

import Status from '../../infra/typeorm/entities/Status';

class StatusesRepository implements IStatusesRepository {
  private statuses: Status[] = [];

  public async findById(id: string): Promise<Status | undefined> {
    const findStatus = this.statuses.find(status => status.id === id);

    return findStatus;
  }

  public async create(statusData: ICreateStatusDTO): Promise<Status> {
    const status = new Status();

    Object.assign(status, { id: uuid() }, statusData);

    this.statuses.push(status);

    return status;
  }

  public async delete(status: Status): Promise<void> {
    this.statuses = this.statuses.filter(
      findStatus => findStatus.id !== status.id,
    );
  }

  public async list(): Promise<Status[]> {
    return this.statuses;
  }

  public async save(status: Status): Promise<Status> {
    const findIndex = this.statuses.findIndex(
      findStatus => findStatus.id === status.id,
    );

    this.statuses[findIndex] = status;

    return status;
  }
}

export default StatusesRepository;
