export default interface ICreateStatusDTO {
  name: string;
  color: string;
  text_color: string;
}
