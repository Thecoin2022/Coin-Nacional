import { getRepository, Repository } from 'typeorm';

import IStatusesRepository from '@modules/statuses/repositories/IStatusesRepository';
import ICreateStatusDTO from '@modules/statuses/dtos/ICreateStatusDTO';

import Status from '../entities/Status';

class StatusRepository implements IStatusesRepository {
  private ormRepository: Repository<Status>;

  constructor() {
    this.ormRepository = getRepository(Status);
  }

  public async findById(id: string): Promise<Status | undefined> {
    const status = await this.ormRepository.findOne(id);

    return status;
  }

  public async create(statusData: ICreateStatusDTO): Promise<Status> {
    const status = this.ormRepository.create(statusData);

    await this.ormRepository.save(status);

    return status;
  }

  public async list(): Promise<Status[]> {
    const statuses = await this.ormRepository.find();

    return statuses;
  }

  public async delete(status: Status): Promise<void> {
    await this.ormRepository.delete({ id: status.id });
  }

  public async save(status: Status): Promise<Status> {
    return this.ormRepository.save(status);
  }
}

export default StatusRepository;
