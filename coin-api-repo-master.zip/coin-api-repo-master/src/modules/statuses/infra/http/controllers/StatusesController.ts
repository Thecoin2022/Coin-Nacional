import { Request, Response } from 'express';

import { container } from 'tsyringe';

import CreateStatusService from '@modules/statuses/services/CreateStatusService';
import UpdateStatusService from '@modules/statuses/services/UpdateStatusService';
import DeleteStatusService from '@modules/statuses/services/DeleteStatusService';
import ListStatusService from '@modules/statuses/services/ListStatusService';
import ShowStatusService from '@modules/statuses/services/ShowStatusService';

export default class StatusesController {
  public async index(req: Request, res: Response): Promise<Response> {
    const listStatus = container.resolve(ListStatusService);

    const statuses = await listStatus.execute();

    return res.json(statuses);
  }

  public async show(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const showStatus = container.resolve(ShowStatusService);

    const status = await showStatus.execute({ status_id: id });

    return res.json(status);
  }

  public async create(req: Request, res: Response): Promise<Response> {
    const createStatus = container.resolve(CreateStatusService);

    const status = await createStatus.execute(req.body);

    return res.json(status);
  }

  public async update(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const updateStatus = container.resolve(UpdateStatusService);

    const status = await updateStatus.execute({
      status_id: id,
      ...req.body,
    });

    return res.json(status);
  }

  public async delete(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const deleteStatus = container.resolve(DeleteStatusService);

    await deleteStatus.execute({
      status_id: id,
    });

    return res.json();
  }
}
