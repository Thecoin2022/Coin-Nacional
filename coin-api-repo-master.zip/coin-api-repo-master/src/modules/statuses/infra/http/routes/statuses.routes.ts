import { Router } from 'express';

import { celebrate, Segments, Joi } from 'celebrate';

import ensureAuthenticated from '@modules/users/infra/http/middlewares/ensureAuthenticated';

import StatusesController from '../controllers/StatusesController';

const statusesRouter = Router({ mergeParams: true });
const statusesController = new StatusesController();

statusesRouter.use(ensureAuthenticated);

statusesRouter.get('/', statusesController.index);

statusesRouter.get(
  '/:id',
  celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().uuid().required(),
    },
  }),
  statusesController.show,
);

statusesRouter.post(
  '/',
  celebrate({
    [Segments.BODY]: {
      name: Joi.string().required(),
      color: Joi.string().required(),
      text_color: Joi.string().required(),
    },
  }),
  statusesController.create,
);

statusesRouter.patch(
  '/:id',
  celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().uuid().required(),
    },
    [Segments.BODY]: {
      name: Joi.string().required(),
      color: Joi.string().required(),
      text_color: Joi.string().required(),
    },
  }),
  statusesController.update,
);

statusesRouter.delete(
  '/:id',
  celebrate({
    [Segments.PARAMS]: {
      id: Joi.string().uuid().required(),
    },
  }),
  statusesController.delete,
);

export default statusesRouter;
