import { getRepository, Repository } from 'typeorm';

import IBanksRepository from '@modules/banks/repositories/IBanksRepository';
import ICreateBankDTO from '@modules/banks/dtos/ICreateBankDTO';

import Bank from '../entities/Bank';

class BanksRepository implements IBanksRepository {
  private ormRepository: Repository<Bank>;

  constructor() {
    this.ormRepository = getRepository(Bank);
  }

  public async findById(id: string): Promise<Bank | undefined> {
    const bank = await this.ormRepository.findOne(id);

    return bank;
  }

  public async create(bankData: ICreateBankDTO): Promise<Bank> {
    const bank = this.ormRepository.create(bankData);

    await this.ormRepository.save(bank);

    return bank;
  }

  public async list(): Promise<Bank[]> {
    const banks = await this.ormRepository.find();

    return banks;
  }

  public async delete(bank: Bank): Promise<void> {
    await this.ormRepository.delete({ id: bank.id });
  }

  public async save(bank: Bank): Promise<Bank> {
    return this.ormRepository.save(bank);
  }
}

export default BanksRepository;
