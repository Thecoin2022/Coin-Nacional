import { Request, Response } from 'express';

import { container } from 'tsyringe';

import CreateBankService from '@modules/banks/services/CreateBankService';
import UpdateBankService from '@modules/banks/services/UpdateBankService';
import DeleteBankService from '@modules/banks/services/DeleteBankService';
import ListBankService from '@modules/banks/services/ListBankService';
import ShowBankService from '@modules/banks/services/ShowBankService';

export default class BanksController {
  public async index(req: Request, res: Response): Promise<Response> {
    const listBank = container.resolve(ListBankService);

    const banks = await listBank.execute();

    return res.json(banks);
  }

  public async show(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const showBank = container.resolve(ShowBankService);

    const bank = await showBank.execute({ bank_id: id });

    return res.json(bank);
  }

  public async create(req: Request, res: Response): Promise<Response> {
    const createBank = container.resolve(CreateBankService);

    const bank = await createBank.execute(req.body);

    return res.json(bank);
  }

  public async update(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const updateBank = container.resolve(UpdateBankService);

    const bank = await updateBank.execute({
      bank_id: id,
      ...req.body,
    });

    return res.json(bank);
  }

  public async delete(req: Request, res: Response): Promise<Response> {
    const { id } = req.params;

    const deleteBank = container.resolve(DeleteBankService);

    await deleteBank.execute({
      bank_id: id,
    });

    return res.json();
  }
}
