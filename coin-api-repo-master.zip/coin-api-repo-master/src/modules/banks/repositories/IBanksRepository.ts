import Bank from '../infra/typeorm/entities/Bank';
import ICreateBankDTO from '../dtos/ICreateBankDTO';

export default interface IBanksRepository {
  findById(id: string): Promise<Bank | undefined>;
  create(data: ICreateBankDTO): Promise<Bank>;
  delete(bank: Bank): Promise<void>;
  list(): Promise<Bank[]>;
  save(bank: Bank): Promise<Bank>;
}
