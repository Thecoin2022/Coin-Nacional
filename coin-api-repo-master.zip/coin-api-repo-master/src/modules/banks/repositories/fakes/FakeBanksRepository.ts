import { uuid } from 'uuidv4';

import IBanksRepository from '@modules/banks/repositories/IBanksRepository';
import ICreateBankDTO from '@modules/banks/dtos/ICreateBankDTO';

import Bank from '../../infra/typeorm/entities/Bank';

class BanksRepository implements IBanksRepository {
  private banks: Bank[] = [];

  public async findById(id: string): Promise<Bank | undefined> {
    const findBank = this.banks.find(bank => bank.id === id);

    return findBank;
  }

  public async create(bankData: ICreateBankDTO): Promise<Bank> {
    const bank = new Bank();

    Object.assign(bank, { id: uuid() }, bankData);

    this.banks.push(bank);

    return bank;
  }

  public async delete(bank: Bank): Promise<void> {
    this.banks = this.banks.filter(findBank => findBank.id !== bank.id);
  }

  public async list(): Promise<Bank[]> {
    return this.banks;
  }

  public async save(bank: Bank): Promise<Bank> {
    const findIndex = this.banks.findIndex(findBank => findBank.id === bank.id);

    this.banks[findIndex] = bank;

    return bank;
  }
}

export default BanksRepository;
