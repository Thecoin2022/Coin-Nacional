export default interface ICreateBankDTO {
  name: string;
}
