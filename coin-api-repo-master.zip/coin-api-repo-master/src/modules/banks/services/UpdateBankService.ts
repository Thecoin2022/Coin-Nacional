import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';
import Bank from '../infra/typeorm/entities/Bank';
import IBanksRepository from '../repositories/IBanksRepository';

interface IRequest {
  bank_id: string;
  name: string;
}

@injectable()
class UpdateBankService {
  constructor(
    @inject('BanksRepository')
    private banksRepository: IBanksRepository,
  ) {}

  public async execute({ bank_id, ...restBankData }: IRequest): Promise<Bank> {
    const bank = await this.banksRepository.findById(bank_id);

    if (!bank) {
      throw new AppError('Bank not found', 404);
    }

    Object.assign(bank, restBankData);

    await this.banksRepository.save(bank);

    return bank;
  }
}

export default UpdateBankService;
