import { injectable, inject } from 'tsyringe';

import AppError from '@shared/errors/AppError';
import IBanksRepository from '../repositories/IBanksRepository';

interface IRequest {
  bank_id: string;
}

@injectable()
class DeleteBankService {
  constructor(
    @inject('BanksRepository')
    private banksRepository: IBanksRepository,
  ) {}

  public async execute({ bank_id }: IRequest): Promise<void> {
    const bank = await this.banksRepository.findById(bank_id);

    if (!bank) {
      throw new AppError('Bank not found', 404);
    }

    await this.banksRepository.delete(bank);
  }
}

export default DeleteBankService;
