import AppError from '@shared/errors/AppError';
import FakeBanksRepository from '../repositories/fakes/FakeBanksRepository';
import ShowBankService from './ShowBankService';

let fakeBanksRepository: FakeBanksRepository;

let showBank: ShowBankService;

describe('ShowBank', () => {
  beforeEach(() => {
    fakeBanksRepository = new FakeBanksRepository();

    showBank = new ShowBankService(fakeBanksRepository);
  });

  it('should be able to show a bank', async () => {
    const bank = await fakeBanksRepository.create({
      name: 'available',
    });

    const findBank = await showBank.execute({
      bank_id: bank.id,
    });

    expect(findBank).toBe(bank);
  });

  it('should not be able to show a non existing bank', async () => {
    expect(
      showBank.execute({
        bank_id: 'non-existing-bank-id',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
