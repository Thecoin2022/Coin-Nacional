import FakeBanksRepository from '../repositories/fakes/FakeBanksRepository';
import ListBankService from './ListBankService';

let fakeBanksRepository: FakeBanksRepository;

let listBank: ListBankService;

describe('ListBank', () => {
  beforeEach(() => {
    fakeBanksRepository = new FakeBanksRepository();

    listBank = new ListBankService(fakeBanksRepository);
  });

  it('should be able to list banks', async () => {
    const bank = await fakeBanksRepository.create({
      name: 'itau',
    });

    const banks = await listBank.execute();

    expect(banks).toStrictEqual([bank]);
  });
});
