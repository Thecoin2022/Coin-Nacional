import AppError from '@shared/errors/AppError';
import FakeBanksRepository from '../repositories/fakes/FakeBanksRepository';
import DeleteBankService from './DeleteBankService';

let fakeBanksRepository: FakeBanksRepository;

let deleteBank: DeleteBankService;

describe('DeleteBank', () => {
  beforeEach(() => {
    fakeBanksRepository = new FakeBanksRepository();

    deleteBank = new DeleteBankService(fakeBanksRepository);
  });

  it('should be able to delete a bank', async () => {
    const bank = await fakeBanksRepository.create({
      name: 'available',
    });

    await deleteBank.execute({
      bank_id: bank.id,
    });

    const findBank = await fakeBanksRepository.findById(bank.id);

    expect(findBank).toBeUndefined();
  });

  it('should not be able to delete a non existing bank', async () => {
    expect(
      deleteBank.execute({
        bank_id: 'non-existing-bank-id',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
