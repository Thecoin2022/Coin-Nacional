import { injectable, inject } from 'tsyringe';

import Bank from '../infra/typeorm/entities/Bank';
import IBanksRepository from '../repositories/IBanksRepository';

@injectable()
class ListBankService {
  constructor(
    @inject('BanksRepository')
    private banksRepository: IBanksRepository,
  ) {}

  public async execute(): Promise<Bank[]> {
    const banks = await this.banksRepository.list();

    return banks;
  }
}

export default ListBankService;
