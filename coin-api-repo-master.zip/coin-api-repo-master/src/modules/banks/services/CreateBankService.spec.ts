import FakeBanksRepository from '../repositories/fakes/FakeBanksRepository';
import CreateBankService from './CreateBankService';

let fakeBanksRepository: FakeBanksRepository;

let createBank: CreateBankService;

describe('CreateBank', () => {
  beforeEach(() => {
    fakeBanksRepository = new FakeBanksRepository();

    createBank = new CreateBankService(fakeBanksRepository);
  });

  it('should be able to create a new bank', async () => {
    const bank = await createBank.execute({
      name: 'itau',
    });

    expect(bank).toHaveProperty('id');
    expect(bank.name).toBe('itau');
  });
});
