import { injectable, inject } from 'tsyringe';

import Bank from '../infra/typeorm/entities/Bank';
import IBanksRepository from '../repositories/IBanksRepository';

interface IRequest {
  name: string;
}

@injectable()
class CreateBankService {
  constructor(
    @inject('BanksRepository')
    private banksRepository: IBanksRepository,
  ) {}

  public async execute(bankData: IRequest): Promise<Bank> {
    const bank = await this.banksRepository.create(bankData);

    return bank;
  }
}

export default CreateBankService;
