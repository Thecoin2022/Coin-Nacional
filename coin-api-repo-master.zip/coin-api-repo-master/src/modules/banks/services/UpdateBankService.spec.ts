import AppError from '@shared/errors/AppError';
import FakeBanksRepository from '../repositories/fakes/FakeBanksRepository';
import UpdateBankService from './UpdateBankService';

let fakeBanksRepository: FakeBanksRepository;

let updateBank: UpdateBankService;

describe('UpdateBank', () => {
  beforeEach(() => {
    fakeBanksRepository = new FakeBanksRepository();

    updateBank = new UpdateBankService(fakeBanksRepository);
  });

  it('should be able to update a bank', async () => {
    const bank = await fakeBanksRepository.create({
      name: 'available',
    });

    await updateBank.execute({
      bank_id: bank.id,
      name: 'other-name',
    });

    expect(bank).toHaveProperty('id');
    expect(bank.name).toBe('other-name');
  });

  it('should not be able to update a non existing bank', async () => {
    expect(
      updateBank.execute({
        bank_id: 'non-existing-bank-id',
        name: 'other-name',
      }),
    ).rejects.toBeInstanceOf(AppError);
  });
});
